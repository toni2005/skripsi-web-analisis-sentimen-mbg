# Sistem Analisis Sentimen Program MBG
### Perbandingan Algoritma Random Forest vs K-Nearest Neighbor (KNN)

Sistem berbasis **PHP native + MySQL** (tanpa framework, tanpa dependency Composer)
untuk keperluan luaran sistem skripsi analisis sentimen. Seluruh algoritma
(TF-IDF, Random Forest, KNN, evaluasi) diimplementasikan sendiri dari nol
di PHP agar mudah dijelaskan ke dosen pembimbing/penguji.

---

## 1. Kebutuhan Sistem

- Web server dengan PHP **5.6 atau 7.x/8.x** (kode ini sengaja ditulis kompatibel PHP 5.6+,
  lihat `includes/compat.php`). Disarankan **XAMPP** atau **Laragon** untuk lokal, tapi
  hosting shared PHP 5.6/7.x juga didukung.
- Ekstensi PHP: `mysqli`, `mbstring` (biasanya sudah aktif default di XAMPP)
- MySQL / MariaDB

## 2. Cara Instalasi

1. **Copy folder project**
   Salin seluruh folder `mbg-sentiment` ke folder `htdocs` (XAMPP) atau `www` (Laragon).

2. **Buat Database**
   - Buka phpMyAdmin
   - **Instalasi baru**: Buat database baru bernama `mbg_sentiment`, lalu import file
     `database/mbg_sentiment.sql` melalui tab **Import** di phpMyAdmin.
   - **Sudah pernah install sebelumnya (upgrade)**: JANGAN hapus database lama Anda.
     Import `database/migration_alur_baru.sql` lalu `database/migration_selaraskan_skripsi.sql`
     di database `mbg_sentiment` yang sudah ada — keduanya hanya menambah kolom baru
     tanpa menghapus data.
   - **Setelah database dibuat/di-upgrade (WAJIB untuk hasil normalisasi yang sesuai
     notebook)**: import juga `database/kamus_normalisasi_full.sql` — ini mengganti kamus
     normalisasi kecil bawaan (±40 entri) dengan kamus penuh (4.345 entri) yang persis
     sama dengan `kamuskatabaku.xlsx` yang dipakai di notebook Colab Anda.

3. **Atur koneksi database**
   Buka file `config/db.php`, sesuaikan jika perlu:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');          // isi jika MySQL Anda punya password
   define('DB_NAME', 'mbg_sentiment');
   ```

4. **Jalankan**
   Akses melalui browser:
   ```
   http://localhost/mbg-sentiment/
   ```
   Halaman ini adalah **landing page** (beranda skripsi) — dari sini Anda bisa masuk ke
   dashboard aplikasi (`public/index.php`), coba demo prediksi, atau lihat hasil perbandingan model.
   Dashboard & seluruh menu aplikasi tetap berada di:
   ```
   http://localhost/mbg-sentiment/public/
   ```

5. **Upload data mentah hasil scraping/gabungan**
   Halaman Upload Dataset mengenali beberapa variasi nama kolom secara otomatis. Kolom
   **teks** wajib ada (mis. `teks`, `teks_komentar`, `komentar`); kolom lain seperti
   `platform`, `keyword`, `username`, `tanggal`, `like_count`, dan `label` semuanya
   **opsional**. Jadi file data mentah gabungan (mis. `data_gabungan_mbg.csv`, kolom
   `platform, keyword, video_id, tanggal, username, teks_komentar, like_count` — TANPA
   kolom label) bisa langsung diupload apa adanya.

## 3. Alur Penggunaan Sistem

1. **Upload Dataset** → upload file CSV data mentah (kolom teks wajib, kolom lain
   termasuk label bersifat opsional). Contoh template (tanpa label) bisa diunduh di
   halaman Upload.

2. **Kelola Dataset** → lihat, filter per batch/status label, koreksi label secara
   manual per baris, dan hapus data yang sudah diupload.

3. **Preprocessing** → klik "Jalankan Preprocessing" per batch dataset.
   Tahapan otomatis: *cleaning → case folding → normalisasi → tokenizing
   → stopword removal → stemming*.

4. **Pelabelan Data** → untuk baris yang belum punya label, klik "Jalankan Pelabelan"
   per batch. Sistem memberi label otomatis berbasis **kamus sentimen Bahasa Indonesia
   (InSet Lexicon, 9.074 kata unik dari 3.609 kata positif + 6.607 kata negatif)**: skor dihitung dengan menjumlahkan bobot token yang cocok di kamus positif DAN negatif
   dengan kamus (skor > 0 → positif, skor < 0 → negatif, skor = 0 → netral). Sebaiknya
   periksa & koreksi manual sebagian hasilnya di menu Kelola Dataset sebelum training,
   supaya kualitas label (dan hasil training) lebih baik.

5. **Training Model** → pilih dataset batch yang sudah dipreprocessing DAN berlabel,
   atur parameter (jumlah tree & max_depth untuk Random Forest, nilai K &
   metrik jarak untuk KNN), lalu latih kedua model.

6. **Perbandingan Model** → lihat perbandingan akurasi, precision, recall,
   F1-score, confusion matrix, dan grafik antar algoritma.

7. **Uji Coba Prediksi** → masukkan kalimat baru untuk diuji sentimennya
   menggunakan model yang sudah dilatih (RF dan/atau KNN sekaligus).

## 4. Struktur Folder

```
mbg-sentiment/
├── config/
│   └── db.php                  # konfigurasi koneksi database
├── includes/                   # class inti algoritma (PHP native)
│   ├── Preprocessing.php       # pipeline cleaning s/d stemming
│   ├── StopwordList.php        # daftar stopword Bahasa Indonesia
│   ├── Stemmer.php             # stemmer sederhana (Nazief-Adriani disederhanakan)
│   ├── Lexicon.php              # pelabelan otomatis berbasis kamus sentimen (InSet)
│   ├── TfIdf.php                # ekstraksi fitur TF-IDF
│   ├── KNN.php                  # algoritma K-Nearest Neighbor
│   ├── DecisionTree.php         # base learner Random Forest (CART + Gini)
│   ├── RandomForest.php         # ensemble Decision Tree (bagging + random subspace)
│   └── Evaluator.php            # accuracy, precision, recall, f1, confusion matrix
├── data/
│   └── lexicon_inset.json      # kamus sentimen InSet (positive.tsv + negative.tsv asli, format {"positive":{}, "negative":{}})
├── database/
│   ├── mbg_sentiment.sql       # skema database + seed kamus normalisasi (instalasi baru)
│   └── migration_alur_baru.sql # migrasi untuk database yang sudah ada (upgrade)
├── models/                      # tempat penyimpanan model hasil training (JSON)
├── uploads/                     # (opsional) tempat file CSV yang diupload
├── public/                      # seluruh halaman web (entry point)
│   ├── templates/               # header/footer/layout
│   ├── index.php                # dashboard
│   ├── upload.php / process_upload.php
│   ├── dataset.php / update_label.php
│   ├── preprocessing.php / process_preprocessing.php
│   ├── pelabelan.php / process_pelabelan.php
│   ├── training.php / process_training.php
│   ├── comparison.php
│   └── predict.php / process_predict.php
└── assets/
    ├── css/style.css
    └── js/
```

## 5. Catatan untuk Skripsi

- **Pelabelan Otomatis (Lexicon-Based Labeling)**: karena data hasil scraping tidak
  memiliki label sentimen, sistem memberi label awal secara otomatis menggunakan
  **kamus sentimen InSet** (Koto & Adriani, 2016 — *"InSet Lexicon: Evaluation of a
  Word List for Indonesian Sentiment Analysis in Microblogs"*, IALP 2016). Setiap kata
  hasil preprocessing diberi skor sesuai bobot pada kamus, lalu skor dijumlahkan per
  komentar untuk menentukan label (positif/negatif/netral). Pendekatan ini umum disebut
  **silver-standard labeling** dalam literatur SA berbasis lexicon, dan lazim dipakai
  sebagai langkah awal sebelum data dipakai melatih model machine learning supervised
  (Random Forest, KNN). Untuk validitas penelitian yang lebih kuat, sebutkan di bab
  metodologi bahwa sebagian data hasil label otomatis sudah diperiksa/dikoreksi manual
  (menu Kelola Dataset), dan jika memungkinkan lakukan uji kesepakatan (mis. dibandingkan
  dengan anotasi manual pada sampel data) untuk memperkuat validitas label.
- **Stemmer**: implementasi stemmer pada `includes/Stemmer.php` adalah
  versi ringkas dari algoritma Nazief-Adriani (bukan pustaka pihak ketiga),
  dibuat native di PHP agar sistem 100% mandiri tanpa Composer. Jika ingin
  akurasi stemming lebih tinggi dan koneksi internet kampus mengizinkan
  instalasi Composer, Anda bisa mengganti kelas ini dengan pustaka
  **Sastrawi untuk PHP** (`sastrawi/sastrawi`), sebutkan hal ini di bab
  metodologi jika digunakan.
- **Random Forest**: dibangun dari beberapa Decision Tree (CART) dengan
  *bootstrap aggregating* (bagging) dan *random subspace method* (memilih
  subset fitur acak tiap tree) — sesuai konsep Random Forest yang umum
  dijelaskan di literatur (Breiman, 2001), diimplementasikan manual.
- **KNN**: mendukung dua metrik jarak (Euclidean dan Cosine Distance),
  dengan voting mayoritas dari K tetangga terdekat.
- **TF-IDF**: fitur dibatasi maksimal 500 term paling sering muncul demi
  efisiensi komputasi di PHP (bisa disesuaikan di `TfIdf.php`).
- Semua parameter (jumlah tree, kedalaman tree, nilai K, rasio data
  testing, metrik jarak) dapat diatur langsung dari antarmuka Training
  Model — cocok untuk eksperimen dan pembahasan sensitivitas parameter
  di skripsi.
- Dataset TIDAK dibagi otomatis dengan k-fold cross validation pada versi
  ini (hanya train-test split acak sesuai rasio yang dipilih). Jika
  dosen pembimbing meminta k-fold cross validation, ini bisa ditambahkan
  sebagai pengembangan lanjutan.

## 6. Penyelarasan dengan Notebook Colab Asli (Update Terbaru)

Update ini menyesuaikan sistem berdasarkan pembacaan LANGSUNG kode di keempat notebook
Colab Anda (`04_Penggabungan_Standardisasi_Data.ipynb`, `05_Text_Preprocessing.ipynb`,
`06_Pelabelan_Sentimen.ipynb`, `07_Ekstraksi_Pemodelan_Analisis.ipynb`) — bukan lagi
tebakan/pola umum. Perubahan dari versi sebelumnya:

1. **Urutan preprocessing diperbaiki**: **case folding → cleaning** (sebelumnya kebalik).
   Ditambahkan langkah reduksi huruf berulang ("bagusss" → "baguss", regex `(.)\1{2,}` →
   `\1\1`, persis notebook subbab 4.3). Regex emoji disamakan persis rentang unicode-nya
   (bukan lagi hapus semua karakter non-ASCII). Filter panjang kata minimum di stopword
   removal **dihapus** (notebook tidak memfilter berdasarkan panjang kata).
2. **Stopword list diganti total** (`includes/StopwordList.php`): sekarang 809 kata bawaan
   asli library Sastrawi (`StopWordRemoverFactory().get_stop_words()`) + 35 kata tambahan
   custom dari notebook (nya, deh, dong, sih, loh, kok, ya, nih, kak, min, lah, https, co,
   RT, ..., amp, lu, fyp, gue, cs, kayak, termul, yg, aja, sdh, gak, ga, update, apk, ajar,
   si, ok, gas, omon, nyinyir) — total 839 kata unik.
3. **Kamus normalisasi diganti total** (`database/kamus_normalisasi_full.sql`, 4.345
   entri): diunduh & di-parse PERSIS dari `kamuskatabaku.xlsx` sumber yang sama dengan
   notebook (`analysisdatasentiment/kamus_kata_baku`), termasuk mereplikasi perilaku
   `dict(zip(...))` di Python (entri duplikat → yang terakhir muncul di file Excel yang
   dipakai). Entri **"mbg" sengaja dikecualikan** (sesuai notebook, supaya "mbg" tidak
   berubah jadi "mbak"). **Jalankan file ini setelah instalasi** (lihat langkah instalasi
   di bawah) — kamus kecil bawaan lama tidak lagi representatif.
4. **Kamus InSet diganti total** (`includes/Lexicon.php`, `data/lexicon_inset.json`):
   direplikasi PERSIS cara notebook menghitung skor (subbab 4.4) — **BUKAN** memakai bobot
   asli TSV InSet dan **BUKAN** menjumlahkan skor dari dua kamus terpisah (koreksi dari
   asumsi update sebelumnya). Yang benar: kata di kamus positif diberi skor **+1** (flat),
   kata di kamus negatif diberi skor **-1** (flat), dan untuk ±1.142 kata yang muncul di
   kedua kamus, **skor negatif yang menang/menimpa** (karena di notebook, dict negatif
   diisi belakangan dan menimpa dict positif). Skor per komentar = jumlah skor semua kata
   yang cocok (bukan cuma yang match satu kamus).
   **`kamus_tambahan` belum bisa direplikasi**: notebook Anda mereferensikan
   `kamus_sentimen.update(kamus_tambahan)` tapi definisi `kamus_tambahan` tidak ada di
   file `.ipynb` manapun (sel yang mendefinisikannya sepertinya tidak sempat tersimpan).
   Sistem ini memperlakukannya sebagai kosong. Kalau Anda ingat isinya, isi
   `data/kamus_tambahan.json` (format `{"kata": skor, ...}`) — otomatis akan menimpa
   kamus utama untuk kata yang sama, persis seperti `.update()` di notebook.
5. **TF-IDF ditulis ulang total** (`includes/TfIdf.php`) untuk meniru
   `TfidfVectorizer(max_features=3000, ngram_range=(1,2), min_df=5, max_df=0.9)`:
   - Vocabulary sekarang berisi **unigram + bigram** (dua kata berurutan), bukan cuma
     unigram.
   - **min_df=5**: term yang muncul di kurang dari 5 dokumen data latih dibuang.
   - **max_df=0.9**: term yang muncul di lebih dari 90% dokumen data latih dibuang.
   - **TF pakai jumlah kemunculan mentah** (bukan dibagi panjang dokumen seperti versi
     sebelumnya), **IDF pakai smoothing** `ln((1+N)/(1+df))+1`, dan vektor akhir
     **dinormalisasi L2** per dokumen — semua persis default `TfidfVectorizer` di sklearn.
   - Bisa dimatikan (unigram saja) atau diubah lewat form Training.
6. **SMOTE ditambahkan** (`includes/Smote.php`) — diterapkan pada data LATIH saja
   (setelah transform TF-IDF, sebelum training), sesuai notebook subbab 4.5-4.6.
7. **Stratified train-test split** — proporsi tiap kelas sentimen dijaga sama di data
   latih & data uji, sesuai `train_test_split(..., stratify=y)` di notebook.
8. **Metrik evaluasi diganti ke weighted-average** (`includes/Evaluator.php`): precision/
   recall/F1 sekarang dibobot berdasarkan jumlah data aktual per kelas (support), persis
   `average='weighted'` di notebook — sebelumnya memakai macro-average (bobot rata semua
   kelas, tanpa memandang jumlah datanya) yang akan menghasilkan angka berbeda.
9. **Default parameter Random Forest & KNN disamakan**: `n_estimators=100` (sebelumnya
   10), `max_depth` tanpa batas secara default (sebelumnya dibatasi 8 — notebook tidak
   membatasi kedalaman tree), metrik KNN default `cosine` (notebook menguji k=3..15 pakai
   cosine dan memilih k dengan akurasi tertinggi pada data uji — Anda perlu coba beberapa
   nilai k manual di form Training untuk mencari yang terbaik, karena sistem ini belum
   melakukan pencarian k otomatis seperti notebook).
10. **Stemming tetap opsional, default NONAKTIF** (notebook subbab 4.3 tidak melakukan
    stemming sama sekali — konfirmasi ini sudah benar dari update sebelumnya).

**Cara menjalankan migrasi setelah update ini** (kalau database sudah pernah diinstal):
```bash
mysql -u root -p mbg_sentiment < database/migration_selaraskan_skripsi.sql
mysql -u root -p mbg_sentiment < database/kamus_normalisasi_full.sql
```

**Catatan penting — yang MASIH belum/tidak bisa disamakan 100%:**
- Implementasi Random Forest/KNN/Decision Tree ditulis manual di PHP, berbeda dari
  `scikit-learn` (detail split, tie-breaking, cara bootstrap sampling).
- Notebook TIDAK memakai `GridSearchCV`/cross-validation (berbeda dari yang disebutkan di
  skripsi Bab III Tabel 3.6) — pemilihan k KNN dilakukan dengan mencoba k=[3,5,7,9,11,13,15]
  langsung pada data uji dan memilih akurasi tertinggi. Web ini belum otomatis melakukan
  pencarian ini, Anda perlu coba manual dari form Training.
- `kamus_tambahan` di notebook Anda tidak diketahui isinya (lihat poin 4 di atas).
- Random seed PHP (`mt_rand`) vs Python (`numpy`/`sklearn`, `random_state=42`) tidak bisa
  disamakan — walau prosesnya identik, sampel yang diambil (split, SMOTE, bootstrap RF)
  akan tetap berbeda tiap kali dijalankan.
- Notebook `04_Penggabungan_Standardisasi_Data.ipynb` menggabungkan 3 file CSV manual di
  Colab (`pd.concat`); web ini punya alur upload sendiri di menu Dataset — secara konsep
  sama (gabung lalu hapus duplikat/kosong), tapi bukan file/kode yang persis sama.

Dengan semua penyelarasan di atas, hasil web ini seharusnya **jauh lebih dekat** ke hasil
Colab Anda dibanding versi sebelumnya, tapi kemungkinan besar **masih belum identik 100%**
karena keterbatasan implementasi manual PHP vs library Python yang sudah teroptimasi.



## 7. Perbaikan "Allowed Memory Size Exhausted" (Vektor TF-IDF Sparse)

Kalau Anda sempat mengalami error seperti ini saat Training:

```
Fatal error: Allowed memory size of 536870912 bytes exhausted ... in includes/TfIdf.php on line 139
```

Penyebabnya: versi sebelumnya menyimpan setiap vektor TF-IDF sebagai **array padat
(dense)** sepanjang seluruh vocabulary (mis. 3000 kolom) — padahal satu komentar medsos
biasanya cuma berisi belasan kata unik. Untuk ribuan baris data, ini gampang menembus
ratusan MB–GB RAM (dan makin parah kalau SMOTE menambah jumlah data latih).

**Sudah diperbaiki**: `TfIdf::transform()` sekarang mengembalikan vektor **sparse**
(hanya menyimpan kolom yang nilainya bukan-nol). Seluruh algoritma yang memakai vektor
ini — `RandomForest.php`, `DecisionTree.php`, `KNN.php`, `Smote.php` — sudah disesuaikan
untuk membaca vektor sparse ini dengan benar (kolom yang tidak ada dianggap 0). Hasil uji
dengan data sintetis skala ~5.800 komentar (mendekati skala skripsi): peak memori turun
dari **>512MB (fatal error)** menjadi **~144MB**, jauh di bawah limit default PHP.

**Kalau Anda tetap menemui error memori** (mis. dataset Anda jauh lebih besar, atau
`max_features`/`n_trees` diset sangat tinggi), naikkan `memory_limit` di `php.ini`:

1. Cari file `php.ini` yang dipakai XAMPP Anda — biasanya di
   `C:\xampp\php\php.ini` (Windows) atau lewat XAMPP Control Panel → Apache → Config → PHP (php.ini).
2. Cari baris `memory_limit = 512M`, ubah jadi misalnya:
   ```ini
   memory_limit = 2048M
   ```
3. **Restart Apache** dari XAMPP Control Panel supaya perubahan berlaku.
4. Kalau training terasa lambat (bukan error memori), naikkan juga:
   ```ini
   max_execution_time = 300
   ```

## 8. Perbaikan "Maximum Execution Time Exceeded" (Optimasi Algoritma Split Tree)

Setelah masalah memori di atas selesai, Anda mungkin sempat menemui error baru:

```
Fatal error: Maximum execution time of 600 seconds exceeded ... in includes/DecisionTree.php on line 140
```

Penyebabnya: algoritma pencarian split terbaik di tiap node pohon (Random Forest)
sebelumnya memindai ULANG seluruh baris data dari awal untuk setiap kandidat threshold
(sampai 8x per fitur, per node) — untuk data ribuan baris x 100 tree, ini jadi sangat
lambat di PHP murni (beda dengan scikit-learn yang jalan di C teroptimasi).

**Sudah dioptimasi 2 tahap:**
1. Diganti ke algoritma standar CART "sort & sweep": data diurutkan **sekali** per
   fitur per node, lalu disapu sekali sambil menghitung Gini impurity secara
   incremental — dari `O(fitur x 8 x n)` jadi `O(fitur x n log n)`, sekaligus
   mengevaluasi SEMUA titik batas nilai (bukan cuma 8 sampel, jadi hasil split
   berpotensi lebih akurat juga).
2. Sorting diganti dari `usort()` dengan closure PHP (lambat, setiap perbandingan
   memanggil balik fungsi PHP) ke `asort()` bawaan PHP (jalan di level C, jauh
   lebih cepat untuk data besar).

**Hasil uji** (data sintetis ~5.800 komentar, sama seperti sebelumnya, setelah SMOTE
jadi 11.478 data latih, 100 tree Random Forest + KNN evaluasi 1.160 data uji): waktu
total turun dari **>600 detik (timeout)** jadi **~204 detik** — margin aman ~3x di bawah
batas default.

**Kalau di komputer Anda masih terasa lambat / mepet limit** (spek lebih rendah, data
jauh lebih banyak, atau `n_trees`/`max_depth` diset sangat tinggi), naikkan juga
`max_execution_time` di `php.ini` yang sama seperti langkah menaikkan `memory_limit`
di atas:
```ini
max_execution_time = 900
```
atau set `0` untuk tanpa batas waktu (hati-hati: kalau ada bug/infinite loop, request
tidak akan pernah berhenti sendiri). Restart Apache setelah mengubah `php.ini`.

**Update lanjutan (v4) — kalau optimasi di atas masih belum cukup untuk dataset Anda:**
Optimasi v1-v3 di atas mempercepat pencarian split, tapi waktunya **masih ikut membesar
seiring bertambahnya jumlah data** (node ROOT selalu memindai SEMUA data latih — bisa
puluhan ribu baris setelah SMOTE). Kalau dataset Anda cukup besar, ini tetap bisa
melampaui limit.

**Sudah ditambahkan subsampling**: `DecisionTree` sekarang punya parameter
`$maxSplitSample` (default **2000**). Kalau satu node punya baris lebih banyak dari itu,
pencarian split terbaik di node itu memakai **subsample acak 2000 baris** (bukan semua
baris) — ini menjamin waktu pencarian split per node **TIDAK LAGI bergantung pada n**,
jadi total waktu training jadi bisa diprediksi berapa pun ukuran dataset Anda.
2.000 sampel acak sudah cukup representatif secara statistik untuk mengestimasi titik
split yang baik (dipakai juga di implementasi production seperti LightGBM/XGBoost dalam
bentuk histogram-based splitting).

**Hasil uji terbaru**: dataset sintetis 100.000 baris x 3000 fitur → **~2,4 detik/tree**
(~244 detik untuk 100 tree, dari yang sebelumnya bisa membengkak tanpa batas). Pipeline
penuh (5.800 komentar → SMOTE → 11.478 data latih → 100 tree RF + evaluasi KNN) turun
dari ~204 detik jadi **~97 detik**, dengan akurasi yang tidak berubah signifikan
(perbedaan <1%, wajar karena sampling acak).

## 9. Perbaikan "Akurasi Sangat Rendah / Model Selalu Memprediksi 1 Kelas Saja"

Kalau hasil training Anda terlihat seperti ini (akurasi rendah, presisi JAUH lebih rendah
dari akurasi, mis. akurasi 24% tapi presisi cuma 6%) — itu tandanya model Random Forest
memprediksi **SATU kelas yang sama untuk SEMUA data uji**, bukan sekadar performa jelek
biasa. (Cara mendeteksinya: kalau presisi ≈ akurasi², itu tanda pasti model cuma
menebak 1 kelas terus-menerus.)

**Penyebab yang ditemukan** (lewat investigasi mendalam pakai data sintetis skala besar):
`max_depth` yang sangat tinggi/tanpa batas (nilai lama: 100, meniru `max_depth=None` di
notebook) membuat setiap tree tumbuh sangat dalam dan overfit parah ke noise spesifik
tiap bootstrap sample. Kombinasi ini dengan SMOTE pada vektor TF-IDF berdimensi tinggi
(ribuan kolom, sangat sparse) membuat seluruh ensemble 100 tree bisa "sepakat keliru"
ke satu kelas yang sama — fenomena yang didokumentasikan di literatur ML soal SMOTE
pada data sparse berdimensi tinggi (interpolasi linear SMOTE di ruang sparse bisa
menghasilkan titik sintetis yang tidak representatif, dan tree gampang menghafal pola
ini alih-alih belajar sinyal asli).

**Sudah diperbaiki:**
1. Default `max_depth` (kalau dikosongkan di form) diturunkan dari 100 → **10**
   (jauh lebih stabil secara empiris; notebook Colab/sklearn memang tidak membatasi
   `max_depth`, tapi implementasi CART murni-PHP ini tidak punya regularisasi internal
   sekuat sklearn, jadi butuh batas eksplisit).
2. Ditambahkan regularisasi **`min_samples_leaf`** (default 5, bisa diatur di form) —
   menolak kandidat split yang membuat salah satu sisi node terlalu kecil.
3. Sudah dipastikan (lewat uji isolasi) bug ini **BUKAN** disebabkan oleh optimasi
   subsampling di bagian 8 — sudah diuji mematikan subsampling sama sekali dan gejala
   collapse tetap muncul, jadi subsampling aman dipakai bersamaan dengan perbaikan ini.

**PENTING — batasan yang jujur perlu Anda ketahui:** dalam pengujian saya, kombinasi
`max_depth` + jumlah tree + SMOTE pada data sintetis dengan sinyal kata lemah (mirip
komentar pendek dengan sedikit kata bermuatan sentimen) **masih bisa menghasilkan
collapse sesekali** meski sudah pakai `max_depth=10` dan `min_samples_leaf=5` — terutama
kalau jumlah tree besar (100). Ini kemungkinan batas kemampuan implementasi RF+SMOTE
murni-PHP pada data sparse berdimensi tinggi, bukan sesuatu yang bisa dijamin 100% hilang
hanya dengan mengubah 1-2 parameter.

**Yang disarankan Anda coba langsung di data ASLI Anda** (training sekarang cepat,
hitungan menit, jadi aman coba beberapa kombinasi dan bandingkan):
1. Cek dulu apakah gejalanya muncul dengan pengaturan default baru (`max_depth=10`,
   `min_samples_leaf=5`). Kalau distribusi PREDIKSI (bukan cuma akurasi) sudah bervariasi
   ke 3 kelas — berarti sudah membaik.
2. Kalau masih collapse: coba **turunkan `max_features` TF-IDF** (misalnya dari 3000 ke
   500-1000) — dimensi lebih rendah relatif terhadap jumlah data terbukti membantu
   stabilitas di banyak kasus serupa.
3. Coba **matikan SMOTE** (uncheck di form) sebagai perbandingan — kalau tanpa SMOTE
   hasilnya jauh lebih baik/stabil, berarti SMOTE-lah yang jadi sumber utama masalah
   untuk data Anda, dan Anda bisa laporkan balik supaya saya bantu cari SMOTE yang lebih
   robust (mis. batasi rasio oversampling, jangan sampai 100% menyamai kelas mayoritas).
4. Coba **kurangi jumlah tree** (mis. 20-30 alih-alih 100) sambil naikkan `max_depth`
   sedikit — kombinasi tree lebih sedikit + regularisasi lebih longgar kadang lebih
   stabil daripada banyak tree yang semuanya overfit ke pola yang sama.
5. Laporkan balik hasil eksperimen # di atas (distribusi prediksi + akurasi/precision di
   tiap kombinasi) supaya saya bisa bantu diagnosis lebih presisi berdasarkan karakteristik
   data ASLI Anda (bukan simulasi saya yang mungkin tidak mewakili data Anda persis).

## 10. KOREKSI Bagian 9 — Root Cause Sebenarnya: Underfitting, Bukan Collapse Overfitting

Bagian 9 di atas (analisis lama) ternyata **salah arah**. Investigasi ulang dengan data
sintetis berskala realistis (5.858 baris, proporsi kelas & vocab mirip data skripsi)
menunjukkan yang sebenarnya terjadi:

- Gejala precision (mis. 65,91%) jauh **lebih tinggi** dari akurasi (28,44%) BUKAN tanda
  model menebak 1 kelas terus (kalau itu masalahnya, precision biasanya justru rendah/tidak
  terdefinisi untuk 2 dari 3 kelas). Pola precision >> akurasi dengan recall = akurasi
  (ini konsisten secara matematis: recall weighted SELALU sama dengan akurasi) di sini
  adalah tanda model **jarang memprediksi kelas mayoritas** dengan benar (recall kelas
  mayoritas rendah) sementara kelas yang jarang diprediksi kebetulan sering benar
  (precision tinggi untuk prediksi yang sedikit itu) — pola khas **underfitting**, bukan
  collapse.
- Penyebabnya: `max_depth=10` + `min_samples_leaf=5` (default lama) terlalu ketat untuk
  data TF-IDF sparse berdimensi ribuan. Dengan kedalaman cuma 10 level dan random feature
  subspace ~55 fitur per node dari total ~1500-3000, pohon tidak sempat menemukan cukup
  kata informatif di sepanjang jalur root→leaf, sehingga banyak data numpuk di leaf yang
  tidak murni dan condong ke kelas mayoritas.
- Diuji langsung: pada data sintetis yang sama, `max_depth=10` → akurasi ~65-83%;
  `max_depth=50` → ~87-92%; `max_depth=200` (mendekati "tanpa batas" seperti sklearn) →
  ~92-96%. Waktu training 100 tree tetap dalam hitungan puluhan detik–2 menit, jauh di
  bawah `set_time_limit(600)`.
- Sama seperti scikit-learn (`max_depth=None` default), Random Forest tahan overfitting
  meski pohonnya dalam — regularisasinya datang dari **bagging** (tiap tree cuma lihat
  sampel bootstrap berbeda) + **random feature subspace segar di tiap node**, bukan dari
  membatasi kedalaman.

**Perbaikan yang diterapkan di paket ini:**
1. Default `max_depth` dinaikkan dari **10 → 50** (`includes/RandomForest.php` &
   `public/process_training.php`). Kalau ingin lebih dekat ke notebook (`max_depth=None`),
   isi manual 100-300 di form — akan lebih lambat tapi masih dalam batas waktu.
2. Default `min_samples_leaf` diturunkan dari **5 → 1**, PERSIS default sklearn.
   Parameter ini TIDAK ada di grid `GridSearchCV` notebook (subbab 4.5) — yang dituning
   cuma `n_estimators`, `max_depth`, `min_samples_split` — jadi hasil final notebook
   otomatis memakai `min_samples_leaf=1` bawaan sklearn, bukan hasil tuning.
3. `maxSplitSample` (batas baris yang dipindai saat mencari split terbaik per node)
   dinaikkan dari **2000 → 3000** secara default dan sekarang bisa diatur lewat
   constructor `RandomForest`.
4. **Baru:** opsi centang **"Cari split pakai SELURUH data latih (tanpa subsampling)"**
   di form training RF. scikit-learn TIDAK pernah men-subsample saat mencari split —
   selalu memindai semua baris di satu node. Kalau dicentang, batas `maxSplitSample`
   dihilangkan sepenuhnya (paling dekat ke notebook), dengan konsekuensi training
   ~2x lebih lambat pada dataset besar.

**Hasil pengujian pada data sintetis** (5.858 baris, proporsi kelas & pola sinyal-kata
dibuat semirip mungkin dengan kondisi skripsi — bukan data ASLI Anda, karena file ZIP
skripsi tidak menyertakan data database, hanya skema tabel):

| Pengaturan | Akurasi |
|---|---|
| Default LAMA (bug): `max_depth=10`, `min_samples_leaf=5` | ~25-65%* |
| Default BARU: `max_depth=50`, `min_samples_leaf=1`, subsample 3000 | ~92-93% |
| Mode "paling dekat notebook": `max_depth=300`, `min_samples_leaf=1`, tanpa subsampling | ~93% |

\* bervariasi tergantung tingkat noise data sintetis yang dipakai untuk menguji; pada
data produksi Anda yang sebenarnya, hasil bug lama tercatat 25-28%.

**Catatan jujur — batas seberapa dekat ini bisa cocok dengan skripsi:** ini tetap
implementasi CART/Random Forest murni-PHP buatan sendiri, bukan pemanggilan langsung ke
scikit-learn, jadi **jangan berharap angka akurasinya identik 100%** dengan hasil
notebook Colab (74,40%). Beberapa sumber perbedaan yang TIDAK bisa dihilangkan hanya
dengan mengubah parameter:
- Generator angka acak PHP (`mt_rand`, Mersenne Twister versi PHP) berbeda dari NumPy
  (`random_state=42`), jadi bootstrap sampling, pemilihan fitur acak per node, dan SMOTE
  tidak akan menghasilkan urutan acak yang sama persis walau di-seed.
- Algoritma pencarian split ("sort & sweep" di sini) secara matematis setara dengan
  sklearn, tapi detail tie-breaking saat ada nilai fitur yang sama bisa berbeda kecil.
- SMOTE di sini reimplementasi sendiri (k-nearest neighbor pakai jarak Euclidean manual),
  bukan `imbalanced-learn.SMOTE` — hasil interpolasinya secara statistik mirip tapi tidak
  identik baris per baris.
- `GridSearchCV` di notebook mencoba 3×3×2 = 18 kombinasi `RandomForestClassifier` dan
  memilih yang terbaik lewat cross-validation; paket ini memakai satu kombinasi tetap
  (`max_depth=50` default) tanpa cross-validation otomatis — kalau ingin meniru lebih
  dekat, coba latih beberapa kali dengan `max_depth` berbeda (50, 100, 200, 300) dan
  bandingkan mana yang akurasinya paling tinggi di data uji Anda, mirip semangat
  `GridSearchCV`.

Dengan perbaikan di atas, akurasi RF pada data sintetis naik dari kisaran bug lama
menjadi **~92-96%** tergantung `max_depth`. Di data ASLI Anda, hasilnya seharusnya juga
naik drastis dari 25-28% dan **mendekati** (meski kemungkinan tidak identik persis)
angka 74,40% di skripsi. **Latih ulang model RF Anda dengan default baru ini** (atau
coba centang mode "paling dekat notebook" + naikkan `max_depth` ke 200-300 untuk hasil
paling mendekati), lalu bandingkan.

## 11. Perbaikan "Upload/Preprocessing/Pelabelan Sangat Lambat" (Transaction Batching)

Kalau sebelumnya upload file CSV ribuan baris (mis. ~5.800an baris hasil scraping)
terasa sangat lambat — baik di lokal (XAMPP/Laragon) maupun di hosting — penyebabnya
BUKAN parsing CSV atau ukuran file, tapi cara data disimpan ke database:

**Penyebab**: `process_upload.php` (begitu juga `process_preprocessing.php` dan
`process_pelabelan.php`) menjalankan **satu query INSERT/UPDATE per baris** dengan
`autocommit` MySQL/MariaDB dalam kondisi AKTIF (default mysqli). Artinya setiap baris
memicu **commit terpisah** (fsync ke disk) ke database. Untuk InnoDB, satu commit bisa
makan beberapa hingga puluhan milidetik tergantung disk — kalau dikalikan 5.800 baris,
totalnya bisa jadi puluhan detik sampai beberapa menit, walaupun setiap query INSERT-nya
sendiri sebenarnya sangat cepat. Di hosting biasanya lebih parah lagi karena ditambah
latensi jaringan ke server database.

**Sudah diperbaiki**: ketiga file di atas sekarang membungkus seluruh proses insert/update
dalam **transaction** (`autocommit(false)` + `begin_transaction()`), dan hanya melakukan
**commit per 500 baris** (bukan per 1 baris). Hasilnya, 5.800 baris cukup ~12 kali commit
ke disk, bukan 5.800 kali — biasanya turun dari puluhan detik/menit menjadi **1-3 detik**
untuk upload, dan proporsional lebih cepat untuk preprocessing & pelabelan. Kalau terjadi
error di tengah proses, transaction akan di-**rollback** (batal semua, bukan tersimpan
setengah-setengah) supaya data tetap konsisten.

Tidak ada perubahan pada `php.ini` yang WAJIB untuk perbaikan ini, tapi kalau dataset
Anda jauh lebih besar dari ~6.000 baris dan masih terasa lambat, tetap disarankan
menaikkan `max_execution_time` seperti di bagian 7-8 di atas.

## 13. Perbaikan "RF Masih Kalah dari KNN Meski Sudah Ikuti Bagian 10" (Form Training Menimpa Default yang Sudah Diperbaiki)

Kalau setelah semua perbaikan di Bagian 10 (`max_depth` default 50, `min_samples_leaf`
default 1), hasil Training Model dari **form web** (`public/training.php`) tetap
menunjukkan KNN lebih tinggi dari Random Forest — padahal skripsi/notebook Colab Anda
menunjukkan RF lebih unggul — penyebabnya BUKAN di `process_training.php` (bagian
backend/PHP sudah benar), tapi di **form HTML**-nya sendiri:

**Penyebab**: input `min_samples_leaf` di `public/training.php` masih di-hardcode
`value="5"` di HTML. Karena field `<input type="number">` ini **tidak pernah kosong**
saat form dikirim (browser selalu mengirim "5" kalau user tidak mengubahnya), default
pintar `1` yang sudah disiapkan di `process_training.php` (`$minLeafRaw ... : '1'`)
**tidak pernah benar-benar terpakai** — form selalu mengirim "5", menimpa perbaikan yang
sudah dilakukan di bagian 10. Efeknya sama seperti sebelum perbaikan: pohon jadi sedikit
lebih dangkal/kurang fleksibel dari yang seharusnya, terutama pada data TF-IDF sparse
berdimensi tinggi.

**Sudah diperbaiki**: field `min_samples_leaf` di form sekarang dikosongkan defaultnya
(`value=""` + placeholder), supaya default `1` dari `process_training.php` benar-benar
terpakai kalau Anda tidak mengisi apa pun — konsisten dengan `max_depth` yang memang
sudah dikosongkan defaultnya sejak Bagian 10.

**Sudah diuji** (data sintetis ~5.860 baris/1.172 data uji, skala persis meniru skripsi,
sinyal kata sengaja dibuat LEMAH/noisy supaya representatif untuk data komentar medsos
pendek): dengan default yang sudah diperbaiki ini, Random Forest secara konsisten
mengungguli KNN di kedua skenario pengujian (selisih akurasi mirip pola di skripsi Anda:
RF jauh lebih unggul dari KNN k=5/cosine).

**Yang perlu Anda lakukan:**
1. **Ganti file `public/training.php` Anda dengan versi baru ini** (upload ulang ke
   hosting) — cukup file ini + `README.md`, file lain di paket ini tidak berubah dari
   yang sebelumnya sudah Anda pakai.
2. Saat Training Model lewat form: **kosongkan** field "Minimal Sampel per Leaf" dan
   "Max Depth" (biarkan placeholder-nya saja), supaya default `min_samples_leaf=1` &
   `max_depth=50` benar-benar dipakai.
3. Latih ulang RF dan KNN pada data ASLI Anda dengan pengaturan itu, lalu bandingkan lagi
   di menu Perbandingan Model.
4. **Kalau RF masih kalah dari KNN setelah ini**, kemungkinan penyebabnya spesifik ke
   karakteristik data asli Anda (bukan lagi bug umum yang bisa saya reproduksi dengan
   data sintetis) — laporkan balik dengan menyertakan: akurasi/presisi/recall KEDUA
   model, nilai `k` & metrik KNN yang dipakai, `n_trees`/`max_depth` RF yang dipakai, dan
   isi `debug_root_is_leaf_count` + `debug_root_labels` dari parameter hasil training RF
   (bisa dilihat di halaman riwayat training) — data diagnostik ini akan sangat membantu
   mempersempit penyebab sebenarnya di data Anda.

## 15. Default RF Dinaikkan ke `max_depth=200` + Full-Split ON (Otomatis Reproduksi ~71% Tanpa Atur Manual)

Riwayat training Anda sendiri (menu Training Model → Riwayat Training) sudah menunjukkan
kombinasi mana yang menang secara meyakinkan:

| max_depth | min_samples_leaf | full-split | Akurasi RF |
|---|---|---|---|
| 100 | 5 | ❌ | 59.95% |
| 200 | 1 | ❌ | 54.48%–56.62% |
| **200** | **1** | **✅** | **70.62%–71.14%** |

Sebelum update ini, form Training mengharuskan Anda mengisi `max_depth=200` secara manual
DAN mencentang "cari split pakai seluruh data latih" setiap kali — kalau lupa satu saja
(paling sering: lupa centang full-split), hasilnya jatuh balik ke ~55-60% walau `max_depth`
sudah diisi tinggi.

**Sudah diperbaiki** — kedua pengaturan itu sekarang jadi **default form** (di
`public/training.php` & `public/process_training.php`):
1. Field `max_depth` kalau dikosongkan sekarang otomatis memakai **200** (sebelumnya 50).
2. Kotak centang **"cari split pakai seluruh data latih" sekarang tercentang secara
   default** (sebelumnya kosong) — pakai trik `<input type="hidden" ... value="0">` di
   depan checkbox supaya PHP tetap bisa membedakan "user sengaja uncheck" dari "form belum
   disentuh", tanpa mengubah cara `process_training.php` membaca `$_POST['full_split_search']`.

Efeknya: klik "Latih Model Random Forest" tanpa mengubah apa pun sekarang langsung memakai
kombinasi yang terbukti ~70-71% di riwayat Anda, bukan lagi kombinasi lama yang cuma ~55-60%.
Konsekuensinya training jadi lebih lambat (100 tree + full-split ≈ 29 menit di riwayat Anda,
dibanding ≈90 detik tanpa full-split) — kalau cuma mau uji coba cepat, turunkan `n_trees` ke
10-30 dulu, atau uncheck full-split secara manual (dengan konsekuensi akurasi turun lagi
sesuai tabel di atas).

**Yang perlu Anda lakukan:** upload ulang `public/training.php` dan
`public/process_training.php` (dua file ini yang berubah) ke hosting, lalu latih ulang tanpa
mengubah pengaturan apa pun untuk memverifikasi akurasi mendekati ~70-71% seperti riwayat.

## 16. Perbaikan "Pengujian Harus Ditunjukkan dari Data Testing" (Revisi Dosen Pembimbing)

Revisi dari dosen: hasil pengujian model (akurasi/precision/recall/F1 di menu
**Perbandingan Model**) harus **ditunjukkan bukti bahwa nilai tersebut memang
dihitung dari data testing** (data uji), bukan sekadar angka agregat yang
dipercaya begitu saja.

**Akar masalah**: secara *perhitungan*, sistem ini sebenarnya SUDAH benar sejak
awal — `process_training.php` memang melakukan *stratified train-test split*
lalu `Evaluator::evaluate()` dipanggil dengan `$testLabels` (label ASLI data
uji) vs `$predictions` (hasil `predictBatch($testVectors)`, HANYA dari data
uji), persis seperti seharusnya. Yang jadi masalah adalah sistem **tidak
pernah menunjukkan buktinya**:

1. Kolom `dipakai_untuk` (enum `train`/`test`/`unused`) sudah ada di skema
   tabel `dataset` sejak instalasi awal, tapi **tidak pernah diisi oleh kode
   manapun** — jadi tidak ada cara untuk melihat baris data mana saja yang
   benar-benar menjadi data uji pada training terakhir.
2. Tidak ada halaman yang menampilkan hasil prediksi PER BARIS data uji
   (teks asli, label aktual vs label hasil prediksi, benar/salah) — hanya
   angka akurasi/precision/recall/F1 agregat dan confusion matrix.

**Sudah diperbaiki:**

- `public/process_training.php`: setiap kali training dijalankan untuk sebuah
  batch, seluruh baris batch tsb ditandai ulang (`UPDATE dataset SET
  dipakai_untuk='unused'` lalu diisi `'train'`/`'test'` sesuai hasil
  `stratifiedSplit()` yang baru saja dipakai). File model JSON (`models/*.json`)
  sekarang juga menyimpan `test_detail` (id, teks asli, label aktual, label
  prediksi, benar/salah untuk SETIAP baris data uji) dan `evaluation_recap`
  (rekap jumlah benar/salah/akurasi) — tidak perlu tabel/migrasi database baru.
- **Halaman baru `public/pengujian.php` ("Hasil Pengujian")**: menampilkan
  tabel detail hasil pengujian per baris data uji (dengan filter batch,
  algoritma, dan status benar/salah, serta paginasi), plus kartu ringkasan
  yang menghitung ulang akurasi dari jumlah "Prediksi Benar" / "Total Data
  Uji" sebagai bukti konsistensi dengan angka di menu Perbandingan Model.
  Tautan menu ditambahkan di sidebar ("📄 Hasil Pengujian").
- `public/dataset.php`: kolom baru **"Dipakai Untuk"** (badge Train/Test/Belum
  dipakai) ditambahkan ke tabel, plus filter dropdown supaya baris data uji
  bisa dilihat/diverifikasi langsung dari menu Kelola Dataset juga.

**Model yang sudah dilatih SEBELUM update ini** belum menyimpan `test_detail`
(dan baris datanya belum ditandai `dipakai_untuk`) — halaman Hasil Pengujian
akan menampilkan pesan supaya Anda melatih ulang model tsb agar detail
pengujian per baris ikut tersimpan.

**Sudah diuji** end-to-end secara lokal (MariaDB + PHP built-in server): latih
KNN & Random Forest pada data ASLI skripsi (5.857 baris, batch "Data MBG"),
kolom `dipakai_untuk` berubah sesuai rasio split yang dipakai (mis. 80:20 →
4.686 train / 1.171 test), dan halaman Hasil Pengujian menampilkan 1.171 baris
data uji dengan jumlah "Prediksi Benar" + "Prediksi Salah" yang totalnya persis
sama dengan jumlah data uji tsb serta akurasi yang identik dengan riwayat
training.

## 14. Troubleshooting

- **"Koneksi database gagal"** → pastikan MySQL sudah running dan database
  `mbg_sentiment` sudah dibuat/diimpor.
- **Preprocessing/training lambat pada dataset besar** → tingkatkan nilai
  `max_execution_time` di `php.ini`, atau proses per batch lebih kecil.
- **Hasil akurasi rendah** → umumnya karena jumlah data training terlalu
  sedikit atau tidak seimbang antar kelas sentimen. Tambahkan lebih
  banyak data dan pastikan distribusi label cukup merata.
