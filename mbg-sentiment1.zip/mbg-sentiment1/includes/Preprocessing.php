<?php
require_once __DIR__ . '/StopwordList.php';
require_once __DIR__ . '/Stemmer.php';

/**
 * Class Preprocessing
 * Tahapan: Cleaning -> Case Folding -> Normalisasi -> Tokenizing
 *          -> Stopword Removal -> Stemming
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class Preprocessing
{
    private $stemmer;
    private $stopwords;
    private $kamusNormalisasi;

    public function __construct($db = null)
    {
        $this->stemmer  = new Stemmer();
        $this->stopwords = getStopwordList();
        $this->kamusNormalisasi = [];

        if ($db !== null) {
            $res = $db->query("SELECT kata_tidak_baku, kata_baku FROM kamus_normalisasi");
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $this->kamusNormalisasi[$row['kata_tidak_baku']] = $row['kata_baku'];
                }
            }
        }
    }

    /**
     * 1. Cleaning: hapus URL, mention, hashtag, angka, tanda baca, emoji,
     * dan kurangi huruf berulang berlebihan ("bagusss" -> "baguss", 3+ huruf
     * sama berturut-turut dipotong jadi 2, PERSIS regex Python-nya, bukan
     * dipotong jadi 1 huruf).
     * Urutan & regex disamakan persis dengan notebook Colab (subbab 4.3):
     *   re.sub(r"http\S+|www\S+", "", teks)
     *   re.sub(r"@\w+", "", teks)
     *   re.sub(r"#\w+", "", teks)
     *   re.sub(r"[0-9]+", "", teks)
     *   teks.translate(str.maketrans("", "", string.punctuation))
     *   re.sub("[emoji unicode ranges]", "", teks)
     *   re.sub(r"(.)\1{2,}", r"\1\1", teks)
     *   re.sub(r"\s+", " ", teks).strip()
     */
    public function cleaning($text)
    {
        $text = preg_replace('/https?:\/\/\S+|www\S+/', '', $text);   // URL (dgn/tanpa http)
        $text = preg_replace('/@\w+/', '', $text);                     // mention
        $text = preg_replace('/#\w+/', '', $text);                     // hashtag
        $text = preg_replace('/[0-9]+/', '', $text);                   // angka
        // tanda baca ASCII, setara string.punctuation di Python:
        // !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
        $punctuation = '!"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~';
        $text = preg_replace('/[' . preg_quote($punctuation, '/') . ']/', '', $text);
        // emoji: rentang unicode yang sama dengan notebook
        $text = preg_replace(
            '/[\x{1F600}-\x{1F64F}\x{1F300}-\x{1F5FF}\x{1F680}-\x{1F6FF}\x{1F1E0}-\x{1F1FF}\x{2700}-\x{27BF}\x{1F900}-\x{1F9FF}]+/u',
            '',
            $text
        );
        // kurangi huruf berulang >=3x jadi 2x (bagusss -> baguss, TIDAK jadi "bagus" -
        // regex (.)\1{2,} -> \1\1 mengurangi 3+ pengulangan jadi 2, persis notebook)
        $text = preg_replace('/(.)\1{2,}/u', '$1$1', $text);
        $text = preg_replace('/\s+/', ' ', $text);                     // spasi berlebih
        return trim($text);
    }

    /** 2. Case Folding: ubah ke huruf kecil */
    public function caseFolding($text)
    {
        return mb_strtolower($text);
    }

    /**
     * 3. Normalisasi kata tidak baku/singkatan.
     * PENTING: beroperasi di level TEKS (bukan token), lalu split ulang
     * dengan spasi. Ini disengaja karena ~96 entri kamus normalisasi
     * hasilnya MULTI-KATA (mis. 'ortu' -> 'orang tua', 'gausah' -> 'tidak
     * usah'). Kalau normalisasi dijalankan SETELAH tokenizing (per token),
     * hasil multi-kata itu nempel jadi SATU token ("orang tua" sebagai 1
     * elemen array, bukan 2 token terpisah), sehingga lolos dari stopword
     * removal dan hasilnya beda dari notebook Colab (yang normalisasi teks
     * dulu baru tokenizing).
     */
    public function normalizeText($text)
    {
        $kamus = $this->kamusNormalisasi;
        $words = explode(' ', $text);
        $words = array_map(function ($word) use ($kamus) {
            return ($word !== '' && isset($kamus[$word])) ? $kamus[$word] : $word;
        }, $words);
        return implode(' ', $words);
    }

    /**
     * @deprecated Beroperasi per-token (setelah tokenizing) - BISA salah untuk
     * entri kamus yang hasilnya multi-kata (lihat normalizeText()). Dipertahankan
     * untuk kompatibilitas kode lama; pipeline utama (process()) TIDAK memakai ini.
     */
    public function normalize($tokens)
    {
        $kamus = $this->kamusNormalisasi;
        return array_map(function ($token) use ($kamus) {
            return isset($kamus[$token]) ? $kamus[$token] : $token;
        }, $tokens);
    }

    /** 4. Tokenizing: pecah kalimat jadi kata */
    public function tokenize($text)
    {
        $tokens = explode(' ', $text);
        $tokens = array_filter($tokens, function ($t) {
            return trim($t) !== '';
        });
        return array_values($tokens);
    }

    /** 5. Stopword Removal (tanpa filter panjang kata minimum, persis notebook:
     *     [kata for kata in tokens if kata not in daftar_stopword]) */
    public function removeStopwords($tokens)
    {
        $stopwords = $this->stopwords;
        return array_values(array_filter($tokens, function ($token) use ($stopwords) {
            return !isset($stopwords[$token]);
        }));
    }

    /** 6. Stemming */
    public function stemTokens($tokens)
    {
        $stemmer = $this->stemmer;
        return array_map(function ($t) use ($stemmer) {
            return $stemmer->stem($t);
        }, $tokens);
    }

    /**
     * Jalankan seluruh pipeline preprocessing sekaligus.
     *
     * @param string $rawText
     * @param bool   $useStemming  Default FALSE agar sesuai dengan metodologi
     *                             skripsi (Tabel 3.4 Bab III & Bab IV): tahapan
     *                             yang dijalankan hanya cleaning -> case folding
     *                             -> normalisasi -> tokenizing -> stopword
     *                             removal, TANPA stemming. Set TRUE hanya jika
     *                             Anda memang ingin menambahkan stemming
     *                             (mis. untuk eksperimen tambahan/pengembangan).
     * Return array ['text' => hasil_string, 'tokens' => array_token]
     */
    public function process($rawText, $useStemming = false)
    {
        // Urutan PERSIS notebook Colab (subbab 4.3): case folding -> cleaning
        // -> normalisasi (di level teks) -> tokenizing -> stopword removal
        // (-> stemming opsional)
        $text = $this->caseFolding($rawText);
        $text = $this->cleaning($text);
        $text = $this->normalizeText($text);
        $tokens = $this->tokenize($text);
        $tokens = $this->removeStopwords($tokens);
        if ($useStemming) {
            $tokens = $this->stemTokens($tokens);
        }
        $tokens = array_values(array_filter($tokens, function ($t) {
            return trim($t) !== '';
        }));

        return [
            'text'   => implode(' ', $tokens),
            'tokens' => $tokens,
        ];
    }

    /**
     * Sama seperti process(), tapi juga mengembalikan setiap tahap
     * antara (untuk ditampilkan di halaman Hasil Pre-Processing).
     * Dipisah dari process() supaya halaman tampilan TIDAK PERLU lagi
     * menyusun ulang urutan pipeline sendiri (itu penyebab bug
     * sebelumnya: tampilan sempat menghitung tokenizing dari teks SEBELUM
     * normalisasi, jadi kata yang sudah dinormalisasi "balik" lagi ke
     * bentuk aslinya di kolom Tokenisasi).
     *
     * @return array{
     *   cleaning: string, case_folding: string, normalisasi: string,
     *   tokenize: array, stopword_removal: array, text: string, tokens: array
     * }
     */
    public function processWithTrace($rawText, $useStemming = false)
    {
        $caseFolding = $this->caseFolding($rawText);
        $cleaning = $this->cleaning($caseFolding);
        $normalisasi = $this->normalizeText($cleaning);
        $tokenize = $this->tokenize($normalisasi);
        $stopwordRemoval = $this->removeStopwords($tokenize);
        $tokens = $stopwordRemoval;
        if ($useStemming) {
            $tokens = $this->stemTokens($tokens);
        }
        $tokens = array_values(array_filter($tokens, function ($t) {
            return trim($t) !== '';
        }));

        return [
            'case_folding'     => $caseFolding,
            'cleaning'         => $cleaning,
            'normalisasi'      => $normalisasi,
            'tokenize'         => $tokenize,
            'stopword_removal' => $stopwordRemoval,
            'text'             => implode(' ', $tokens),
            'tokens'           => $tokens,
        ];
    }
}
