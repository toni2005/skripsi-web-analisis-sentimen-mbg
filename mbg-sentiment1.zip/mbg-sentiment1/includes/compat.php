<?php
/**
 * Polyfill agar kompatibel dengan PHP 5.6 dan PHP 7.x (bukan hanya 7.3+/8+).
 * array_key_first() baru tersedia mulai PHP 7.3, jadi didefinisikan manual
 * di sini kalau belum ada.
 */
if (!function_exists('array_key_first')) {
    function array_key_first($arr) {
        foreach ($arr as $key => $value) {
            return $key;
        }
        return null;
    }
}

/**
 * BUG FIX: mysqli_stmt::get_result() hanya tersedia kalau ekstensi PHP
 * dikompilasi dengan driver mysqlnd. Sebagian hosting murah/lama (termasuk
 * beberapa paket shared hosting PHP 5.6/7.x) masih memakai libmysqlclient
 * tanpa mysqlnd, sehingga get_result() akan gagal dengan fatal error
 * "Call to undefined method mysqli_stmt::get_result()".
 *
 * Fungsi ini otomatis memakai get_result() kalau tersedia, dan kalau tidak
 * akan fallback ke bind_result()+fetch() manual (selalu tersedia di semua
 * instalasi mysqli). Hasilnya SELALU berupa array asosiatif (bukan objek
 * mysqli_result), supaya konsisten dipakai di kedua kondisi.
 *
 * @return array daftar baris (masing-masing array asosiatif kolom => nilai)
 */
function stmtFetchAll($stmt) {
    if (method_exists($stmt, 'get_result')) {
        $result = $stmt->get_result();
        $rows = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
        }
        return $rows;
    }

    // Fallback tanpa mysqlnd: ambil nama kolom dari metadata, lalu bind_result manual.
    $meta = $stmt->result_metadata();
    if (!$meta) return [];

    $fields = [];
    $bindVars = [];
    while ($field = $meta->fetch_field()) {
        $fields[] = $field->name;
    }
    $rowBuffer = array_fill(0, count($fields), null);
    foreach ($rowBuffer as $i => $v) {
        $bindVars[$i] = &$rowBuffer[$i];
    }
    call_user_func_array([$stmt, 'bind_result'], $bindVars);

    $rows = [];
    while ($stmt->fetch()) {
        $row = [];
        foreach ($fields as $i => $name) {
            $row[$name] = $rowBuffer[$i];
        }
        $rows[] = $row;
    }
    return $rows;
}
