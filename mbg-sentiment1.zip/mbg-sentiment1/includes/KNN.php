<?php
require_once __DIR__ . '/compat.php';
/**
 * Class KNN (K-Nearest Neighbor)
 * Menggunakan cosine similarity / euclidean distance pada vektor TF-IDF
 *
 * Kompatibel PHP 5.6 & 7.x (tanpa type hint/typed property/arrow function
 * yang baru tersedia di PHP 7.4+/8+).
 */
class KNN
{
    private $trainVectors = [];
    private $trainLabels = [];
    private $k;
    private $metric; // 'euclidean' atau 'cosine'

    public function __construct($k = 5, $metric = 'euclidean')
    {
        $this->k = $k;
        $this->metric = $metric;
    }

    public function fit($vectors, $labels)
    {
        $this->trainVectors = $vectors;
        $this->trainLabels = $labels;
    }

    /**
     * PENTING: $a dan $b sekarang berupa vektor SPARSE (associative array
     * `index => nilai`, hanya untuk entri bukan-nol). Sebelumnya kode ini
     * memakai count($a) + akses $a[$i] berurutan yang mengasumsikan vektor
     * PADAT (semua index 0..n-1 ada) — itu salah/rawan bug untuk vektor
     * sparse (count() jadi cuma menghitung entri bukan-nol, bukan dimensi
     * penuh). Sekarang jarak dihitung dari GABUNGAN (union) key yang ada di
     * $a ATAU $b saja — key yang tidak ada di sparse vector otomatis
     * dianggap 0, hasilnya identik dengan menghitung pada vektor padat.
     */
    private function euclideanDistance($a, $b)
    {
        $sum = 0.0;
        $keys = array_keys($a + $b); // union index yang bernilai bukan-nol di salah satu vektor
        foreach ($keys as $i) {
            $ai = isset($a[$i]) ? $a[$i] : 0.0;
            $bi = isset($b[$i]) ? $b[$i] : 0.0;
            $diff = $ai - $bi;
            $sum += $diff * $diff;
        }
        return sqrt($sum);
    }

    private function cosineDistance($a, $b)
    {
        $dot = 0.0; $normA = 0.0; $normB = 0.0;
        // dot product cukup dihitung dari key yang ada di KEDUA vektor (irisan);
        // key yang hanya ada di salah satu tidak menyumbang ke dot product (x*0=0)
        foreach ($a as $i => $ai) {
            $normA += $ai * $ai;
            if (isset($b[$i])) {
                $dot += $ai * $b[$i];
            }
        }
        foreach ($b as $bi) {
            $normB += $bi * $bi;
        }
        if ($normA == 0 || $normB == 0) return 1.0;
        $cosineSim = $dot / (sqrt($normA) * sqrt($normB));
        return 1 - $cosineSim; // distance = 1 - similarity
    }

    /** Prediksi label untuk satu vektor input */
    public function predict($inputVector)
    {
        $distances = [];

        foreach ($this->trainVectors as $i => $vec) {
            $dist = $this->metric === 'cosine'
                ? $this->cosineDistance($inputVector, $vec)
                : $this->euclideanDistance($inputVector, $vec);
            $distances[] = ['distance' => $dist, 'label' => $this->trainLabels[$i]];
        }

        // BUG FIX: operator spaceship (<=>) baru ada di PHP 7.0, tidak jalan
        // di PHP 5.6 - diganti perbandingan eksplisit agar kompatibel.
        usort($distances, function ($a, $b) {
            if ($a['distance'] == $b['distance']) return 0;
            return ($a['distance'] < $b['distance']) ? -1 : 1;
        });
        $nearest = array_slice($distances, 0, $this->k);

        $votes = [];
        foreach ($nearest as $n) {
            $votes[$n['label']] = (isset($votes[$n['label']]) ? $votes[$n['label']] : 0) + 1;
        }
        arsort($votes);
        return array_key_first($votes);
    }

    /** Prediksi banyak data sekaligus */
    public function predictBatch($vectors)
    {
        $self = $this;
        return array_map(function ($v) use ($self) {
            return $self->predict($v);
        }, $vectors);
    }

    public function export()
    {
        return [
            'k' => $this->k,
            'metric' => $this->metric,
            'trainVectors' => $this->trainVectors,
            'trainLabels' => $this->trainLabels,
        ];
    }

    public function loadFromArray($data)
    {
        $this->k = $data['k'];
        $this->metric = $data['metric'];
        $this->trainVectors = $data['trainVectors'];
        $this->trainLabels = $data['trainLabels'];
    }
}
