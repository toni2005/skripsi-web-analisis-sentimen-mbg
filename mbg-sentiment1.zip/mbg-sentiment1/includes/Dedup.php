<?php
require_once __DIR__ . '/compat.php';

/**
 * FITUR: Penghapusan duplikat otomatis.
 *
 * Data mentah hasil scraping (terutama dari sosial media) sering mengandung
 * baris duplikat -- komentar yang sama persis ter-scrape lebih dari sekali.
 * Fungsi ini mendeteksi baris dengan `teks_asli` IDENTIK (setelah di-trim
 * spasi) di dalam batch yang sama, menyisakan HANYA baris pertama (id
 * terkecil / paling awal masuk), dan menghapus sisanya.
 *
 * PENTING: dedup dilakukan PER BATCH, bukan lintas batch. Kalau komentar
 * yang sama muncul di dua batch berbeda (mis. "scraping_juli" vs
 * "scraping_agustus"), keduanya tetap dianggap data terpisah -- supaya
 * setiap sesi upload/eksperimen tetap terisolasi dan tidak ada data dari
 * batch lain yang "hilang" tanpa sadar.
 *
 * Dipanggil otomatis setiap kali halaman Preprocessing / Hasil
 * Pre-Processing dibuka (lihat preprocessing.php & preprocessing_result.php),
 * jadi TIDAK perlu menunggu tombol "Jalankan Preprocessing" / "Proses Ulang"
 * diklik -- termasuk untuk batch yang statusnya sudah 100% "Selesai".
 *
 * @param mysqli      $db
 * @param string|null $batch  Kalau diisi, dedup hanya dijalankan untuk batch
 *                            ini saja. Kalau null, dedup dijalankan untuk
 *                            SEMUA batch (masing-masing tetap terisolasi
 *                            per batch, hanya loop-nya yang mencakup semua).
 * @return int  Jumlah baris duplikat yang dihapus.
 */
function autoRemoveDuplicates(mysqli $db, $batch = null) {
    if ($batch !== null) {
        $stmt = $db->prepare("SELECT id, teks_asli FROM dataset WHERE dataset_batch = ? ORDER BY id ASC");
        $stmt->bind_param('s', $batch);
        $stmt->execute();
        $rows = stmtFetchAll($stmt);
        return removeDuplicateIdsFromRows($db, $rows);
    }

    // Tanpa batch spesifik: proses semua batch yang ada, tapi tetap
    // dikelompokkan per batch (bukan dibandingkan lintas batch).
    $result = $db->query("SELECT id, teks_asli, dataset_batch FROM dataset ORDER BY dataset_batch ASC, id ASC");
    $rowsByBatch = [];
    if ($result) {
        while ($r = $result->fetch_assoc()) {
            $rowsByBatch[$r['dataset_batch']][] = $r;
        }
    }

    $totalRemoved = 0;
    foreach ($rowsByBatch as $batchRows) {
        $totalRemoved += removeDuplicateIdsFromRows($db, $batchRows);
    }
    return $totalRemoved;
}

/**
 * Helper internal: dari sekumpulan baris (id, teks_asli) yang SUDAH terurut
 * per batch, tentukan mana yang duplikat lalu hapus dari database.
 */
function removeDuplicateIdsFromRows(mysqli $db, array $rows) {
    $seenTeks = [];
    $duplicateIds = [];
    foreach ($rows as $r) {
        $key = trim($r['teks_asli']);
        if (isset($seenTeks[$key])) {
            $duplicateIds[] = (int)$r['id'];
        } else {
            $seenTeks[$key] = true;
        }
    }

    if (empty($duplicateIds)) {
        return 0;
    }

    $removed = 0;
    foreach (array_chunk($duplicateIds, 500) as $chunk) {
        $placeholders = implode(',', array_fill(0, count($chunk), '?'));
        $types = str_repeat('i', count($chunk));
        $delStmt = $db->prepare("DELETE FROM dataset WHERE id IN ($placeholders)");
        $delStmt->bind_param($types, ...$chunk);
        $delStmt->execute();
        $removed += $delStmt->affected_rows;
    }
    return $removed;
}
