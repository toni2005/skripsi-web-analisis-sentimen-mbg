<?php
require_once __DIR__ . '/compat.php';

/**
 * Class DecisionTree
 * Implementasi sederhana CART (Classification and Regression Tree)
 * menggunakan Gini Impurity, dipakai sebagai base learner Random Forest.
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class DecisionTree
{
    private $tree = null;
    private $maxDepth;
    private $minSamplesSplit;
    private $minSamplesLeaf; // regularisasi: tolak split yang bikin salah satu sisi < N sampel
    private $maxSplitSample; // batas jumlah baris yang dipakai utk CARI split (lihat findBestSplit)
    private $numFeatures;      // total dimensi vocabulary (utk random subspace SEGAR per node)
    private $featuresPerSplit; // jumlah fitur acak yang diundang ULANG di SETIAP node (bukan sekali per pohon)

    // Data bootstrap yang dipakai tree ini (referensi, indeks lokal 0..n-1)
    private $X;
    private $y;

    /**
     * PERBAIKAN PERFORMA (v5) - INDEKS KOLOM SPARSE: dibangun SEKALI di
     * fit(), bukan diulang untuk tiap node/tiap fitur seperti versi lama.
     * Untuk tiap indeks fitur, simpan HANYA baris yang nilainya BUKAN NOL
     * (rowIdx lokal => value). Data TF-IDF sangat sparse (satu dokumen
     * biasanya cuma memuat puluhan kata dari total ribuan kolom
     * vocabulary), jadi indeks ini jauh lebih kecil daripada matriks
     * penuh n x fitur. Manfaatnya dipakai di findBestSplit():
     *  (a) fitur yang nilainya NOL di SEMUA baris node bisa dilewati
     *      langsung O(1) (dulu tetap discan penuh O(n) walau hasilnya
     *      pasti tidak mengubah gini sama sekali),
     *  (b) untuk fitur yang tidak nol, HANYA nilai non-nol yang perlu
     *      diurut & disapu satu-satu (biasanya jauh < n), sedangkan semua
     *      baris bernilai nol diperlakukan sebagai SATU blok di sisi kiri
     *      (valid karena TF-IDF selalu >= 0, sehingga 0 selalu jadi nilai
     *      terkecil) — bukan aproksimasi, hasil split yang ditemukan
     *      identik secara matematis dengan menyapu semua n baris satu per
     *      satu, cuma jauh lebih sedikit pekerjaan.
     * Index array indices) — dulu setiap split menyalin penuh sub-array
     * X/y ke kiri/kanan; walau PHP copy-on-write meringankan biaya memori,
     * overhead pembangunan array tetap O(n) per node. Sekarang cukup
     * menyalin daftar INDEKS baris (integer), jauh lebih ringan.
     */
    public function __construct($maxDepth = 10, $minSamplesSplit = 2, $maxSplitSample = 2000, $minSamplesLeaf = 5)
    {
        $this->maxDepth = $maxDepth;
        $this->minSamplesSplit = $minSamplesSplit;
        $this->maxSplitSample = $maxSplitSample;
        $this->minSamplesLeaf = $minSamplesLeaf;
    }

    /**
     * @param array    $X               kumpulan vektor fitur — SPARSE (index=>nilai,
     *                                  hanya entri bukan-nol; key tak ada = 0).
     * @param array    $y               kumpulan label
     * @param int      $numFeatures     total dimensi vocabulary (WAJIB, karena vektor
     *                                  sparse tidak bisa dipakai menebak total dimensi).
     * @param int|null $featuresPerSplit jumlah fitur acak yang dicoba di SETIAP node
     *                                  (random subspace) — diundang ULANG tiap kali
     *                                  cari split baru, BUKAN sekali untuk seluruh pohon.
     *                                  null = pakai semua fitur di setiap node (setara
     *                                  decision tree biasa tanpa random subspace).
     */
    public function fit($X, $y, $numFeatures, $featuresPerSplit = null)
    {
        $this->numFeatures = $numFeatures;
        $this->featuresPerSplit = $featuresPerSplit !== null ? $featuresPerSplit : $numFeatures;
        $this->X = $X;
        $this->y = $y;

        $this->featureIndex = array_fill(0, $numFeatures, null);
        foreach ($X as $i => $row) {
            foreach ($row as $f => $v) {
                if ($v == 0.0) continue;
                if ($this->featureIndex[$f] === null) $this->featureIndex[$f] = array();
                $this->featureIndex[$f][$i] = $v;
            }
        }

        $allIdx = range(0, count($X) - 1);
        $this->tree = $this->buildTree($allIdx, 0);
    }
    private $featureIndex;

    /** Undang subset fitur acak yang BARU (dipanggil di SETIAP node, bukan sekali per pohon) */
    private function randomFeatureSubset()
    {
        $all = range(0, $this->numFeatures - 1);
        shuffle($all);
        return array_slice($all, 0, min($this->featuresPerSplit, $this->numFeatures));
    }

    private function giniImpurity($y)
    {
        $total = count($y);
        if ($total === 0) return 0;
        $counts = array_count_values($y);
        $impurity = 1.0;
        foreach ($counts as $c) {
            $p = $c / $total;
            $impurity -= $p * $p;
        }
        return $impurity;
    }

    private function majorityLabel($y)
    {
        $counts = array_count_values($y);
        arsort($counts);
        return array_key_first($counts);
    }

    /** Sama seperti majorityLabel() tapi juga mengembalikan rincian jumlah tiap kelas (untuk diagnostik) */
    private function majorityLabelWithCounts($y)
    {
        $counts = array_count_values($y);
        arsort($counts);
        return array('label' => array_key_first($counts), 'counts' => $counts, 'n' => count($y));
    }

    /**
     * @param array $idx daftar INDEKS baris lokal (bukan lagi array X/y penuh — lihat
     *              catatan performa v5 di atas konstruktor)
     */
    private function buildTree($idx, $depth)
    {
        $numSamples = count($idx);
        $ySub = array();
        foreach ($idx as $i) $ySub[] = $this->y[$i];
        $uniqueLabels = array_unique($ySub);

        // Kondisi berhenti (leaf node)
        if (count($uniqueLabels) === 1 || $depth >= $this->maxDepth || $numSamples < $this->minSamplesSplit) {
            $m = $this->majorityLabelWithCounts($ySub);
            return array('leaf' => true, 'label' => $m['label'], 'label_counts' => $m['counts'], 'n' => $m['n']);
        }

        // PENTING: subset fitur acak yang SEGAR untuk node ini saja — bukan
        // diwariskan tetap dari root.
        $featureSubsetIdx = $this->randomFeatureSubset();
        $best = $this->findBestSplit($idx, $ySub, $featureSubsetIdx);

        if ($best === null) {
            $m = $this->majorityLabelWithCounts($ySub);
            return array('leaf' => true, 'label' => $m['label'], 'label_counts' => $m['counts'], 'n' => $m['n']);
        }

        list($leftIdx, $rightIdx) = $this->splitIdx($idx, $best['feature'], $best['threshold']);

        if (count($leftIdx) === 0 || count($rightIdx) === 0) {
            $m = $this->majorityLabelWithCounts($ySub);
            return array('leaf' => true, 'label' => $m['label'], 'label_counts' => $m['counts'], 'n' => $m['n']);
        }

        return array(
            'leaf' => false,
            'feature' => $best['feature'],
            'threshold' => $best['threshold'],
            'left' => $this->buildTree($leftIdx, $depth + 1),
            'right' => $this->buildTree($rightIdx, $depth + 1),
        );
    }

    /**
     * PERBAIKAN PERFORMA (v5) — lihat catatan panjang di konstruktor.
     * $idx = daftar indeks baris lokal milik node ini; $ySub = label-nya
     * (urutan sejajar dengan $idx). Untuk tiap fitur kandidat, dipakai
     * indeks kolom sparse ($this->featureIndex) supaya HANYA nilai
     * non-nol yang diurut & disapu — fitur yang nol total di node ini
     * dilewati dalam O(1).
     */
    private function findBestSplit($idx, $ySub, $featureSubsetIdx)
    {
        $bestGini = 999;
        $bestFeature = null;
        $bestThreshold = null;
        $parentGini = $this->giniImpurity($ySub);
        $n = count($idx);
        if ($n < 2) return null;

        // Jaminan waktu terbatas: subsample node yang terlalu besar (root
        // setelah SMOTE bisa puluhan ribu baris) — sama seperti versi lama,
        // hanya sekarang beroperasi di atas INDEKS, bukan array baris penuh.
        if ($n > $this->maxSplitSample) {
            $keys = array_rand($idx, $this->maxSplitSample);
            if (!is_array($keys)) $keys = array($keys);
            $sIdx = array(); $sY = array();
            foreach ($keys as $k) { $sIdx[] = $idx[$k]; $sY[] = $ySub[$k]; }
            $idx = $sIdx; $ySub = $sY;
            $n = count($idx);
        }

        $totalCounts = array_count_values($ySub);
        $idxSet = array_flip($idx); // rowIdx lokal => posisi, dipakai cek keanggotaan cepat

        foreach ($featureSubsetIdx as $featureIdx) {
            $col = $this->featureIndex[$featureIdx];
            if ($col === null) continue; // fitur nol di SELURUH data bootstrap -> tak mungkin memisahkan apa pun

            // Ambil pasangan (rowIdx, value) yang non-nol DAN ada di node ini.
            // Iterasi struktur yang lebih PENDEK (kolom sparse fitur ini, atau
            // daftar baris node) supaya biaya irisan minimal.
            $nz = array();
            if (count($col) <= $n) {
                foreach ($col as $rowIdx => $v) {
                    if (isset($idxSet[$rowIdx])) $nz[$rowIdx] = $v;
                }
            } else {
                foreach ($idx as $rowIdx) {
                    if (isset($col[$rowIdx])) $nz[$rowIdx] = $col[$rowIdx];
                }
            }

            $nzCount = count($nz);
            if ($nzCount === 0) continue; // fitur nol total di NODE ini -> tak ada split dari fitur ini
            $zeroCount = $n - $nzCount;

            asort($nz); // urut ascending berdasar value, key = rowIdx asli dipertahankan

            // Distribusi label pada bagian non-nol, lalu distribusi nol = total - non-nol
            $nonzeroLabelCounts = array();
            foreach (array_keys($nz) as $rowIdx) {
                $lbl = $this->y[$rowIdx];
                $nonzeroLabelCounts[$lbl] = (isset($nonzeroLabelCounts[$lbl]) ? $nonzeroLabelCounts[$lbl] : 0) + 1;
            }
            $zeroLabelCounts = $totalCounts;
            foreach ($nonzeroLabelCounts as $lbl => $c) {
                $zeroLabelCounts[$lbl] = (isset($zeroLabelCounts[$lbl]) ? $zeroLabelCounts[$lbl] : 0) - $c;
                if ($zeroLabelCounts[$lbl] <= 0) unset($zeroLabelCounts[$lbl]);
            }

            $leftCounts = $zeroLabelCounts;
            $leftTotal = $zeroCount;
            $rightCounts = $nonzeroLabelCounts;
            $rightTotal = $nzCount;

            $sortedRowIdx = array_keys($nz);
            $sortedVals = array_values($nz);

            // Titik split pertama: batas antara blok NOL (kiri) dan nilai
            // non-nol terkecil (kanan) — hanya valid kalau ada baris nol.
            if ($zeroCount > 0 && $leftTotal >= $this->minSamplesLeaf && $rightTotal >= $this->minSamplesLeaf) {
                $giniLeft = $this->giniFromCounts($leftCounts, $leftTotal);
                $giniRight = $this->giniFromCounts($rightCounts, $rightTotal);
                $giniSplit = ($leftTotal / $n) * $giniLeft + ($rightTotal / $n) * $giniRight;
                if ($giniSplit < $bestGini) {
                    $bestGini = $giniSplit;
                    $bestFeature = $featureIdx;
                    $bestThreshold = $sortedVals[0] / 2; // titik tengah antara 0 dan nilai terkecil
                }
            }

            // Sapu sisanya: geser satu per satu nilai NON-NOL dari kanan ke kiri
            for ($k = 0; $k < $nzCount - 1; $k++) {
                $rowIdx = $sortedRowIdx[$k];
                $lbl = $this->y[$rowIdx];
                $leftCounts[$lbl] = (isset($leftCounts[$lbl]) ? $leftCounts[$lbl] : 0) + 1;
                $rightCounts[$lbl] -= 1;
                $leftTotal++;
                $rightTotal--;

                $curVal = $sortedVals[$k];
                $nextVal = $sortedVals[$k + 1];
                if ($curVal == $nextVal) continue;

                if ($leftTotal < $this->minSamplesLeaf || $rightTotal < $this->minSamplesLeaf) continue;

                $giniLeft = $this->giniFromCounts($leftCounts, $leftTotal);
                $giniRight = $this->giniFromCounts($rightCounts, $rightTotal);
                $giniSplit = ($leftTotal / $n) * $giniLeft + ($rightTotal / $n) * $giniRight;

                if ($giniSplit < $bestGini) {
                    $bestGini = $giniSplit;
                    $bestFeature = $featureIdx;
                    $bestThreshold = ($curVal + $nextVal) / 2;
                }
            }
        }

        if ($bestFeature === null || $bestGini >= $parentGini) {
            return null;
        }

        return array('feature' => $bestFeature, 'threshold' => $bestThreshold, 'gini' => $bestGini);
    }

    /** Gini impurity dari peta jumlah label (bukan dari array label mentah) — dipakai di sweep incremental */
    private function giniFromCounts($counts, $total)
    {
        if ($total <= 0) return 0;
        $impurity = 1.0;
        foreach ($counts as $c) {
            if ($c <= 0) continue;
            $p = $c / $total;
            $impurity -= $p * $p;
        }
        return $impurity;
    }

    /**
     * PERBAIKAN PERFORMA (v5): dulu bernama splitDataset(), menyalin penuh
     * array baris X/y ke kiri/kanan. Sekarang cukup memilah daftar INDEKS
     * baris — jauh lebih ringan, dan konsisten dengan representasi
     * berbasis indeks yang dipakai buildTree()/findBestSplit().
     */
    private function splitIdx($idx, $featureIdx, $threshold)
    {
        $col = $this->featureIndex[$featureIdx];
        $leftIdx = array();
        $rightIdx = array();
        foreach ($idx as $rowIdx) {
            $val = ($col !== null && isset($col[$rowIdx])) ? $col[$rowIdx] : 0.0;
            if ($val <= $threshold) {
                $leftIdx[] = $rowIdx;
            } else {
                $rightIdx[] = $rowIdx;
            }
        }
        return array($leftIdx, $rightIdx);
    }

    public function predict($x)
    {
        $node = $this->tree;
        while (!$node['leaf']) {
            $val = isset($x[$node['feature']]) ? $x[$node['feature']] : 0.0; // sparse: key tak ada = 0
            $node = ($val <= $node['threshold']) ? $node['left'] : $node['right'];
        }
        return $node['label'];
    }

    /**
     * DIAGNOSTIK: sama seperti predict(), tapi merekam SETIAP langkah
     * (fitur yang dicek, nilai x pada fitur itu, threshold, arah yang
     * diambil) sampai ke leaf, plus rincian isi leaf akhirnya (label_counts).
     * Dipakai untuk melacak KENAPA suatu dokumen uji berakhir di leaf
     * tertentu — terutama kalau dicurigai banyak dokumen berbeda-beda
     * selalu berakhir di leaf yang SAMA (indikasi split tidak informatif
     * untuk data uji nyata, meski split-nya sendiri "valid" secara gini).
     */
    public function predictTrace($x)
    {
        $node = $this->tree;
        $path = array();
        while (!$node['leaf']) {
            $val = isset($x[$node['feature']]) ? $x[$node['feature']] : 0.0;
            $goLeft = $val <= $node['threshold'];
            $path[] = array(
                'feature' => $node['feature'],
                'x_value' => $val,
                'threshold' => $node['threshold'],
                'direction' => $goLeft ? 'LEFT (<=)' : 'RIGHT (>)',
            );
            $node = $goLeft ? $node['left'] : $node['right'];
        }
        return array(
            'depth_reached' => count($path),
            'path' => $path,
            'leaf_label' => $node['label'],
            'leaf_label_counts' => isset($node['label_counts']) ? $node['label_counts'] : null,
            'leaf_n' => isset($node['n']) ? $node['n'] : null,
        );
    }

    public function getTree()
    {
        return $this->tree;
    }

    public function loadTree($tree)
    {
        $this->tree = $tree;
    }
}
