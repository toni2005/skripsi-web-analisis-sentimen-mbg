<?php
/**
 * Simple Indonesian Stemmer
 * Implementasi ringkas berbasis aturan Nazief-Adriani (disederhanakan)
 * Menghilangkan imbuhan: partikel, kata ganti kepunyaan, awalan, akhiran
 *
 * Catatan: ini adalah stemmer ringan buatan sendiri (tanpa dependency
 * eksternal) agar sistem tetap 100% berjalan native di PHP/XAMPP.
 */

class Stemmer
{
    private $prefixes1 = ['di','ke','se'];
    private $prefixes2 = ['me','be','pe','te'];
    private $suffixesParticle = ['lah','kah','tah','pun'];
    private $suffixesPossessive = ['ku','mu','nya'];
    private $suffixesDerivation = ['kan','an','i'];

    /**
     * Kamus kata dasar yang dilindungi dari proses stripping.
     * BUG FIX: stemmer versi awal tidak melakukan pengecekan kamus sama
     * sekali (murni potong imbuhan berbasis pola huruf), sehingga banyak
     * kata dasar asli/serapan ikut terpotong salah, contoh sebelum
     * diperbaiki: "sehat" -> "hat", "senang" -> "nang", "sekolah" -> "seko",
     * "distribusi" -> "stribus", "menjadi" -> "jad" (seharusnya "jadi").
     * Daftar di bawah dicek LEBIH DULU sebelum aturan potong imbuhan
     * dijalankan, mirip prinsip dictionary lookup pada algoritma
     * Nazief-Adriani/Sastrawi yang sesungguhnya.
     */
    private $protectedWords = [
        'sehat','senang','sedang','semangat','seperti','sekali','sekolah','selalu','sebentar',
        'setiap','sesuai','segera','sempat','semua','sebagian','sebaik','sekitar','serius',
        'kepala','kemarin','ketika','kenapa','kesan','kecewa','kelas','kelompok','kental',
        'perlu','pernah','pertama','penting','pelajar','pelayanan','pedas','peduli','petugas',
        'terima','tertarik','teratur','terlalu','tersebut','terus','teman','tepat','telat',
        'berikut','beberapa','berbeda','berbagai','bermanfaat','bergizi','berat','beras',
        'menu','media','makanan','minuman','manfaat','murah','mahal','mudah','miskin',
        'distribusi','kualitas','program','porsi','gizi','jadwal','jadi','anggaran','anggota',
        'reaksi','kondisi','situasi','organisasi','administrasi','konsumsi','komposisi',
        'nasi','lauk','sayur','buah','susu','telur','ayam','ikan','roti','snack',
        'siswa','murid','guru','sekolahan','anak','orangtua','wali','pemerintah','daerah',
        'gratis','layak','bersih','higienis','segar','basi','busuk','dingin','hangat',
    ];

    /**
     * BUG FIX (lanjutan): beberapa kata berimbuhan umum yang sering muncul
     * pada komentar/opini publik masih salah distem lewat aturan generik di
     * atas (mis. "menjadi" -> "njad" karena prefiks "men" gagal syarat
     * panjang lalu jatuh ke prefiks pendek "me"). Kata-kata frekuensi
     * tinggi ini dipetakan langsung ke bentuk dasarnya sebagai pengecualian,
     * dicek sebelum aturan potong imbuhan generik dijalankan.
     */
    private $exceptions = [
        'menjadi' => 'jadi', 'dijadikan' => 'jadi', 'kejadian' => 'jadi',
        'dimakan' => 'makan', 'memakan' => 'makan', 'dimakannya' => 'makan',
        'diberikan' => 'beri', 'memberikan' => 'beri', 'pemberian' => 'beri',
        'diterima' => 'terima', 'menerima' => 'terima', 'penerimaan' => 'terima',
        'kekurangan' => 'kurang', 'mengurangi' => 'kurang', 'dikurangi' => 'kurang',
        'kelebihan' => 'lebih', 'melebihi' => 'lebih',
        'kebersihan' => 'bersih', 'membersihkan' => 'bersih',
        'keamanan' => 'aman', 'mengamankan' => 'aman',
        'kesehatan' => 'sehat', 'menyehatkan' => 'sehat',
        'perbaikan' => 'baik', 'memperbaiki' => 'baik', 'diperbaiki' => 'baik',
        'meningkatkan' => 'tingkat', 'peningkatan' => 'tingkat', 'ditingkatkan' => 'tingkat',
        'menurunkan' => 'turun', 'penurunan' => 'turun',
        'membagikan' => 'bagi', 'pembagian' => 'bagi', 'dibagikan' => 'bagi',
        'disediakan' => 'sedia', 'menyediakan' => 'sedia', 'ketersediaan' => 'sedia',
        'menunjukkan' => 'tunjuk', 'ditunjukkan' => 'tunjuk',
        'kesekolah' => 'sekolah', 'disekolah' => 'sekolah', 'persekolahan' => 'sekolah',
        'memasak' => 'masak', 'dimasak' => 'masak', 'memasaknya' => 'masak',
        'berjalan' => 'jalan', 'menjalankan' => 'jalan', 'dijalankan' => 'jalan',
    ];

    public function stem($word)
    {
        $word = strtolower(trim($word));
        if (mb_strlen($word) <= 3) {
            return $word;
        }

        // 0. BUG FIX: cek kamus kata dilindungi terlebih dahulu, jangan
        //    dipotong sama sekali kalau memang sudah kata dasar yang dikenal.
        if (in_array($word, $this->protectedWords, true)) {
            return $word;
        }

        // 0b. BUG FIX: cek kamus pengecualian kata berimbuhan frekuensi
        //     tinggi yang salah jika hanya mengandalkan aturan generik.
        if (isset($this->exceptions[$word])) {
            return $this->exceptions[$word];
        }

        $original = $word;

        // 1. Hilangkan partikel (lah, kah, tah, pun)
        $word = $this->removeSuffixGroup($word, $this->suffixesParticle);

        // 2. Hilangkan kata ganti kepunyaan (ku, mu, nya)
        $word = $this->removeSuffixGroup($word, $this->suffixesPossessive);

        // 3. Hilangkan akhiran turunan (kan, an, i)
        $word = $this->removeSuffixGroup($word, $this->suffixesDerivation);

        // BUG FIX: setelah imbuhan akhiran dihilangkan, cek ulang ke kamus
        // sebelum lanjut memotong awalan (mencegah pemotongan berlebihan
        // seperti pada kasus "menjadi" -> "menjad" -> "jad").
        if (in_array($word, $this->protectedWords, true)) {
            return $word;
        }

        // 4. Hilangkan awalan (maks 2 lapis: contoh "memper-", "diper-")
        $word = $this->removePrefix($word);
        $word = $this->removePrefix($word);

        // Jaga-jaga: jika hasil terlalu pendek/aneh, kembalikan kata asli
        // BUG FIX: batas minimum dinaikkan dari 3 -> 4 karakter untuk
        // mengurangi hasil stemming yang terlalu agresif/tidak bermakna.
        if (mb_strlen($word) < 4) {
            return $original;
        }

        return $word;
    }

    private function removeSuffixGroup($word, $suffixes)
    {
        foreach ($suffixes as $suf) {
            $len = mb_strlen($suf);
            // BUG FIX: syarat sisa huruf dinaikkan dari >=3 menjadi >=4
            // supaya kata pendek seperti "sekolah" tidak terlanjur salah
            // terpotong jadi "seko" akibat dikira akhiran partikel "-lah".
            if (mb_substr($word, -$len) === $suf && mb_strlen($word) - $len >= 4) {
                return mb_substr($word, 0, -$len);
            }
        }
        return $word;
    }

    private function removePrefix($word)
    {
        $rules = [
            // prefix => panjang huruf yang dihapus
            'mempe' => 5, 'memper' => 6,
            'meng'  => 4, 'meny'  => 4, 'menge' => 5, 'men'   => 3, 'mem'   => 3,
            'peng'  => 4, 'peny'  => 4, 'penge' => 5, 'pen'   => 3, 'pem'   => 3, 'per'   => 3,
            'diper' => 5,
            'terke' => 5, 'ter'   => 3,
            'berke' => 5, 'ber'   => 3,
        ];
        // BUG FIX: prefiks generik 2 huruf (me, pe, be, di, ke, se) disyaratkan
        // sisa >=5 huruf (bukan >=4 seperti prefiks yang lebih spesifik).
        // Sebelumnya, ketika varian yang lebih spesifik (mis. "men") gagal
        // memenuhi syarat panjang, kode tetap lanjut mencoba prefiks pendek
        // "me" dengan syarat yang sama longgarnya, menghasilkan pemotongan
        // ganda yang salah, contoh: "menjadi" -> "menjad" -> "njad".
        $shortRules = ['me' => 2, 'pe' => 2, 'be' => 2, 'di' => 2, 'ke' => 2, 'se' => 2];

        foreach ($rules as $prefix => $len) {
            if (mb_substr($word, 0, mb_strlen($prefix)) === $prefix && mb_strlen($word) - mb_strlen($prefix) >= 4) {
                return mb_substr($word, mb_strlen($prefix));
            }
        }
        foreach ($shortRules as $prefix => $len) {
            if (mb_substr($word, 0, mb_strlen($prefix)) === $prefix && mb_strlen($word) - mb_strlen($prefix) >= 5) {
                return mb_substr($word, mb_strlen($prefix));
            }
        }
        return $word;
    }
}
