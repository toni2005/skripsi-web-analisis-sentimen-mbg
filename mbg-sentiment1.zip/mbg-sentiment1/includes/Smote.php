<?php
/**
 * Class Smote
 * Implementasi SMOTE (Synthetic Minority Over-sampling Technique) sederhana,
 * native PHP, untuk menyeimbangkan distribusi kelas pada data LATIH sebelum
 * training (sesuai metodologi skripsi: SMOTE diterapkan hanya pada data
 * latih hasil split, data uji tetap asli/tidak diubah).
 *
 * Cara kerja (sama seperti imbalanced-learn SMOTE pada umumnya):
 * 1. Untuk tiap kelas minoritas, hitung berapa banyak sampel sintetis yang
 *    perlu dibuat agar jumlahnya menyamai kelas mayoritas.
 * 2. Untuk tiap sampel baru: ambil satu sampel acak dari kelas tsb, cari
 *    k tetangga terdekat (di dalam kelas yang sama) berdasarkan jarak
 *    Euclidean pada vektor TF-IDF, pilih salah satu tetangga secara acak,
 *    lalu buat sampel baru dengan interpolasi linear antara sampel asal
 *    dan tetangga tersebut (gap acak antara 0-1).
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class Smote
{
    /**
     * @param array $X       array of feature vectors (array of array float)
     * @param array $y       array of label per baris X
     * @param int   $kNeighbors jumlah tetangga terdekat yang dipertimbangkan
     * @return array [$newX, $newY] data latih setelah oversampling
     */
    public static function apply($X, $y, $kNeighbors = 5)
    {
        $totalData = count($X);
        if ($totalData === 0) {
            return [$X, $y];
        }

        // Kelompokkan index berdasarkan label
        $classIdx = [];
        foreach ($y as $i => $label) {
            $classIdx[$label][] = $i;
        }

        // Kelas mayoritas jadi target jumlah tiap kelas (strategy 'not majority')
        $maxCount = 0;
        foreach ($classIdx as $idxs) {
            $maxCount = max($maxCount, count($idxs));
        }

        $newX = $X;
        $newY = $y;

        foreach ($classIdx as $label => $idxs) {
            $countClass = count($idxs);
            $needed = $maxCount - $countClass;
            if ($needed <= 0) {
                continue; // kelas ini sudah mayoritas / seimbang
            }

            // Ambil vektor fitur khusus kelas ini
            $classVectors = [];
            foreach ($idxs as $i) {
                $classVectors[] = $X[$i];
            }
            $n = count($classVectors);
            $k = min($kNeighbors, $n - 1);

            // Kalau cuma ada 1 sampel di kelas ini, tidak bisa interpolasi
            // antar tetangga -> duplikasi sampel apa adanya.
            if ($k < 1) {
                for ($s = 0; $s < $needed; $s++) {
                    $newX[] = $classVectors[0];
                    $newY[] = $label;
                }
                continue;
            }

            // Pra-hitung jarak antar semua pasangan di kelas ini (n biasanya
            // tidak terlalu besar karena ini per-kelas pada data latih saja)
            for ($s = 0; $s < $needed; $s++) {
                $i = mt_rand(0, $n - 1);
                $sample = $classVectors[$i];

                $distances = [];
                for ($j = 0; $j < $n; $j++) {
                    if ($j === $i) continue;
                    $distances[$j] = self::euclidean($sample, $classVectors[$j]);
                }
                asort($distances);
                $nearestIdx = array_slice(array_keys($distances), 0, $k);
                $neighborIdx = $nearestIdx[array_rand($nearestIdx)];
                $neighbor = $classVectors[$neighborIdx];

                $gap = mt_rand() / mt_getrandmax(); // 0.0 - 1.0
                // PENTING: $sample & $neighbor sekarang vektor SPARSE
                // (index => nilai, hanya entri bukan-nol). Interpolasi hanya
                // perlu dilakukan pada key yang ada di SALAH SATU vektor;
                // key yang tidak muncul di keduanya otomatis bernilai 0 di
                // hasil interpolasi (0 + gap*(0-0) = 0) jadi bisa diabaikan.
                $synthetic = [];
                $keys = array_keys($sample + $neighbor);
                foreach ($keys as $d) {
                    $sd = isset($sample[$d]) ? $sample[$d] : 0.0;
                    $nd = isset($neighbor[$d]) ? $neighbor[$d] : 0.0;
                    $val = $sd + $gap * ($nd - $sd);
                    if ($val != 0.0) {
                        $synthetic[$d] = $val; // simpan sparse, buang entri yang jadi 0
                    }
                }

                $newX[] = $synthetic;
                $newY[] = $label;
            }
        }

        return [$newX, $newY];
    }

    /**
     * Jarak Euclidean antar dua vektor SPARSE (index => nilai, hanya entri
     * bukan-nol). Dihitung dari gabungan (union) key yang ada di salah satu
     * vektor — key yang tak ada di kedua vektor otomatis dianggap 0.
     */
    private static function euclidean($a, $b)
    {
        $sum = 0.0;
        $keys = array_keys($a + $b);
        foreach ($keys as $i) {
            $ai = isset($a[$i]) ? $a[$i] : 0.0;
            $bi = isset($b[$i]) ? $b[$i] : 0.0;
            $diff = $ai - $bi;
            $sum += $diff * $diff;
        }
        return sqrt($sum);
    }

    /** Ringkasan distribusi kelas (berguna untuk ditampilkan di UI: sebelum/sesudah SMOTE) */
    public static function classDistribution($y)
    {
        $dist = [];
        foreach ($y as $label) {
            $dist[$label] = (isset($dist[$label]) ? $dist[$label] : 0) + 1;
        }
        return $dist;
    }
}
