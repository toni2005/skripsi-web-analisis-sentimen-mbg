<?php
require_once __DIR__ . '/DecisionTree.php';
require_once __DIR__ . '/compat.php';

/**
 * Class RandomForest
 * Ensemble dari beberapa Decision Tree dengan:
 *  - Bootstrap Aggregating (Bagging): setiap tree dilatih dari sampel acak (with replacement)
 *  - Random Subspace: setiap tree hanya melihat subset fitur secara acak
 * Prediksi akhir = majority voting dari semua tree
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class RandomForest
{
    private $trees = [];
    private $numTrees;
    private $maxDepth;
    private $minSamplesSplit;
    private $minSamplesLeaf;
    private $numFeaturesPerTree;
    private $maxSplitSample;

    /**
     * PERBAIKAN PENTING (root cause akurasi rendah dibanding notebook Colab):
     * versi lama mem-batasi max_depth default ke 10 dan min_samples_leaf ke 5
     * dengan asumsi pohon "dalam tanpa batas" menyebabkan RF collapse ke 1
     * kelas. Investigasi ulang (lihat test_rf2.php/test_rf3.php di paket
     * perbaikan ini) menunjukkan itu SALAH ARAH: gejala precision jauh LEBIH
     * TINGGI dari accuracy yang dulu diamati bukan tanda overfitting, tapi
     * tanda pohon terlalu DANGKAL (underfitting) — dengan ribuan fitur TF-IDF
     * sparse dan cuma kedalaman 10, pohon tidak sempat menemukan cukup banyak
     * kata informatif di sepanjang jalur root->leaf, sehingga sebagian besar
     * data numpuk di leaf yang tidak murni dan condong ke kelas mayoritas.
     * Sama seperti scikit-learn (yang defaultnya max_depth=None / tanpa
     * batas), Random Forest TIDAK gampang overfit walau pohon dalam, karena
     * regularisasi datang dari BAGGING (tiap tree cuma lihat sampel bootstrap
     * berbeda) + random feature subspace SEGAR di tiap node — bukan dari
     * membatasi kedalaman. Default di sini dinaikkan jadi 50 (kompromi
     * kecepatan training PHP vs kualitas; scikit-learn sendiri bisa tanpa
     * batas karena implementasinya di C), dan min_samples_leaf diturunkan
     * jadi 2 (mendekati default sklearn=1, sedikit regularisasi tetap
     * dipertahankan supaya tidak split ke baris SMOTE yang terlalu spesifik).
     */
    public function __construct($numTrees = 10, $maxDepth = 50, $minSamplesSplit = 2, $numFeaturesPerTree = null, $minSamplesLeaf = 2, $maxSplitSample = 3000)
    {
        $this->numTrees = $numTrees;
        $this->maxDepth = $maxDepth;
        $this->minSamplesSplit = $minSamplesSplit;
        $this->numFeaturesPerTree = $numFeaturesPerTree; // null = otomatis sqrt(jumlah fitur)
        $this->minSamplesLeaf = $minSamplesLeaf;
        // PERBAIKAN: dinaikkan dari 2000 -> 3000 (default). Nilai ini membatasi
        // berapa baris yang dipindai saat mencari split terbaik di satu node
        // (lihat DecisionTree::findBestSplit). Setelah SMOTE, data latih bisa
        // ~8000 baris; subsample yang terlalu kecil membuat fitur/bigram LANGKA
        // (misalnya cuma muncul di 5-10 baris, persis ambang min_df) punya
        // peluang besar TIDAK IKUT TERSAMPEL sama sekali di root/node besar,
        // sehingga split yang sebetulnya paling informatif tidak pernah
        // dipertimbangkan. Nilai lebih besar = pencarian split lebih akurat,
        // trade-off waktu training sedikit lebih lama (masih dalam batas
        // set_time_limit di process_training.php).
        $this->maxSplitSample = $maxSplitSample;
    }

    /**
     * @param array    $X           kumpulan vektor fitur — SEKARANG SPARSE
     *                              (index=>nilai per baris, hanya entri bukan-nol)
     * @param array    $y           kumpulan label
     * @param int|null $numFeatures total dimensi vektor (ukuran vocabulary TF-IDF).
     *                              WAJIB diisi eksplisit untuk vektor sparse — TIDAK
     *                              bisa lagi ditebak dari count($X[0]) karena baris
     *                              pertama belum tentu punya semua kolom terisi.
     */
    public function fit($X, $y, $numFeatures = null)
    {
        $this->trees = [];
        $numSamples = count($X);
        if ($numFeatures === null) {
            // fallback ini hanya benar untuk vektor PADAT (dense); untuk vektor
            // sparse pemanggil (process_training.php) sudah mengisi ini eksplisit.
            $numFeatures = count($X[0]);
        }

        $featuresPerTree = $this->numFeaturesPerTree !== null
            ? $this->numFeaturesPerTree
            : max(1, (int) round(sqrt($numFeatures)));

        for ($t = 0; $t < $this->numTrees; $t++) {
            // Bootstrap sampling (sampling with replacement)
            $bootstrapX = [];
            $bootstrapY = [];
            for ($i = 0; $i < $numSamples; $i++) {
                // BUG FIX: random_int() baru ada di PHP 7.0, diganti mt_rand()
                // supaya jalan juga di PHP 5.6 (bukan untuk keperluan kriptografi).
                $idx = mt_rand(0, $numSamples - 1);
                $bootstrapX[] = $X[$idx];
                $bootstrapY[] = $y[$idx];
            }

            // PENTING: random subspace (featuresPerTree) TIDAK lagi dipilih di
            // sini sekali untuk seluruh pohon — itu bug lama yang menyebabkan
            // RF collapse pada data TF-IDF sparse (lihat catatan panjang di
            // DecisionTree::fit()). Sekarang DecisionTree sendiri yang
            // mengundang subset fitur SEGAR di SETIAP node.
            $tree = new DecisionTree($this->maxDepth, $this->minSamplesSplit, $this->maxSplitSample, $this->minSamplesLeaf);
            $tree->fit($bootstrapX, $bootstrapY, $numFeatures, $featuresPerTree);
            $this->trees[] = $tree;
        }
    }

    public function predict($x)
    {
        $votes = [];
        foreach ($this->trees as $tree) {
            $label = $tree->predict($x);
            $votes[$label] = (isset($votes[$label]) ? $votes[$label] : 0) + 1;
        }
        arsort($votes);
        return array_key_first($votes);
    }

    public function predictBatch($vectors)
    {
        $self = $this;
        return array_map(function ($v) use ($self) {
            return $self->predict($v);
        }, $vectors);
    }

    /**
     * DIAGNOSTIK (bukan bagian inti algoritma): dipakai untuk melacak akar
     * penyebab kalau seluruh forest "collapse" memprediksi 1 kelas saja.
     * Mengembalikan, per tree: apakah root-nya langsung jadi leaf (artinya
     * findBestSplit gagal menemukan split VALID sama sekali di root itu —
     * tanda paling jelas dari collapse), fitur yang dipakai root (kalau
     * bukan leaf), dan label mayoritas leaf (kalau leaf).
     */
    public function debugStats()
    {
        $stats = [];
        foreach ($this->trees as $i => $tree) {
            $root = $tree->getTree();
            $stats[] = [
                'tree' => $i,
                'root_is_leaf' => $root['leaf'],
                'root_label' => $root['leaf'] ? $root['label'] : null,
                'root_feature' => $root['leaf'] ? null : $root['feature'],
            ];
        }
        $rootLeafCount = count(array_filter($stats, function ($s) { return $s['root_is_leaf']; }));
        return [
            'total_trees' => count($this->trees),
            'root_is_leaf_count' => $rootLeafCount,
            'per_tree' => $stats,
        ];
    }

    /** DIAGNOSTIK: lacak jalur prediksi satu vektor $x lewat tree ke-$treeIdx */
    public function traceOne($x, $treeIdx = 0)
    {
        if (!isset($this->trees[$treeIdx])) return null;
        return $this->trees[$treeIdx]->predictTrace($x);
    }

    public function export()
    {
        return [
            'numTrees' => $this->numTrees,
            'maxDepth' => $this->maxDepth,
            'minSamplesSplit' => $this->minSamplesSplit,
            'trees' => array_map(function ($t) {
                return $t->getTree();
            }, $this->trees),
        ];
    }

    public function loadFromArray($data)
    {
        $this->numTrees = $data['numTrees'];
        $this->maxDepth = $data['maxDepth'];
        $this->minSamplesSplit = $data['minSamplesSplit'];
        $this->trees = [];
        foreach ($data['trees'] as $treeData) {
            $tree = new DecisionTree($this->maxDepth, $this->minSamplesSplit, $this->maxSplitSample, $this->minSamplesLeaf);
            $tree->loadTree($treeData);
            $this->trees[] = $tree;
        }
    }
}
