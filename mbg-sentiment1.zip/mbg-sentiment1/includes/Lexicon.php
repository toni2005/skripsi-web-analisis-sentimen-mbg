<?php
/**
 * Class Lexicon
 * Pelabelan otomatis berbasis kamus sentimen Bahasa Indonesia InSet
 * (Koto & Adriani, 2016 — fajri91/InSet), diunduh dari:
 *   https://raw.githubusercontent.com/fajri91/InSet/master/positive.tsv
 *   https://raw.githubusercontent.com/fajri91/InSet/master/negative.tsv
 * — sama persis dengan sumber di notebook Colab.
 *
 * PENTING - direplikasi PERSIS sesuai kode notebook (subbab 4.4, cell
 * "Fungsi Penghitungan Skor Sentimen"), yang TIDAK memakai bobot asli TSV:
 *
 *   kamus_sentimen = {}
 *   for word in positive_lexicon: kamus_sentimen[word] = 1
 *   for word in negative_lexicon: kamus_sentimen[word] = -1
 *   kamus_sentimen.update(kamus_tambahan)
 *
 * Artinya:
 *  - Kata di kamus positif diberi skor +1 (bukan bobot asli TSV-nya).
 *  - Kata di kamus negatif diberi skor -1 (bukan bobot asli TSV-nya).
 *  - Kalau satu kata ada di KEDUA kamus (InSet punya ±1.142 kata yang
 *    tumpang tindih), skor NEGATIF-lah yang menang / menimpa (karena
 *    dict negatif diisi belakangan) — BUKAN dijumlahkan.
 *  - kamus_tambahan (kamus custom tambahan di notebook Anda) di-load dari
 *    data/kamus_tambahan.json kalau ada, dan menimpa kamus_sentimen di atas
 *    untuk kata yang sama (persis .update() di notebook). Defaultnya kosong
 *    karena isi kamus_tambahan asli belum diketahui/tidak tersimpan di
 *    notebook Anda — isi data/kamus_tambahan.json manual kalau Anda ingat
 *    isinya (format: {"kata": skor, ...}).
 *
 * Cara kerja skor per komentar (persis hitung_skor_sentimen di notebook):
 *  1. teks.split() -> daftar kata (SUDAH hasil preprocessing/stopword removal)
 *  2. skor = jumlah kamus_sentimen.get(kata, 0) untuk tiap kata
 *  3. skor > 0 -> Positif, skor < 0 -> Negatif, skor = 0 -> Netral
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class Lexicon
{
    private $kamus = [];

    public function __construct($jsonPath = null, $kamusTambahanPath = null)
    {
        if ($jsonPath === null) {
            $jsonPath = __DIR__ . '/../data/lexicon_inset.json';
        }
        if (is_file($jsonPath)) {
            $raw = file_get_contents($jsonPath);
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                if (isset($decoded['positive']) || isset($decoded['negative'])) {
                    // Kompatibilitas format lama (dua kamus terpisah) -> gabungkan
                    // dengan negatif menimpa positif, persis logika notebook.
                    $pos = isset($decoded['positive']) ? $decoded['positive'] : [];
                    $neg = isset($decoded['negative']) ? $decoded['negative'] : [];
                    foreach ($pos as $kata => $_) {
                        $this->kamus[$kata] = 1;
                    }
                    foreach ($neg as $kata => $_) {
                        $this->kamus[$kata] = -1;
                    }
                } else {
                    $this->kamus = $decoded;
                }
            }
        }

        // kamus_tambahan.update(kamus_tambahan) - opsional, defaultnya kosong
        if ($kamusTambahanPath === null) {
            $kamusTambahanPath = __DIR__ . '/../data/kamus_tambahan.json';
        }
        if (is_file($kamusTambahanPath)) {
            $raw = file_get_contents($kamusTambahanPath);
            $tambahan = json_decode($raw, true);
            if (is_array($tambahan)) {
                foreach ($tambahan as $kata => $skor) {
                    $this->kamus[$kata] = (float)$skor; // menimpa, persis .update()
                }
            }
        }
    }

    /** Berapa banyak entri kata pada kamus (untuk ditampilkan di UI) */
    public function jumlahKata()
    {
        return count($this->kamus);
    }

    /**
     * Hitung skor sentimen dari kumpulan token.
     * Return array ['skor' => float, 'label' => 'positif'|'negatif'|'netral', 'cocok' => [...]]
     */
    public function scoreTokens($tokens)
    {
        $skor = 0;
        $cocok = [];
        foreach ($tokens as $token) {
            $token = trim($token);
            if ($token === '') continue;
            if (isset($this->kamus[$token])) {
                $bobot = (float)$this->kamus[$token];
                $skor += $bobot;
                $cocok[] = $token . '(' . ($bobot > 0 ? '+' : '') . $bobot . ')';
            }
        }

        if ($skor > 0) {
            $label = 'positif';
        } elseif ($skor < 0) {
            $label = 'negatif';
        } else {
            $label = 'netral';
        }

        return ['skor' => $skor, 'label' => $label, 'cocok' => $cocok];
    }
}
