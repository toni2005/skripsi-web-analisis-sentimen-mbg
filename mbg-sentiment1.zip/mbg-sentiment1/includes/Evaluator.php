<?php
/**
 * Class Evaluator
 * Menghitung metrik evaluasi klasifikasi: Accuracy, Precision, Recall, F1-Score
 * serta Confusion Matrix (multi-class).
 *
 * Precision/Recall/F1 memakai WEIGHTED AVERAGE (dibobot berdasarkan jumlah data
 * aktual/support tiap kelas) — PERSIS `average='weighted'` yang dipakai di
 * notebook Colab (precision_score/recall_score/f1_score), BUKAN macro-average
 * (yang membobot semua kelas sama rata tanpa memandang jumlah datanya).
 */
class Evaluator
{
    public static function evaluate($yTrue, $yPred)
    {
        $labels = array_values(array_unique(array_merge($yTrue, $yPred)));
        sort($labels);

        $matrix = [];
        foreach ($labels as $actual) {
            foreach ($labels as $predicted) {
                $matrix[$actual][$predicted] = 0;
            }
        }

        $correct = 0;
        $total = count($yTrue);

        for ($i = 0; $i < $total; $i++) {
            $matrix[$yTrue[$i]][$yPred[$i]]++;
            if ($yTrue[$i] === $yPred[$i]) $correct++;
        }

        $accuracy = $total > 0 ? $correct / $total : 0;

        // Precision, Recall, F1 per kelas -> lalu weighted-average (dibobot support)
        $precisions = [];
        $recalls = [];
        $f1s = [];
        $supports = [];

        foreach ($labels as $label) {
            $tp = isset($matrix[$label][$label]) ? $matrix[$label][$label] : 0;
            $fp = 0;
            $fn = 0;
            foreach ($labels as $other) {
                if ($other !== $label) {
                    $fp += isset($matrix[$other][$label]) ? $matrix[$other][$label] : 0; // diprediksi $label padahal aslinya lain
                    $fn += isset($matrix[$label][$other]) ? $matrix[$label][$other] : 0; // aslinya $label tapi diprediksi lain
                }
            }
            $precision = ($tp + $fp) > 0 ? $tp / ($tp + $fp) : 0;
            $recall = ($tp + $fn) > 0 ? $tp / ($tp + $fn) : 0;
            $f1 = ($precision + $recall) > 0 ? 2 * $precision * $recall / ($precision + $recall) : 0;

            $precisions[$label] = $precision;
            $recalls[$label] = $recall;
            $f1s[$label] = $f1;
            $supports[$label] = $tp + $fn; // jumlah data aktual berlabel $label (support)
        }

        $totalSupport = array_sum($supports);
        $weightedPrecision = 0;
        $weightedRecall = 0;
        $weightedF1 = 0;
        if ($totalSupport > 0) {
            foreach ($labels as $label) {
                $w = $supports[$label] / $totalSupport;
                $weightedPrecision += $precisions[$label] * $w;
                $weightedRecall += $recalls[$label] * $w;
                $weightedF1 += $f1s[$label] * $w;
            }
        }

        return [
            'accuracy' => round($accuracy, 4),
            'precision' => round($weightedPrecision, 4),
            'recall' => round($weightedRecall, 4),
            'f1_score' => round($weightedF1, 4),
            'confusion_matrix' => $matrix,
            'labels' => $labels,
            'per_class' => [
                'precision' => $precisions,
                'recall' => $recalls,
                'f1' => $f1s,
                'support' => $supports,
            ],
        ];
    }
}
