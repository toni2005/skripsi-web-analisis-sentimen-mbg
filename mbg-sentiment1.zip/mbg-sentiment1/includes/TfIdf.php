<?php
/**
 * Class TfIdf
 * Membangun vocabulary dari korpus dokumen dan mengubah dokumen (array token)
 * menjadi vektor TF-IDF — dibuat untuk meniru sedekat mungkin perilaku
 * `sklearn.feature_extraction.text.TfidfVectorizer` yang dipakai di notebook
 * Colab (subbab 4.5):
 *
 *   TfidfVectorizer(max_features=3000, ngram_range=(1, 2), min_df=5, max_df=0.9)
 *
 * Detail yang direplikasi:
 *  - ngram_range=(1,2): vocabulary terdiri dari UNIGRAM + BIGRAM (dua kata
 *    berturut-turut digabung dengan spasi, mis. "makan bergizi").
 *  - min_df=5: term yang muncul di kurang dari 5 dokumen (data latih) DIBUANG.
 *  - max_df=0.9: term yang muncul di lebih dari 90% dokumen (data latih) DIBUANG
 *    (dianggap terlalu umum/tidak informatif).
 *  - max_features=3000: setelah difilter min_df/max_df, hanya 3000 term dengan
 *    frekuensi kemunculan TOTAL (jumlah kemunculan di seluruh korpus) tertinggi
 *    yang dipertahankan — persis urutan seleksi sklearn.
 *  - TF = jumlah kemunculan RAW term dalam satu dokumen (bukan dibagi panjang
 *    dokumen seperti versi sebelumnya).
 *  - IDF = ln((1 + N) / (1 + df(t))) + 1  (smooth_idf=True, default sklearn).
 *  - Vektor akhir (TF x IDF) dinormalisasi L2 per dokumen (norm='l2', default
 *    sklearn): setiap vektor dibagi akar dari jumlah kuadrat elemennya.
 *
 * Kompatibel PHP 5.6 & 7.x.
 */
class TfIdf
{
    public $vocabulary = [];   // term => index
    public $idf = [];          // term => idf value
    private $totalDocs = 0;
    private $ngramMin = 1;
    private $ngramMax = 2;

    /**
     * Pecah array token jadi daftar term sesuai ngram_range (unigram + bigram
     * secara default, sama seperti ngram_range=(1,2) di sklearn).
     */
    private function buildNgrams($tokens, $ngramMin = 1, $ngramMax = 2)
    {
        $terms = [];
        $n = count($tokens);
        for ($size = $ngramMin; $size <= $ngramMax; $size++) {
            if ($size > $n) continue;
            for ($i = 0; $i <= $n - $size; $i++) {
                $terms[] = implode(' ', array_slice($tokens, $i, $size));
            }
        }
        return $terms;
    }

    /**
     * Fit vocabulary + hitung IDF dari kumpulan dokumen (array of token-arrays)
     *
     * @param array      $documents   array of token-arrays (hasil preprocessing, BELUM di-ngram)
     * @param int|null   $maxFeatures batas jumlah term. null/0 = tanpa batas.
     * @param float      $minDf       document frequency minimum (integer count, seperti sklearn min_df int)
     * @param float      $maxDf       document frequency maksimum, proporsi 0-1 (seperti sklearn max_df float)
     * @param array      $ngramRange  [min_n, max_n], default [1, 2] (unigram + bigram)
     */
    public function fit($documents, $maxFeatures = 3000, $minDf = 5, $maxDf = 0.9, $ngramRange = [1, 2])
    {
        $this->totalDocs = count($documents);
        $this->ngramMin = $ngramRange[0];
        $this->ngramMax = $ngramRange[1];

        $docFrequency = [];   // term => jumlah dokumen yang mengandung term ini
        $corpusFrequency = []; // term => total kemunculan di seluruh korpus (untuk seleksi max_features)

        foreach ($documents as $tokens) {
            $terms = $this->buildNgrams($tokens, $this->ngramMin, $this->ngramMax);
            if (empty($terms)) continue;

            $counts = array_count_values($terms);
            foreach ($counts as $term => $c) {
                $docFrequency[$term] = (isset($docFrequency[$term]) ? $docFrequency[$term] : 0) + 1;
                $corpusFrequency[$term] = (isset($corpusFrequency[$term]) ? $corpusFrequency[$term] : 0) + $c;
            }
        }

        // Terapkan min_df & max_df (persis semantik sklearn)
        $minDfCount = $minDf; // di sini dipakai sebagai integer count (seperti min_df=5 di notebook)
        $maxDfCount = $maxDf > 1 ? $maxDf : ($maxDf * $this->totalDocs); // max_df float = proporsi

        $filtered = [];
        foreach ($docFrequency as $term => $df) {
            if ($df < $minDfCount) continue;
            if ($df > $maxDfCount) continue;
            $filtered[$term] = $corpusFrequency[$term];
        }

        // max_features: ambil N term dengan frekuensi total tertinggi (urutan sklearn)
        arsort($filtered);
        if ($maxFeatures !== null && (int)$maxFeatures > 0) {
            $filtered = array_slice($filtered, 0, (int)$maxFeatures, true);
        }

        $index = 0;
        $this->vocabulary = [];
        $this->idf = [];
        foreach ($filtered as $term => $freq) {
            $df = $docFrequency[$term];
            $this->vocabulary[$term] = $index++;
            // idf smooth (default sklearn): ln((1+N)/(1+df)) + 1
            $this->idf[$term] = log((1 + $this->totalDocs) / (1 + $df)) + 1;
        }
    }

    /**
     * Ubah satu dokumen (array token, BELUM di-ngram) menjadi vektor TF-IDF.
     *
     * PENTING (perbaikan memori): vektor dikembalikan dalam bentuk SPARSE
     * (associative array `index => nilai`, HANYA untuk term yang benar-benar
     * muncul di dokumen ini), BUKAN array padat sepanjang seluruh vocabulary.
     * Satu komentar media sosial biasanya cuma berisi belasan kata, sementara
     * vocabulary bisa sampai 3000 term — kalau disimpan padat, ribuan dokumen
     * x 3000 kolom bisa menghabiskan >1GB RAM PHP dan menyebabkan "Allowed
     * memory size exhausted". Dengan sparse, memori yang dipakai sebanding
     * dengan jumlah kata UNIK per dokumen (biasanya <20), jauh lebih hemat.
     * Semua konsumen vektor ini (RandomForest, KNN, SMOTE) sudah disesuaikan
     * untuk membaca vektor sparse ini (entri yang tidak ada dianggap 0).
     */
    public function transform($tokens)
    {
        $terms = $this->buildNgrams($tokens, $this->ngramMin, $this->ngramMax);
        if (empty($terms)) {
            return [];
        }

        $termCount = array_count_values($terms);
        $vector = [];

        foreach ($termCount as $term => $count) {
            if (isset($this->vocabulary[$term])) {
                $idx = $this->vocabulary[$term];
                // TF = raw count (persis sklearn default, bukan dibagi panjang dokumen)
                $vector[$idx] = $count * $this->idf[$term];
            }
        }

        // Normalisasi L2 (persis default norm='l2' di TfidfVectorizer)
        $sumSquares = 0.0;
        foreach ($vector as $v) {
            $sumSquares += $v * $v;
        }
        if ($sumSquares > 0) {
            $norm = sqrt($sumSquares);
            foreach ($vector as $i => $v) {
                $vector[$i] = $v / $norm;
            }
        }

        return $vector;
    }

    /** Jumlah total fitur/kolom di vocabulary (dimensi penuh vektor, meski disimpan sparse) */
    public function vocabSize()
    {
        return count($this->vocabulary);
    }

    /** Transform banyak dokumen sekaligus */
    public function transformBatch($documentsTokens)
    {
        $self = $this;
        return array_map(function ($tokens) use ($self) {
            return $self->transform($tokens);
        }, $documentsTokens);
    }

    /** Export vocabulary + idf untuk disimpan (JSON) */
    public function export()
    {
        return [
            'vocabulary' => $this->vocabulary,
            'idf' => $this->idf,
            'totalDocs' => $this->totalDocs,
            'ngramMin' => $this->ngramMin,
            'ngramMax' => $this->ngramMax,
        ];
    }

    /** Load kembali vocabulary + idf dari data tersimpan */
    public function loadFromArray($data)
    {
        $this->vocabulary = $data['vocabulary'];
        $this->idf = $data['idf'];
        $this->totalDocs = $data['totalDocs'];
        $this->ngramMin = isset($data['ngramMin']) ? $data['ngramMin'] : 1;
        $this->ngramMax = isset($data['ngramMax']) ? $data['ngramMax'] : 2;
    }
}
