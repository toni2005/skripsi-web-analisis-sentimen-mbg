<?php
/**
 * Konfigurasi Koneksi Database
 * Sistem Analisis Sentimen Program MBG
 *
 * File ini OTOMATIS memilih kredensial database yang benar tergantung
 * di mana kode ini dijalankan, supaya Anda tidak perlu edit manual
 * setiap kali upload dari lokal (XAMPP/Laragon) ke hosting cPanel
 * atau sebaliknya.
 *
 * Caranya: dicek dari nama host yang diakses browser ($_SERVER['HTTP_HOST']).
 *  - Kalau 'localhost' / '127.0.0.1' -> pakai kredensial LOKAL.
 *  - Selain itu (domain hosting Anda)  -> pakai kredensial HOSTING.
 *
 * -----------------------------------------------------------------
 * YANG PERLU ANDA ISI SENDIRI (khusus bagian HOSTING di bawah):
 * Buka cPanel -> menu "MySQL Databases", lalu isi 3 nilai berikut
 * persis seperti yang tertulis di sana:
 *   1. DB_NAME (hosting) -> nama database (format: cpaneluser_namadb)
 *   2. DB_USER (hosting) -> username database (format: cpaneluser_namauser)
 *   3. DB_PASS (hosting) -> password yang Anda buat waktu membuat user itu
 * DB_HOST di cPanel hampir selalu tetap 'localhost' (karena MySQL-nya
 * jalan di server yang sama dengan PHP-nya) - biasanya tidak perlu diubah.
 * -----------------------------------------------------------------
 */

// Daftar nama host yang dianggap "lokal" (development di komputer sendiri)
$localHosts = ['localhost', '127.0.0.1', '::1'];

$currentHost = isset($_SERVER['HTTP_HOST'])
    ? strtolower(explode(':', $_SERVER['HTTP_HOST'])[0]) // buang port kalau ada, mis. localhost:8080
    : 'localhost'; // fallback kalau dijalankan lewat CLI (php -r ..., cron, dsb)

$isLocal = in_array($currentHost, $localHosts, true);

if ($isLocal) {
    // =========================== LOKAL (XAMPP/Laragon) ===========================
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');                 // sesuaikan kalau MySQL lokal Anda pakai password
    define('DB_NAME', 'mbg_sentiment1');
} else {
    // =========================== HOSTING (cPanel) =================================
    // GANTI 3 nilai di bawah ini sesuai punya Anda di cPanel -> MySQL Databases
    define('DB_HOST', 'localhost');
    define('DB_USER', 'nuky7665_mbgsentiment');   // mis. 'cpaneluser_mbguser'
    define('DB_PASS', 'sentimenMBG');
    define('DB_NAME', 'nuky7665_mbg.sentiment');       // mis. 'cpaneluser_mbgsentiment'
}

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die(
                "Koneksi database gagal: " . $conn->connect_error .
                "<br>Environment terdeteksi: " . (defined('DB_NAME') ? DB_NAME : '?') .
                "<br>Pastikan database sudah dibuat dan kredensial di config/db.php sudah benar."
            );
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}
