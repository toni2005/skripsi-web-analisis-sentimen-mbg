<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/compat.php';
$db = getDB();

// Daftar batch dataset yang tersedia, untuk dropdown filter di navbar
$daftarBatch = [];
try {
    $resBatch = $db->query("SELECT DISTINCT dataset_batch FROM dataset ORDER BY dataset_batch ASC");
    if ($resBatch) {
        while ($rowBatch = $resBatch->fetch_assoc()) {
            $daftarBatch[] = $rowBatch['dataset_batch'];
        }
    }
} catch (Exception $e) {
    // abaikan, dropdown akan kosong
}

// Batch yang sedang dipilih lewat query string ?batch=... ("" / tidak diisi = semua batch)
$batchDipilih = isset($_GET['batch']) ? trim($_GET['batch']) : '';
if ($batchDipilih !== '' && !in_array($batchDipilih, $daftarBatch, true)) {
    $batchDipilih = ''; // abaikan nilai batch yang tidak valid/tidak dikenal
}

// Statistik ringkas untuk kartu di hero (sama seperti referensi: total komentar, akurasi, data training)
// Angka-angka ini mengikuti batch yang dipilih di dropdown navbar (kosong = semua batch)
$totalKomentar = 0; $akurasiTerbaik = null; $algoTerbaik = ''; $dataTesting = 0;
try {
    if ($batchDipilih !== '') {
        $stmtCount = $db->prepare("SELECT COUNT(*) c FROM dataset WHERE dataset_batch = ?");
        $stmtCount->bind_param('s', $batchDipilih);
        $stmtCount->execute();
        $totalKomentar = (int)stmtFetchAll($stmtCount)[0]['c'];

        $stmtBest = $db->prepare("SELECT * FROM training_history WHERE dataset_batch = ? ORDER BY akurasi DESC LIMIT 1");
        $stmtBest->bind_param('s', $batchDipilih);
        $stmtBest->execute();
        $bestRows = stmtFetchAll($stmtBest);
        $best = isset($bestRows[0]) ? $bestRows[0] : null;
    } else {
        $totalKomentar = (int)$db->query("SELECT COUNT(*) c FROM dataset")->fetch_assoc()['c'];
        $best = $db->query("SELECT * FROM training_history ORDER BY akurasi DESC LIMIT 1")->fetch_assoc();
    }

    if ($best) {
        $akurasiTerbaik = round($best['akurasi'] * 100, 2);
        $algoTerbaik = $best['algoritma'] === 'random_forest' ? 'Random Forest' : 'KNN';
        $dataTesting = (int)$best['jumlah_data_test'];
    }
} catch (Exception $e) {
    // Database belum di-setup — landing page tetap tampil dengan angka 0
}

// Render dropdown pemilih batch (dipakai di navbar desktop & menu mobile)
function renderBatchDropdown($daftarBatch, $batchDipilih, $mobile = false) {
    $currentLabel = $batchDipilih !== '' ? $batchDipilih : 'Semua Batch';
    $wrapClass = 'batch-dropdown' . ($mobile ? ' batch-dropdown-mobile' : '');
    ob_start();
    ?>
    <div class="<?= $wrapClass ?>" data-batch-dropdown>
        <button type="button" class="batch-dropdown-toggle" aria-haspopup="listbox" aria-expanded="false">
            <svg class="batch-dropdown-icon" width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path d="M1.5 2.5h11L8.25 7.4v3.6l-2.5 1.3V7.4L1.5 2.5z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round"/>
            </svg>
            <span class="batch-dropdown-current"><?= htmlspecialchars($currentLabel) ?></span>
            <svg class="batch-dropdown-chevron" width="10" height="6" viewBox="0 0 10 6" fill="none" aria-hidden="true">
                <path d="M1 1L5 5L9 1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </button>
        <ul class="batch-dropdown-menu" role="listbox" aria-label="Pilih batch dataset">
            <li role="option" aria-selected="<?= $batchDipilih === '' ? 'true' : 'false' ?>">
                <a href="index.php" class="batch-dropdown-item<?= $batchDipilih === '' ? ' active' : '' ?>">
                    <span class="batch-dropdown-check">✓</span><span>Semua Batch</span>
                </a>
            </li>
            <?php foreach ($daftarBatch as $namaBatch): ?>
            <li role="option" aria-selected="<?= $namaBatch === $batchDipilih ? 'true' : 'false' ?>">
                <a href="index.php?batch=<?= urlencode($namaBatch) ?>" class="batch-dropdown-item<?= $namaBatch === $batchDipilih ? ' active' : '' ?>">
                    <span class="batch-dropdown-check">✓</span><span><?= htmlspecialchars($namaBatch) ?></span>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
    return ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analisis Sentimen Program MBG | Random Forest vs KNN</title>
    <link rel="stylesheet" href="assets/css/style.css?v=<?= time() ?>">
</head>
<body class="landing">

    <nav class="landing-nav">
        <div class="brand">
            <span class="brand-icon">🍱</span>
            <div>
                <div class="brand-title">Sentimen MBG</div>
                <div class="brand-sub">Skripsi · Sistem Informasi</div>
            </div>
        </div>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="#alur">Alur</a>
            <a href="#metodologi">Metodologi</a>
            <a href="#hasil">Hasil</a>
            <a href="public/upload.php">Demo</a>
            <?php if (count($daftarBatch) > 0): ?>
                <?= renderBatchDropdown($daftarBatch, $batchDipilih, false) ?>
            <?php endif; ?>
        </div>
        <button class="navbar-toggle" id="landingNavToggle" aria-label="Buka menu" aria-expanded="false">
            <span></span><span></span><span></span>
        </button>
    </nav>
    <div class="landing-mobile-menu" id="landingMobileMenu">
        <a href="index.php">Home</a>
        <a href="#alur">Alur</a>
        <a href="#metodologi">Metodologi</a>
        <a href="#hasil">Hasil</a>
        <a href="public/upload.php">Demo</a>
        <?php if (count($daftarBatch) > 0): ?>
            <?= renderBatchDropdown($daftarBatch, $batchDipilih, true) ?>
        <?php endif; ?>
    </div>

    <section class="hero">
        <div class="hero-text">
            <h1 class="hero-title">
                Analisis Sentimen<br>
                <span class="accent">Program Makan Bergizi Gratis</span><br>
                Random Forest vs KNN
            </h1>
            <p class="hero-desc">
                Penelitian ini mengklasifikasikan komentar publik (YouTube, TikTok, X, dll.) mengenai
                program Makan Bergizi Gratis (MBG) ke dalam sentimen <strong>positif</strong>,
                <strong>negatif</strong>, dan <strong>netral</strong>, menggunakan preprocessing teks
                Bahasa Indonesia serta membandingkan performa algoritma <strong>Random Forest</strong>
                dan <strong>K-Nearest Neighbor (KNN)</strong>.
            </p>
            <div class="hero-actions">
                <a href="public/upload.php" class="btn primary-mbg">📁 Upload Dataset</a>
                <a href="public/comparison.php" class="btn outline-mbg">📈 Lihat Hasil →</a>
            </div>
        </div>

        <div class="hero-stats">
            <?php if ($batchDipilih !== ''): ?>
            <div class="hero-stats-batch-label">Batch: <?= htmlspecialchars($batchDipilih) ?></div>
            <?php endif; ?>
            <div class="hero-stat-card">
                <div class="num"><?= number_format($totalKomentar, 0, ',', '.') ?></div>
                <div class="lbl">Total Komentar</div>
            </div>
            <div class="hero-stat-card">
                <div class="num"><?= $akurasiTerbaik !== null ? $akurasiTerbaik . '%' : '—' ?></div>
                <div class="lbl"><?= $algoTerbaik !== '' ? 'Akurasi Terbaik (' . $algoTerbaik . ')' : 'Akurasi Model' ?></div>
            </div>
            <div class="hero-stat-card">
                <div class="num"><?= number_format($dataTesting, 0, ',', '.') ?></div>
                <div class="lbl">Data Testing</div>
            </div>
        </div>
    </section>

    <section id="alur" class="landing-section">
        <h2 class="section-h">Alur Sistem Analisis Sentimen</h2>
        <p class="section-sub">
            Sistem berbasis PHP native + MySQL ini mengikuti alur kerja standar analisis sentimen,
            mulai dari pengumpulan data hingga pelatihan model klasifikasi.
        </p>
        <div class="feature-grid">
            <div class="feature-card">
                <div class="icon">📁</div>
                <h3>1. Upload Data Mentah</h3>
                <p>Upload hasil scraping/gabungan komentar (CSV) apa adanya — kolom label sentimen tidak wajib ada, dikelompokkan per batch.</p>
            </div>
            <div class="feature-card">
                <div class="icon">🧹</div>
                <h3>2. Pre-Processing</h3>
                <p>Cleaning, case folding, normalisasi kata gaul, tokenisasi, dan stopword removal.</p>
            </div>
            <div class="feature-card">
                <div class="icon">🏷️</div>
                <h3>3. Pelabelan Data</h3>
                <p>Pelabelan otomatis berbasis kamus sentimen (InSet Lexicon), dengan opsi koreksi manual sebelum training.</p>
            </div>
            <div class="feature-card">
                <div class="icon">⚙️</div>
                <h3>4. Klasifikasi</h3>
                <p>Ekstraksi fitur TF-IDF lalu melatih model Random Forest dan KNN untuk dibandingkan.</p>
            </div>
        </div>
    </section>

    <section id="metodologi" class="landing-section" style="padding-top:0;">
        <h2 class="section-h">Metodologi</h2>
        <p class="section-sub">Ringkasan teknis metode yang digunakan pada sistem ini.</p>
        <div class="feature-grid">
            <div class="feature-card">
                <div class="icon">🧮</div>
                <h3>TF-IDF</h3>
                <p>Ekstraksi fitur teks menjadi vektor numerik berbobot (maks. 3.000 fitur, unigram + bigram).</p>
            </div>
            <div class="feature-card">
                <div class="icon">🌲</div>
                <h3>Random Forest</h3>
                <p>Ensemble Decision Tree (CART + Gini) dengan bagging &amp; random subspace method.</p>
            </div>
            <div class="feature-card">
                <div class="icon">📍</div>
                <h3>K-Nearest Neighbor</h3>
                <p>Klasifikasi berbasis jarak (Euclidean / Cosine) dengan voting mayoritas K tetangga.</p>
            </div>
            <div class="feature-card">
                <div class="icon">📊</div>
                <h3>Evaluasi</h3>
                <p>Accuracy, precision, recall, F1-score, dan confusion matrix per kelas sentimen.</p>
            </div>
        </div>
    </section>

    <section id="hasil" class="landing-section" style="padding-top:0;">
        <h2 class="section-h">Hasil &amp; Demo</h2>
        <p class="section-sub">Lihat dashboard lengkap, perbandingan model, dan coba prediksi sentimen kalimat baru.</p>
        <div class="hero-actions">
            <a href="public/index.php" class="btn primary-mbg">📊 Buka Dashboard</a>
            <a href="public/comparison.php" class="btn outline-mbg">📈 Perbandingan Model</a>
            <a href="public/upload.php" class="btn outline-mbg">📁 Upload Dataset</a>
        </div>
    </section>

    <footer class="landing-footer">
        Sistem Analisis Sentimen Program MBG &middot; Random Forest vs KNN &middot; &copy; <?= date('Y') ?>
    </footer>

    <script>
        (function () {
            var toggleBtn = document.getElementById('landingNavToggle');
            var mobileMenu = document.getElementById('landingMobileMenu');
            if (!toggleBtn || !mobileMenu) return;

            function closeMenu() {
                mobileMenu.classList.remove('open');
                toggleBtn.setAttribute('aria-expanded', 'false');
            }

            toggleBtn.addEventListener('click', function () {
                var isOpen = mobileMenu.classList.toggle('open');
                toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            });

            // Tutup menu saat salah satu link diklik (mis. anchor scroll)
            mobileMenu.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', closeMenu);
            });

            // Tutup menu otomatis saat layar dilebarkan ke ukuran desktop
            window.addEventListener('resize', function () {
                if (window.innerWidth > 900) closeMenu();
            });
        })();

        // Dropdown kustom untuk pemilih batch (desktop & mobile)
        (function () {
            var dropdowns = document.querySelectorAll('[data-batch-dropdown]');
            if (!dropdowns.length) return;

            function closeAll(except) {
                dropdowns.forEach(function (d) {
                    if (d === except) return;
                    d.classList.remove('open');
                    var t = d.querySelector('.batch-dropdown-toggle');
                    if (t) t.setAttribute('aria-expanded', 'false');
                });
            }

            dropdowns.forEach(function (dropdown) {
                var toggle = dropdown.querySelector('.batch-dropdown-toggle');
                if (!toggle) return;
                toggle.addEventListener('click', function (e) {
                    e.stopPropagation();
                    var willOpen = !dropdown.classList.contains('open');
                    closeAll(dropdown);
                    dropdown.classList.toggle('open', willOpen);
                    toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
                });
            });

            document.addEventListener('click', function () { closeAll(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') closeAll();
            });
        })();
    </script>

</body>
</html>
