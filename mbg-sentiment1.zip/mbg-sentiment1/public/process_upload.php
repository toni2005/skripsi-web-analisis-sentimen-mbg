<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: upload.php?error=' . urlencode('Permintaan tidak valid.'));
    exit;
}

if (!isset($_FILES['file_csv'])) {
    // Kalau $_FILES kosong total (bukan cuma error code), kemungkinan besar
    // ukuran file MELEBIHI post_max_size di php.ini, sehingga PHP bahkan
    // tidak sempat mengisi $_FILES/$_POST sama sekali.
    $postMaxSize = ini_get('post_max_size');
    header('Location: upload.php?error=' . urlencode(
        'File tidak diterima server. Kemungkinan ukuran file melebihi batas post_max_size ' .
        'di php.ini Anda saat ini (' . $postMaxSize . '). Naikkan nilai post_max_size (dan ' .
        'upload_max_filesize) di php.ini, lalu restart Apache.'
    ));
    exit;
}

$batch = trim(isset($_POST['dataset_batch']) ? $_POST['dataset_batch'] : '');
$delimiterPilihanUser = isset($_POST['delimiter']) ? $_POST['delimiter'] : ',';

// PERBAIKAN BUG: sebelumnya delimiter dari dropdown user (koma/titik koma)
// langsung dipakai mentah-mentah ke fgetcsv() tanpa validasi. Kalau user
// salah pilih (mis. pilih ";" padahal file aslinya pakai ","), hasil parsing
// jadi rusak total: baris multi-baris yang harusnya digabung tanda kutip
// malah kepotong-potong jadi banyak baris palsu, dan jumlah baris yang
// terupload jadi salah (lebih banyak dari yang seharusnya, tapi isinya
// pecahan kalimat, bukan data valid).
//
// Sekarang delimiter dideteksi otomatis dari isi file: baca beberapa baris
// pertama, coba pisah pakai kandidat delimiter umum (koma, titik koma, tab,
// pipe), lalu pilih yang menghasilkan JUMLAH KOLOM PALING KONSISTEN dan
// PALING BANYAK (>1) di baris-baris tersebut. Pilihan dropdown user tetap
// dipakai sebagai prioritas HANYA kalau delimiter itu memang cocok dengan isi
// file; kalau tidak cocok, sistem otomatis mengoreksi ke delimiter yang benar
// dan user diberi tahu lewat pesan di halaman hasil upload.
function detectDelimiter($filePath, $preferredDelimiter) {
    $candidates = [',', ';', "\t", '|'];
    $bestDelimiter = $preferredDelimiter;
    $bestScore = -1;

    foreach ($candidates as $cand) {
        $handle = fopen($filePath, 'r');
        if (!$handle) continue;

        $counts = [];
        $rowsChecked = 0;
        while ($rowsChecked < 10 && ($row = fgetcsv($handle, 0, $cand)) !== false) {
            $counts[] = count($row);
            $rowsChecked++;
        }
        fclose($handle);

        if (empty($counts)) continue;

        $colCount = $counts[0];
        // Delimiter yang bagus: kolomnya > 1 DAN konsisten di semua baris sampel.
        $consistent = true;
        foreach ($counts as $c) {
            if ($c !== $colCount) { $consistent = false; break; }
        }
        if ($colCount <= 1 || !$consistent) continue;

        // Skor: makin banyak kolom yang konsisten, makin besar kemungkinan itu
        // delimiter yang benar. Kandidat sesuai pilihan user diberi sedikit
        // bonus supaya kalau dua kandidat sama kuat, pilihan user dimenangkan.
        $score = $colCount + ($cand === $preferredDelimiter ? 0.5 : 0);
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestDelimiter = $cand;
        }
    }

    return $bestDelimiter;
}

if ($batch === '') {
    header('Location: upload.php?error=' . urlencode('Nama batch wajib diisi.'));
    exit;
}

$fileTmp = $_FILES['file_csv']['tmp_name'];
$fileError = $_FILES['file_csv']['error'];

if ($fileError !== UPLOAD_ERR_OK) {
    // PERBAIKAN: pesan error spesifik per kode error PHP, supaya penyebab
    // sebenarnya (biasanya ukuran file melebihi batas php.ini) langsung
    // terlihat, bukan cuma "Gagal mengupload file." yang tidak jelas.
    $uploadMax = ini_get('upload_max_filesize');
    $postMax = ini_get('post_max_size');
    $errorMessages = [
        UPLOAD_ERR_INI_SIZE => 'Ukuran file melebihi batas upload_max_filesize di php.ini Anda saat ini (' . $uploadMax . '). ' .
            'Naikkan nilai upload_max_filesize (mis. jadi 64M) di file php.ini, lalu restart Apache dari XAMPP Control Panel.',
        UPLOAD_ERR_FORM_SIZE => 'Ukuran file melebihi batas maksimum form upload.',
        UPLOAD_ERR_PARTIAL   => 'File hanya terupload sebagian (koneksi terputus di tengah proses). Silakan coba upload ulang.',
        UPLOAD_ERR_NO_FILE   => 'Tidak ada file yang dipilih.',
        UPLOAD_ERR_NO_TMP_DIR => 'Folder temporary server tidak ditemukan (kesalahan konfigurasi server).',
        UPLOAD_ERR_CANT_WRITE => 'Gagal menyimpan file ke disk server (periksa permission folder temp).',
        UPLOAD_ERR_EXTENSION  => 'Upload dihentikan oleh salah satu ekstensi PHP di server.',
    ];
    $msg = isset($errorMessages[$fileError])
        ? $errorMessages[$fileError]
        : 'Gagal mengupload file (kode error: ' . $fileError . '). Batas saat ini: upload_max_filesize=' . $uploadMax . ', post_max_size=' . $postMax . '.';
    header('Location: upload.php?error=' . urlencode($msg));
    exit;
}

// Deteksi delimiter yang SEBENARNYA dari isi file, jangan cuma percaya
// dropdown user. Kalau ketahuan beda, koreksi otomatis + tandai untuk
// ditampilkan sebagai peringatan ke user setelah upload selesai.
$delimiter = detectDelimiter($fileTmp, $delimiterPilihanUser);
$delimiterDikoreksi = ($delimiter !== $delimiterPilihanUser);

$handle = fopen($fileTmp, 'r');
if (!$handle) {
    header('Location: upload.php?error=' . urlencode('File tidak dapat dibaca.'));
    exit;
}

$header = fgetcsv($handle, 0, $delimiter);
// BUG FIX: file CSV yang diekspor dari Excel biasanya diawali UTF-8 BOM
// (byte order mark) pada kolom pertama, sehingga header "teks" terbaca
// sebagai "\xEF\xBB\xBFteks" dan gagal dikenali oleh array_search di bawah.
if (isset($header[0])) {
    $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', $header[0]);
}
$header = array_map(function ($h) { return strtolower(trim($h)); }, $header);

// ALUR BARU: data mentah hasil scraping BOLEH belum punya label sama sekali.
// Hanya kolom TEKS yang wajib ada; kolom label & metadata lain semuanya opsional
// dan otomatis dikenali dari nama header yang umum dipakai (termasuk hasil
// scraping YouTube/TikTok/X seperti "teks_komentar", "video_id", dst.)
$teksAliases     = ['teks', 'teks_asli', 'teks_komentar', 'komentar', 'komentar_asli', 'text', 'comment', 'caption'];
$labelAliases    = ['label', 'label_sentimen', 'sentiment', 'sentimen', 'label_sentiment', 'kelas'];
$platformAliases = ['platform', 'sumber', 'source'];
$keywordAliases  = ['keyword', 'kata_kunci', 'query'];
$usernameAliases = ['username', 'user', 'nama_user', 'author'];
$tanggalAliases  = ['tanggal', 'tanggal_komentar', 'date', 'created_at', 'timestamp', 'waktu'];
$likeAliases     = ['like_count', 'likes', 'jumlah_like', 'like'];

// FITUR BARU: deteksi kolom otomatis yang lebih fleksibel.
// Sebelumnya findColumn() hanya cocok kalau nama header PERSIS sama dengan
// salah satu alias (mis. header "Teks Komentar" atau "Komentar_" dengan
// spasi/kapital/underscore berbeda TIDAK terbaca walaupun jelas-jelas kolom
// teks). Sekarang ditambah 2 lapis fallback tanpa mengharuskan CSV diubah:
//   1) Fuzzy match: nama header dinormalisasi (huruf kecil, tanda baca/spasi
//      jadi underscore) lalu dibandingkan lagi ke alias yang juga dinormalisasi,
//      dan dicek apakah mengandung salah satu KATA KUNCI (mis. header
//      "Isi Komentar (Mentah)" -> dikenali karena mengandung kata "komentar").
//   2) Deteksi berbasis ISI kolom: kalau header tidak mengandung kata kunci
//      apa pun (mis. hasil export tool lain dengan nama header aneh seperti
//      "col_3" atau "value"), sistem membaca beberapa baris data dan memilih
//      kolom yang isinya paling mirip teks komentar (kalimat panjang & banyak
//      kata), bukan angka/tanggal/id pendek.
function normalizeHeaderName($h) {
    $h = strtolower(trim($h));
    $h = preg_replace('/[^a-z0-9]+/', '_', $h);
    return trim($h, '_');
}

// Kata kunci per jenis kolom untuk lapis fuzzy (dicek sebagai substring dari
// header yang sudah dinormalisasi).
$teksKeywords     = ['teks', 'text', 'komentar', 'koment', 'comment', 'caption', 'content', 'isi', 'ulasan', 'review', 'tweet', 'kalimat', 'narasi', 'pesan'];
$labelKeywords    = ['label', 'sentimen', 'sentiment', 'kelas', 'class'];
$platformKeywords = ['platform', 'sumber', 'source', 'media', 'channel'];
$keywordKeywords  = ['keyword', 'katakunci', 'query'];
$usernameKeywords = ['username', 'user', 'nama', 'author', 'akun'];
$tanggalKeywords  = ['tanggal', 'date', 'waktu', 'time', 'created'];
$likeKeywords     = ['like', 'suka'];

/**
 * Cari kolom lewat fuzzy header-name matching. Dipanggil hanya kalau
 * findColumn() (exact match) sudah gagal duluan.
 */
function findColumnFuzzy($header, $aliases, $keywords) {
    $normalizedHeader = array_map('normalizeHeaderName', $header);
    // Lapis 1: alias yang sudah dinormalisasi (menangani beda kapital/spasi/underscore)
    foreach ($aliases as $alias) {
        $normAlias = normalizeHeaderName($alias);
        foreach ($normalizedHeader as $idx => $h) {
            if ($h !== '' && $h === $normAlias) return $idx;
        }
    }
    // Lapis 2: header mengandung salah satu kata kunci (mis. "Isi Komentar (Mentah)")
    foreach ($normalizedHeader as $idx => $h) {
        if ($h === '') continue;
        foreach ($keywords as $kw) {
            if (strpos($h, $kw) !== false) return $idx;
        }
    }
    return false;
}

/**
 * Fallback terakhir kalau nama header sama sekali tidak mengandung petunjuk
 * apa pun (mis. "col_3"): baca sampel baris data dan tebak kolom teks
 * komentar berdasarkan ISI-nya (kalimat panjang & berisi banyak kata),
 * bukan angka/tanggal/username/id yang biasanya pendek.
 */
function guessTextColumnByContent($handle, $delimiter, $excludeIdx = []) {
    $startPos = ftell($handle);
    $samples = [];
    $sampleRows = 0;
    while ($sampleRows < 50 && ($row = fgetcsv($handle, 0, $delimiter)) !== false) {
        foreach ($row as $idx => $val) {
            if (in_array($idx, $excludeIdx, true)) continue;
            $samples[$idx][] = trim($val);
        }
        $sampleRows++;
    }
    fseek($handle, $startPos); // kembalikan posisi baca supaya loop utama tidak melewatkan baris sampel

    $bestIdx = false;
    $bestScore = 0;
    foreach ($samples as $idx => $vals) {
        $n = count($vals);
        if ($n === 0) continue;
        $totalLen = 0;
        $wordyCount = 0;
        foreach ($vals as $v) {
            $totalLen += mb_strlen($v);
            if (str_word_count($v) >= 3) $wordyCount++;
        }
        $avgLen = $totalLen / $n;
        // Lewati kolom yang isinya rata-rata pendek (kemungkinan id/tanggal/angka/username)
        if ($avgLen < 15) continue;
        $score = $avgLen * ($wordyCount / $n);
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestIdx = $idx;
        }
    }
    return $bestIdx;
}
// FITUR BARU: kenali file yang SUDAH dipreprocessing sebelumnya (mis. hasil
// notebook Google Colab yang punya kolom "teks_bersih" / hasil stopword
// removal + stemming). Kalau kolom ini ada, baris langsung ditandai
// status_preprocessing = 'selesai' sehingga bisa lompat langsung ke
// menu Training tanpa perlu klik "Jalankan Preprocessing" lagi.
$preprocessedAliases = ['teks_bersih', 'teks_preprocessing', 'hasil_preprocessing', 'clean_text', 'stemming', 'hasil_stemming'];
$tokenAliases = ['tokens', 'token', 'stopword_removal', 'hasil_tokenizing'];

function findColumn($header, $aliases) {
    foreach ($aliases as $alias) {
        $idx = array_search($alias, $header);
        if ($idx !== false) return $idx;
    }
    return false;
}

$idxTeks         = findColumn($header, $teksAliases);
$idxLabel        = findColumn($header, $labelAliases);
$idxPlatform     = findColumn($header, $platformAliases);
$idxKeyword      = findColumn($header, $keywordAliases);
$idxUsername     = findColumn($header, $usernameAliases);
$idxTanggal      = findColumn($header, $tanggalAliases);
$idxLike         = findColumn($header, $likeAliases);
$idxPreprocessed = findColumn($header, $preprocessedAliases);
$idxTokens       = findColumn($header, $tokenAliases);

// FALLBACK 1: nama header tidak persis sama tapi mirip/mengandung kata kunci
// (mis. "Teks Komentar", "KOMENTAR_ASLI ", "isi_komentar") -> tidak perlu
// CSV diubah, kolomnya tetap dikenali.
if ($idxTeks === false)     $idxTeks     = findColumnFuzzy($header, $teksAliases, $teksKeywords);
if ($idxLabel === false)    $idxLabel    = findColumnFuzzy($header, $labelAliases, $labelKeywords);
if ($idxPlatform === false) $idxPlatform = findColumnFuzzy($header, $platformAliases, $platformKeywords);
if ($idxKeyword === false)  $idxKeyword  = findColumnFuzzy($header, $keywordAliases, $keywordKeywords);
if ($idxUsername === false) $idxUsername = findColumnFuzzy($header, $usernameAliases, $usernameKeywords);
if ($idxTanggal === false)  $idxTanggal  = findColumnFuzzy($header, $tanggalAliases, $tanggalKeywords);
if ($idxLike === false)     $idxLike     = findColumnFuzzy($header, $likeAliases, $likeKeywords);

$teksAutoDetectedByContent = false;

// FALLBACK 2: kolom teks WAJIB ada, jadi kalau nama headernya sama sekali
// tidak memberi petunjuk (mis. "col_3", "value", "field1"), tebak dari ISI
// datanya (lihat isi 50 baris pertama, pilih kolom paling "berupa kalimat").
// Kolom yang sudah ketebak jadi label/platform/dst. dikecualikan supaya tidak
// tertukar.
if ($idxTeks === false) {
    $excludeForGuess = array_filter([$idxLabel, $idxPlatform, $idxKeyword, $idxUsername, $idxTanggal, $idxLike], function ($v) {
        return $v !== false;
    });
    $idxTeks = guessTextColumnByContent($handle, $delimiter, array_values($excludeForGuess));
    if ($idxTeks !== false) $teksAutoDetectedByContent = true;
}

if ($idxTeks === false) {
    fclose($handle);
    header('Location: upload.php?error=' . urlencode(
        'Kolom teks komentar tidak ditemukan/tidak dapat dikenali dari header maupun isi data. ' .
        'Kolom yang terbaca: ' . implode(', ', $header)
    ));
    exit;
}

// Nama kolom teks yang sebenarnya dipakai (untuk ditampilkan di pesan sukses,
// supaya user tahu kolom mana yang otomatis terdeteksi).
$teksColNameUsed = $teksAutoDetectedByContent
    ? '(ditebak dari isi data, kolom ke-' . ($idxTeks + 1) . ')'
    : (isset($header[$idxTeks]) && $header[$idxTeks] !== '' ? $header[$idxTeks] : ('kolom ke-' . ($idxTeks + 1)));

// Normalisasi variasi penulisan label ("Positif", "POSITIF", "pos", dst.) ke 3 kelas baku.
// Kolom label bersifat OPSIONAL: kalau tidak ada / nilainya tidak dikenali,
// baris tetap disimpan sebagai data BELUM BERLABEL (label = NULL) dan akan
// diberi label otomatis nanti di menu "Pelabelan Data".
function normalizeLabel($raw) {
    $l = strtolower(trim($raw));
    $map = [
        'positif' => 'positif', 'positive' => 'positif', 'pos' => 'positif', '1' => 'positif',
        'negatif' => 'negatif', 'negative' => 'negatif', 'neg' => 'negatif', '-1' => 'negatif',
        'netral' => 'netral', 'neutral' => 'netral', 'net' => 'netral', '0' => 'netral',
    ];
    return isset($map[$l]) ? $map[$l] : null;
}

/**
 * Ubah teks hasil preprocessing (string) atau representasi list Python
 * (mis. "['kacau', 'banget', 'program']" dari kolom stopword_removal hasil
 * Colab) menjadi array token bersih.
 */
function parseTokensFromCell($raw) {
    $raw = trim($raw);
    if ($raw === '') return [];
    // Format list Python: ['kata1', 'kata2', ...]
    if ($raw[0] === '[' && substr($raw, -1) === ']') {
        $inner = substr($raw, 1, -1);
        preg_match_all("/'([^']*)'|\"([^\"]*)\"/", $inner, $matches);
        $tokens = [];
        foreach ($matches[0] as $i => $m) {
            $val = $matches[1][$i] !== '' ? $matches[1][$i] : $matches[2][$i];
            $val = trim($val);
            if ($val !== '') $tokens[] = $val;
        }
        if (!empty($tokens)) return $tokens;
    }
    // Fallback: string biasa dipisah spasi
    return array_values(array_filter(explode(' ', $raw), function ($t) { return trim($t) !== ''; }));
}

// PERBAIKAN PERFORMA (upload lambat untuk dataset ribuan baris, mis. ~5.800an
// baris dari scraping): versi sebelumnya menjalankan SATU INSERT per baris
// dengan autocommit AKTIF (default mysqli) — artinya MySQL/MariaDB melakukan
// commit (fsync ke disk) TERPISAH untuk SETIAP baris. Untuk InnoDB ini sangat
// mahal (bisa puluhan ms per commit tergantung disk), jadi 5.800 baris x commit
// terpisah = bisa berpuluh detik-menit, WALAUPUN insert-nya sendiri instan.
// Ini sama persis di lokal (XAMPP/Laragon) maupun hosting (biasanya malah
// lebih lambat lagi karena latensi jaringan ke DB server).
//
// Perbaikan: matikan autocommit, bungkus insert dalam TRANSACTION, dan commit
// per CHUNK (per 500 baris) alih-alih per baris. Hasilnya satu file CSV
// ribuan baris cukup butuh beberapa kali commit saja (bukan ribuan kali),
// biasanya turun dari puluhan detik/menit menjadi 1-3 detik.
set_time_limit(300);

$stmt = $db->prepare("
    INSERT INTO dataset
        (teks_asli, label, status_pelabelan, label_sumber, dataset_batch, platform, keyword, username, tanggal_asli, like_count, teks_preprocessing, tokens, status_preprocessing)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");

$count = 0;
$skipped = 0;
$labeledCount = 0;
$preprocessedCount = 0;
$validLabels = ['positif', 'negatif', 'netral'];

const UPLOAD_COMMIT_CHUNK = 500; // commit tiap 500 baris, bukan tiap 1 baris

$db->autocommit(false);
$db->begin_transaction();
$sinceLastCommit = 0;

try {

while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
    if (!isset($row[$idxTeks])) { $skipped++; continue; }

    $teks = trim($row[$idxTeks]);
    if ($teks === '') { $skipped++; continue; }

    $label = null;
    $statusPelabelan = 'belum';
    $labelSumber = null;
    if ($idxLabel !== false && isset($row[$idxLabel]) && trim($row[$idxLabel]) !== '') {
        $normalized = normalizeLabel($row[$idxLabel]);
        if ($normalized !== null && in_array($normalized, $validLabels)) {
            $label = $normalized;
            $statusPelabelan = 'selesai';
            $labelSumber = 'upload';
            $labeledCount++;
        }
    }

    $platform = ($idxPlatform !== false && isset($row[$idxPlatform])) ? trim($row[$idxPlatform]) : null;
    $keyword  = ($idxKeyword  !== false && isset($row[$idxKeyword]))  ? trim($row[$idxKeyword])  : null;
    $username = ($idxUsername !== false && isset($row[$idxUsername])) ? trim($row[$idxUsername]) : null;
    $tanggal  = ($idxTanggal  !== false && isset($row[$idxTanggal]))  ? trim($row[$idxTanggal])  : null;
    $like     = ($idxLike     !== false && isset($row[$idxLike]) && $row[$idxLike] !== '') ? (int)$row[$idxLike] : null;

    // Kalau CSV sudah punya kolom hasil preprocessing (dari Colab dsb.),
    // langsung pakai supaya tidak perlu diproses ulang di menu Preprocessing.
    $teksPreprocessing = null;
    $tokensJson = null;
    $statusPreprocessing = 'belum';
    if ($idxPreprocessed !== false && isset($row[$idxPreprocessed]) && trim($row[$idxPreprocessed]) !== '') {
        $teksPreprocessing = trim($row[$idxPreprocessed]);
        $tokens = ($idxTokens !== false && isset($row[$idxTokens]) && trim($row[$idxTokens]) !== '')
            ? parseTokensFromCell($row[$idxTokens])
            : parseTokensFromCell($teksPreprocessing);
        $tokensJson = json_encode($tokens);
        $statusPreprocessing = 'selesai';
        $preprocessedCount++;
    }

    $stmt->bind_param(
        'sssssssssisss',
        $teks, $label, $statusPelabelan, $labelSumber, $batch,
        $platform, $keyword, $username, $tanggal, $like,
        $teksPreprocessing, $tokensJson, $statusPreprocessing
    );
    $stmt->execute();
    $count++;
    $sinceLastCommit++;

    // Commit per chunk (bukan per baris) supaya jumlah commit ke disk jauh
    // lebih sedikit, tapi transaksi tidak membengkak tanpa batas untuk file
    // yang sangat besar (juga membebaskan lock InnoDB secara berkala).
    if ($sinceLastCommit >= UPLOAD_COMMIT_CHUNK) {
        $db->commit();
        $db->begin_transaction();
        $sinceLastCommit = 0;
    }
}

// Commit sisa baris terakhir yang belum genap satu chunk
$db->commit();

} catch (Throwable $e) {
    $db->rollback();
    $db->autocommit(true);
    fclose($handle);
    header('Location: upload.php?error=' . urlencode(
        'Gagal menyimpan data ke database (transaksi dibatalkan): ' . $e->getMessage()
    ));
    exit;
}

$db->autocommit(true); // kembalikan ke mode normal untuk request berikutnya
fclose($handle);

if ($count === 0) {
    header('Location: upload.php?error=' . urlencode('Tidak ada data valid ditemukan pada file CSV (kolom teks kosong di semua baris).'));
    exit;
}

// Catat snapshot jumlah data MENTAH (sebelum dedup) untuk batch ini.
// Nilai ini TIDAK PERNAH diubah oleh fitur dedup otomatis di
// preprocessing.php -- hanya bertambah kalau ada upload susulan ke batch
// yang sama -- supaya "Total Data" di halaman Preprocessing tetap
// menunjukkan angka asli walaupun baris duplikat sudah dihapus dari
// tabel `dataset`.
$logStmt = $db->prepare("
    INSERT INTO dataset_upload_log (dataset_batch, total_upload_awal)
    VALUES (?, ?)
    ON DUPLICATE KEY UPDATE total_upload_awal = total_upload_awal + VALUES(total_upload_awal)
");
$logStmt->bind_param('si', $batch, $count);
$logStmt->execute();

$unlabeledCount = $count - $labeledCount;
$delimiterLabel = ['\t' => 'Tab', ',' => 'Koma (,)', ';' => 'Titik koma (;)', '|' => 'Pipe (|)'];
$redirectUrl = 'upload.php?success=1&count=' . $count . '&skipped=' . $skipped .
    '&labeled=' . $labeledCount . '&unlabeled=' . $unlabeledCount .
    '&preprocessed=' . $preprocessedCount . '&batch=' . urlencode($batch) .
    '&teks_col=' . urlencode($teksColNameUsed);

// Kalau delimiter yang dipilih user di dropdown ternyata TIDAK cocok dengan
// isi file asli, kita sudah otomatis pakai delimiter yang benar (lihat
// detectDelimiter() di atas) supaya data tidak rusak/kepotong-potong. User
// tetap diberi tahu lewat query string ini supaya sadar dropdown-nya salah.
if ($delimiterDikoreksi) {
    $namaDipilih = isset($delimiterLabel[$delimiterPilihanUser]) ? $delimiterLabel[$delimiterPilihanUser] : $delimiterPilihanUser;
    $namaDipakai = isset($delimiterLabel[$delimiter]) ? $delimiterLabel[$delimiter] : $delimiter;
    $redirectUrl .= '&delimiter_warning=' . urlencode(
        "Anda memilih delimiter \"$namaDipilih\", tapi sistem mendeteksi file CSV ini " .
        "sebenarnya memakai \"$namaDipakai\". Delimiter otomatis dikoreksi supaya data tidak " .
        "rusak/terpotong. Silakan cek Nama Batch Dataset di atas untuk memastikan hasilnya sesuai."
    );
}

header('Location: ' . $redirectUrl);
exit;
