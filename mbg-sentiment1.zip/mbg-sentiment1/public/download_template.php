<?php
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="template_dataset_mbg_mentah.csv"');

$output = fopen('php://output', 'w');
// Template alur baru: data mentah, TANPA kolom label (label diisi otomatis nanti)
fputcsv($output, ['platform', 'keyword', 'teks_komentar', 'username', 'tanggal', 'like_count']);
fputcsv($output, ['YouTube', 'makan bergizi gratis', 'Program MBG sangat membantu anak sekolah dapat makan bergizi', '@user1', '2026-07-01T10:00:00Z', 5]);
fputcsv($output, ['TikTok', 'makan bergizi gratis', 'Menu MBG di sekolah anak saya sering telat dan dingin', '@user2', '2026-07-01T11:00:00Z', 2]);
fputcsv($output, ['X', 'makan bergizi gratis', 'Programnya biasa saja belum terlihat perubahan signifikan', '@user3', '2026-07-01T12:00:00Z', 0]);
fclose($output);
exit;
