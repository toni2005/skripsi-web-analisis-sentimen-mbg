<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
require_once __DIR__ . '/../includes/Preprocessing.php';

$db = getDB();
$pageTitle = 'Hasil Pre-Processing';

include __DIR__ . '/templates/header.php';

$batches = $db->query("
    SELECT dataset_batch, COUNT(*) total, SUM(status_preprocessing='selesai') selesai
    FROM dataset GROUP BY dataset_batch HAVING selesai > 0 ORDER BY dataset_batch
");
$batchList = [];
while ($b = $batches->fetch_assoc()) $batchList[] = $b;

$defaultBatch = isset($batchList[0]['dataset_batch']) ? $batchList[0]['dataset_batch'] : '';
$batchFilter = isset($_GET['batch']) ? $_GET['batch'] : $defaultBatch;
$selectedBatch = null;
foreach ($batchList as $b) {
    if ($b['dataset_batch'] === $batchFilter) { $selectedBatch = $b; break; }
}
?>

<?php if (isset($_GET['reprocessed'])): ?>
    <div class="alert success">
        <?= (int)$_GET['count'] ?> baris berhasil diproses ulang.
        <?php $dupRemoved = isset($_GET['duplicate_removed']) ? (int)$_GET['duplicate_removed'] : 0; ?>
        <?php if ($dupRemoved > 0): ?>
            Ditemukan <strong><?= $dupRemoved ?> data duplikat</strong> dan otomatis dihapus.
        <?php endif; ?>
    </div>
<?php endif; ?>

<div class="card">
    <div class="flex-between">
        <h2 style="margin:0;">🧩 Alur Preprocessing</h2>
        <form method="GET" class="flex">
            <select name="batch" onchange="this.form.submit()" style="margin:0;min-width:220px;">
                <?php if (empty($batchList)): ?>
                    <option value="">-- belum ada dataset diproses --</option>
                <?php endif; ?>
                <?php foreach ($batchList as $b): ?>
                    <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" <?= $batchFilter === $b['dataset_batch'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b['dataset_batch']) ?> (<?= $b['selesai'] ?>/<?= $b['total'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <?php if ($selectedBatch): ?>
    <p class="text-muted mt-16" style="margin-bottom:14px;">
        Dataset batch "<strong><?= htmlspecialchars($selectedBatch['dataset_batch']) ?></strong>" dipilih.
        Berikut hasil setiap tahapan preprocessing per baris data.
    </p>

    <div class="pipeline mt-16">
        <span class="step blue">Teks Asli</span><span class="arrow">→</span>
        <span class="step">Cleaning</span><span class="arrow">→</span>
        <span class="step">Case Folding</span><span class="arrow">→</span>
        <span class="step">Normalisasi (kamus)</span><span class="arrow">→</span>
        <span class="step">Tokenisasi</span><span class="arrow">→</span>
        <span class="step">Stopword Removal</span><span class="arrow">→</span>
        <span class="step blue">TF-IDF</span><span class="arrow">→</span>
        <span class="step blue">Random Forest / KNN</span>
    </div>

    <div class="alert info mt-16">
        <p style="margin:0 0 10px;">
            Preprocessing diimplementasikan native di PHP (tanpa dependency eksternal):
        </p>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 190px;">&bull; Cleaning</span><span>: hapus URL, mention, hashtag, angka, tanda baca, dan karakter non-ASCII/emoji.</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 190px;">&bull; Case Folding</span><span>: ubah seluruh teks menjadi huruf kecil.</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 190px;">&bull; Normalisasi</span><span>: kamus kata tidak baku/singkatan (gk→tidak, yg→yang, dst.) dari tabel <code>kamus_normalisasi</code>.</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 190px;">&bull; Stopword Removal</span><span>: daftar stopword Bahasa Indonesia (<code>StopwordList.php</code>).</span></div>
        <div style="display:flex; gap:8px;"><span style="flex:0 0 190px;">&bull; TF-IDF → RF / KNN</span><span>: ekstraksi fitur lalu klasifikasi (menu Training Model).</span></div>
        <p style="margin:12px 0 0;">
            Selanjutnya, data yang belum berlabel bisa diberi label otomatis di menu <a href="pelabelan.php">Pelabelan Data</a>.
        </p>
    </div>
    <?php endif; ?>
</div>

<?php if ($selectedBatch):
    $preprocessing = new Preprocessing($db);

    $perPage = 10;
    $page = max(1, (int)(isset($_GET['page']) ? $_GET['page'] : 1));
    $totalRows = (int)$selectedBatch['total'];
    $totalPages = max(1, (int)ceil($totalRows / $perPage));
    $offset = ($page - 1) * $perPage;

    $stmt = $db->prepare("SELECT id, teks_asli, label, teks_preprocessing, status_preprocessing FROM dataset WHERE dataset_batch = ? ORDER BY id ASC LIMIT ? OFFSET ?");
    $stmt->bind_param('sii', $selectedBatch['dataset_batch'], $perPage, $offset);
    $stmt->execute();
    // BUG FIX: pakai stmtFetchAll() (bukan get_result() langsung) supaya tetap
    // jalan di hosting yang mysqli-nya tidak dikompilasi dengan mysqlnd.
    $rows = stmtFetchAll($stmt);
?>
<div class="card">
    <div class="flex-between">
        <div></div>
        <div class="flex">
            <a class="btn small" href="download_preprocessing.php?batch=<?= urlencode($selectedBatch['dataset_batch']) ?>">⬇ Download Hasil CSV</a>
        </div>
    </div>
    <p class="text-muted mt-16"><?= $selectedBatch['selesai'] ?> dari <?= $selectedBatch['total'] ?> baris berhasil diproses — siap download.</p>

    <div class="step-table-wrap mt-16">
    <table>
        <tr>
            <th>Teks Asli</th>
            <th>Case Folding</th>
            <th>Cleaning</th>
            <th>Normalisasi</th>
            <th>Tokenisasi</th>
            <th>Stopword</th>
            <th>Hasil Akhir</th>
            <th>Label</th>
        </tr>
        <?php foreach ($rows as $r):
            if ($r['status_preprocessing'] !== 'selesai') {
                echo '<tr><td colspan="8" class="text-muted">#' . $r['id'] . ' — ' . htmlspecialchars(mb_strimwidth($r['teks_asli'], 0, 60, '...')) . ' (belum diproses)</td></tr>';
                continue;
            }
            // Satu sumber kebenaran untuk semua tahap tampilan (lihat
            // Preprocessing::processWithTrace) - urutannya dijamin identik
            // dengan proses asli yang menghasilkan teks_preprocessing/tokens
            // yang tersimpan di database, tidak disusun ulang manual di sini.
            $trace = $preprocessing->processWithTrace($r['teks_asli']);
        ?>
        <tr>
            <td><?= htmlspecialchars(mb_strimwidth($r['teks_asli'], 0, 80, '...')) ?></td>
            <td><?= htmlspecialchars($trace['case_folding']) ?></td>
            <td><?= htmlspecialchars($trace['cleaning']) ?></td>
            <td><?= htmlspecialchars($trace['normalisasi']) ?></td>
            <td><?= htmlspecialchars(implode(' ', $trace['tokenize'])) ?></td>
            <td><?= htmlspecialchars(implode(' ', $trace['stopword_removal'])) ?></td>
            <td><strong><?= htmlspecialchars($r['teks_preprocessing']) ?></strong></td>
            <td>
                <?php if ($r['label']): ?>
                    <span class="badge <?= $r['label'] ?>"><?= $r['label'] ?></span>
                <?php else: ?>
                    <span class="badge belum">belum</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>

    <div class="pagination">
        <?php if ($page > 1): ?><a href="?batch=<?= urlencode($batchFilter) ?>&page=<?= $page-1 ?>">‹ Sebelumnya</a><?php endif; ?>
        <span class="current">Hal. <?= $page ?> / <?= $totalPages ?></span>
        <?php if ($page < $totalPages): ?><a href="?batch=<?= urlencode($batchFilter) ?>&page=<?= $page+1 ?>">Berikutnya ›</a><?php endif; ?>
    </div>
</div>
<?php else: ?>
<div class="alert info">
    Belum ada dataset yang selesai dipreprocessing. Jalankan preprocessing terlebih dahulu di menu
    <a href="preprocessing.php">Preprocessing</a>.
</div>
<?php endif; ?>

<?php include __DIR__ . '/templates/footer.php'; ?>
