<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dataset.php');
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$label = isset($_POST['label']) ? trim($_POST['label']) : '';
$batch = isset($_POST['batch']) ? $_POST['batch'] : '';
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;

$validLabels = ['positif', 'negatif', 'netral'];
if ($id > 0 && in_array($label, $validLabels)) {
    $stmt = $db->prepare("UPDATE dataset SET label = ?, status_pelabelan = 'selesai', label_sumber = 'manual' WHERE id = ?");
    $stmt->bind_param('si', $label, $id);
    $stmt->execute();
}

header('Location: dataset.php?updated=1&batch=' . urlencode($batch) . '&page=' . $page);
exit;
