<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();
$pageTitle = 'Training Model';
include __DIR__ . '/templates/header.php';

$batches = $db->query("
    SELECT dataset_batch, COUNT(*) total,
           SUM(status_preprocessing='selesai') selesai,
           SUM(status_preprocessing='selesai' AND label IS NOT NULL) siap_training
    FROM dataset GROUP BY dataset_batch HAVING siap_training > 0
");

$historyBatchFilter = isset($_GET['history_batch']) ? $_GET['history_batch'] : '';
$historyBatches = $db->query("SELECT DISTINCT dataset_batch FROM training_history ORDER BY dataset_batch");

$historyWhere = $historyBatchFilter !== '' ? "WHERE dataset_batch = '" . $db->real_escape_string($historyBatchFilter) . "'" : '';
$history = $db->query("SELECT * FROM training_history $historyWhere ORDER BY created_at DESC");

// Pisahkan riwayat training per algoritma (RF & KNN), masing-masing sudah terurut
// terbaru -> terlama (ORDER BY created_at DESC di query). Sekalian tandai baris
// akurasi TERAKHIR (training paling baru) dan TERBAIK (akurasi tertinggi) per algoritma.
$historyRF = [];
$historyKNN = [];
while ($h = $history->fetch_assoc()) {
    if ($h['algoritma'] === 'random_forest') {
        $historyRF[] = $h;
    } else {
        $historyKNN[] = $h;
    }
}

function tandaiRiwayat($rows) {
    if (empty($rows)) return $rows;
    // Baris pertama = paling baru (data sudah ORDER BY created_at DESC)
    $rows[0]['is_latest'] = true;
    // Cari akurasi tertinggi
    $bestIdx = 0;
    foreach ($rows as $i => $r) {
        if ($r['akurasi'] > $rows[$bestIdx]['akurasi']) $bestIdx = $i;
    }
    $rows[$bestIdx]['is_best'] = true;
    return $rows;
}
$historyRF = tandaiRiwayat($historyRF);
$historyKNN = tandaiRiwayat($historyKNN);
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert success">
        Training model <strong><?= $_GET['algo'] === 'random_forest' ? 'Random Forest' : 'KNN' ?></strong> selesai!
        Akurasi: <strong><?= round($_GET['acc'] * 100, 2) ?>%</strong>.
        Lihat detail di menu <a href="comparison.php">Perbandingan Model</a>.
    </div>
<?php endif; ?>
<?php if (isset($_GET['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
<?php endif; ?>

<div class="alert info">
    Training hanya memakai baris yang <strong>sudah dipreprocessing dan sudah berlabel</strong>.
    Jika sebuah batch belum muncul di sini atau jumlah "siap dilatih"-nya masih kurang, jalankan
    <a href="preprocessing.php">Preprocessing</a> lalu <a href="pelabelan.php">Pelabelan Data</a> terlebih dahulu.
    <br><br>
    Pembagian data latih/uji sekarang otomatis <strong>stratified</strong>
    (proporsi tiap kelas sentimen dijaga sama di data latih & data uji), dan tersedia opsi
    <strong>SMOTE</strong> untuk menyeimbangkan kelas minoritas pada data latih sebelum training.
</div>


<div class="grid grid-2">
    <div class="card">
        <h2>🌲 Training Random Forest</h2>
        <form action="process_training.php" method="POST">
            <input type="hidden" name="algoritma" value="random_forest">

            <label>Pilih Dataset Batch</label>
            <select name="batch" id="rf-batch" required onchange="updateSplitPreview('rf')">
                <option value="">-- pilih batch --</option>
                <?php
                $batches->data_seek(0);
                while ($b = $batches->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" data-siap="<?= (int) $b['siap_training'] ?>">
                        <?= htmlspecialchars($b['dataset_batch']) ?> (<?= $b['siap_training'] ?>/<?= $b['total'] ?> siap dilatih)
                    </option>
                <?php endwhile; ?>
            </select>

            <label>Rasio Data Latih : Data Uji (stratified — proporsi tiap kelas sentimen dijaga sama)</label>
            <select name="test_ratio" id="rf-test-ratio" onchange="updateSplitPreview('rf')">
                <option value="20" selected>80% : 20%</option>
            </select>
            <p id="rf-split-preview" class="text-muted" style="margin:-8px 0 14px;font-size:12.5px;">
                Pilih batch untuk melihat perkiraan jumlah data latih / data uji.
            </p>

            <label>Random Seed (isi angka tetap misalnya 42 supaya hasil training bisa direproduksi persis sama; kosongkan untuk kembali ke perilaku acak seperti sebelumnya)</label>
            <input type="number" name="random_seed" value="42" placeholder="kosongkan = acak setiap run">

            <label>Jumlah Tree (n_estimators)</label>
            <input type="number" name="n_trees" value="100" min="1" max="300">

            <label>Kedalaman Maksimum Tree (max_depth, kosongkan = default 200)</label>
            <input type="number" name="max_depth" value="" min="1" max="300" placeholder="kosongkan = 200 (terbukti terbaik di riwayat training Anda)">

            <label>Minimal Sampel per Leaf (min_samples_leaf, kosongkan = 1, persis default scikit-learn/notebook)</label>
            <input type="number" name="min_samples_leaf" value="" min="1" max="100" placeholder="kosongkan = 1 (disarankan; naikkan ke 5-10 HANYA kalau max_depth &gt; 150 dan muncul error memori)">

            <label style="font-weight:normal;">
                <input type="hidden" name="full_split_search" value="0">
                <input type="checkbox" name="full_split_search" value="1" checked style="width:auto;">
                Cari split pakai SELURUH data latih (tanpa subsampling) — paling dekat ke
                notebook Colab/sklearn, dan terbukti di riwayat training Anda menaikkan akurasi
                dari ~55-60% ke ~70-71% (konsekuensinya training ~2x lebih lambat pada dataset besar)
            </label>

            <label>Maksimal Fitur TF-IDF (max_features)</label>
            <input type="number" name="max_features" value="3000" min="0">

            <label>Min. Document Frequency (min_df)</label>
            <input type="number" name="min_df" value="5" min="1">

            <label>Max. Document Frequency (max_df, proporsi 0-1)</label>
            <input type="number" name="max_df" value="0.9" min="0.01" max="1" step="0.01">

            <label style="font-weight:normal;">
                <input type="checkbox" name="use_bigram" value="1" checked style="width:auto;">
                Sertakan bigram (dua kata berurutan), sesuai ngram_range=(1,2)
            </label>

            <label style="font-weight:normal;">
                <input type="checkbox" name="use_smote" value="1" checked style="width:auto;">
                Terapkan SMOTE pada data latih (seimbangkan kelas minoritas)
            </label>

            <button type="submit" class="btn">Latih Model Random Forest</button>
        </form>
    </div>

    <div class="card">
        <h2>📍 Training K-Nearest Neighbor</h2>
        <form action="process_training.php" method="POST">
            <input type="hidden" name="algoritma" value="knn">

            <label>Pilih Dataset Batch</label>
            <select name="batch" id="knn-batch" required onchange="updateSplitPreview('knn')">
                <option value="">-- pilih batch --</option>
                <?php
                $batches->data_seek(0);
                while ($b = $batches->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" data-siap="<?= (int) $b['siap_training'] ?>">
                        <?= htmlspecialchars($b['dataset_batch']) ?> (<?= $b['siap_training'] ?>/<?= $b['total'] ?> siap dilatih)
                    </option>
                <?php endwhile; ?>
            </select>

            <label>Rasio Data Latih : Data Uji (stratified — proporsi tiap kelas sentimen dijaga sama)</label>
            <select name="test_ratio" id="knn-test-ratio" onchange="updateSplitPreview('knn')">
                <option value="20" selected>80% : 20%</option>
            </select>
            <p id="knn-split-preview" class="text-muted" style="margin:-8px 0 14px;font-size:12.5px;">
                Pilih batch untuk melihat perkiraan jumlah data latih / data uji.
            </p>

            <label>Random Seed (isi angka tetap misalnya 42 supaya hasil training bisa direproduksi persis sama; kosongkan untuk kembali ke perilaku acak seperti sebelumnya)</label>
            <input type="number" name="random_seed" value="42" placeholder="kosongkan = acak setiap run">

            <label>Nilai K (jumlah tetangga)</label>
            <input type="number" name="k_value" value="5" min="1" max="25">

            <label>Metrik Jarak</label>
            <select name="metric">
                <option value="cosine" selected>Cosine Distance</option>
                <option value="euclidean">Euclidean Distance</option>
            </select>

            <label>Maksimal Fitur TF-IDF (max_features)</label>
            <input type="number" name="max_features" value="3000" min="0">

            <label>Min. Document Frequency (min_df)</label>
            <input type="number" name="min_df" value="5" min="1">

            <label>Max. Document Frequency (max_df, proporsi 0-1)</label>
            <input type="number" name="max_df" value="0.9" min="0.01" max="1" step="0.01">

            <label style="font-weight:normal;">
                <input type="checkbox" name="use_bigram" value="1" checked style="width:auto;">
                Sertakan bigram (dua kata berurutan), sesuai ngram_range=(1,2)
            </label>

            <label style="font-weight:normal;">
                <input type="checkbox" name="use_smote" value="1" checked style="width:auto;">
                Terapkan SMOTE pada data latih (seimbangkan kelas minoritas)
            </label>

            <button type="submit" class="btn">Latih Model KNN</button>
        </form>
    </div>
</div>

<script>
// REVISI DOSEN: sebelumnya rasio 80:20 disimpan sebagai <input type="hidden">
// (tidak kelihatan sama sekali sebelum training dijalankan) — pengguna baru
// bisa lihat jumlah data latih/uji SETELAH training selesai, di tabel
// Riwayat Training. Sekarang rasio ditampilkan sebagai dropdown yang bisa
// dilihat (dan diganti kalau perlu), dan perkiraan jumlah data latih/uji
// dihitung langsung di sini (stratified split, jadi hasil ASLI dari
// process_training.php akan sangat dekat dengan perkiraan ini, hanya
// mungkin beda 1-2 baris karena pembulatan per kelas).
function updateSplitPreview(prefix) {
    var batchSelect = document.getElementById(prefix + '-batch');
    var ratioSelect = document.getElementById(prefix + '-test-ratio');
    var preview = document.getElementById(prefix + '-split-preview');
    var opt = batchSelect.options[batchSelect.selectedIndex];
    var total = opt ? parseInt(opt.getAttribute('data-siap') || '0', 10) : 0;

    if (!total) {
        preview.textContent = 'Pilih batch untuk melihat perkiraan jumlah data latih / data uji.';
        return;
    }
    var testRatio = parseInt(ratioSelect.value, 10) / 100;
    var testCount = Math.round(total * testRatio);
    var trainCount = total - testCount;
    var trainPct = Math.round((1 - testRatio) * 100);
    var testPct = Math.round(testRatio * 100);
    preview.innerHTML = '≈ <strong>' + trainCount + '</strong> data latih / <strong>' + testCount +
        '</strong> data uji (dari ' + total + ' data siap dilatih, rasio ' + trainPct + ':' + testPct +
        ', stratified per kelas sentimen). Jumlah pasti akan tercatat di riwayat training di bawah setelah selesai.';
}
document.addEventListener('DOMContentLoaded', function () {
    updateSplitPreview('rf');
    updateSplitPreview('knn');
});
</script>

<div class="card">
    <div class="flex-between">
        <h2 style="margin:0;">Riwayat Training</h2>
        <form method="GET">
            <select name="history_batch" onchange="this.form.submit()" style="margin:0;">
                <option value="">-- Semua Batch --</option>
                <?php while ($b = $historyBatches->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" <?= $historyBatchFilter === $b['dataset_batch'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b['dataset_batch']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>
    <?php
    function renderRiwayatTable($rows, $heading, $emoji) {
    ?>
    <div class="history-subheading"><span><span class="history-subheading-icon"><?= $emoji ?></span><span><?= htmlspecialchars($heading) ?></span></span></div>
    <div class="history-table-wrap">
    <table>
        <tr>
            <th>Waktu</th><th>Batch</th><th>Algoritma</th><th>Data Train/Test</th>
            <th>Akurasi</th><th>Precision</th><th>Recall</th><th>F1-Score</th><th>Waktu Latih</th><th class="col-pengaturan-th">Pengaturan</th>
        </tr>
        <?php if (empty($rows)): ?>
            <tr><td colspan="10" class="text-muted">Belum ada riwayat training <?= htmlspecialchars($heading) ?>.</td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $h):
            $p = json_decode($h['parameter'], true);
            $p = is_array($p) ? $p : [];
            $isLatest = !empty($h['is_latest']);
            $isBest = !empty($h['is_best']);
            $rowClass = $isBest ? 'row-highlight' : '';
        ?>
        <tr class="<?= $rowClass ?>">
            <td><?= date('d/m/Y H:i', strtotime($h['created_at'])) ?></td>
            <td><?= htmlspecialchars($h['dataset_batch']) ?></td>
            <td><?= $h['algoritma'] === 'random_forest' ? '🌲 Random Forest' : '📍 KNN' ?></td>
            <td><?= $h['jumlah_data_train'] ?> / <?= $h['jumlah_data_test'] ?></td>
            <td>
                <strong><?= round($h['akurasi'] * 100, 2) ?>%</strong>
            </td>
            <td><?= round($h['presisi'] * 100, 2) ?>%</td>
            <td><?= round($h['recall_score'] * 100, 2) ?>%</td>
            <td><?= round($h['f1_score'] * 100, 2) ?>%</td>
            <td><?= round($h['waktu_training'], 2) ?>s</td>
            <td class="text-muted col-pengaturan" style="font-size:12px;">
                <?php
                    $splitLabel = isset($p['stratified_split']) && $p['stratified_split'] ? 'Stratified' : '-';
                    if (isset($p['split_ratio'])) {
                        // Riwayat baru: rasio split asli (sebelum SMOTE) tersimpan langsung, akurat.
                        $splitLabel .= ' ' . $p['split_ratio'];
                    } else {
                        // Riwayat lama: jumlah_data_train tersimpan SETELAH SMOTE (data sintetis
                        // menambah jumlah train), jadi tidak bisa dipakai untuk menghitung mundur
                        // rasio split asli — akan menyesatkan (mis. tampak 87:13 padahal aslinya 80:20).
                        $splitLabel .= ' (rasio asli tidak tercatat di riwayat ini)';
                    }
                ?>
                <?= htmlspecialchars($splitLabel) ?>,
                SMOTE: <?= (isset($p['use_smote']) && $p['use_smote']) ? '✅' : '❌' ?>,
                fitur: <?= isset($p['max_features_tfidf']) ? htmlspecialchars($p['max_features_tfidf']) : '-' ?>
                <?php if (isset($p['max_depth'])): ?>, depth: <?= htmlspecialchars($p['max_depth']) ?><?php endif; ?>
                <?php if (isset($p['min_samples_leaf'])): ?>, minLeaf: <?= htmlspecialchars($p['min_samples_leaf']) ?><?php endif; ?>
                <?php if (!empty($p['full_split_search'])): ?>, <strong>full-split</strong><?php endif; ?>
                <?php if (isset($p['k'])): ?>, K: <?= htmlspecialchars($p['k']) ?><?php endif; ?>
                <?php if (isset($p['metric'])): ?>, metrik: <?= htmlspecialchars($p['metric']) ?><?php endif; ?>
                <?php if (isset($p['random_seed'])): ?>, seed: <?= htmlspecialchars($p['random_seed']) ?><?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php
    }
    renderRiwayatTable($historyRF, 'Random Forest', '🌲');
    renderRiwayatTable($historyKNN, 'K-Nearest Neighbor (KNN)', '📍');
    ?>
</div>

<?php include __DIR__ . '/templates/footer.php'; ?>
