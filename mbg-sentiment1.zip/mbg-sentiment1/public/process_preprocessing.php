<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
require_once __DIR__ . '/../includes/Preprocessing.php';
require_once __DIR__ . '/../includes/Dedup.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: preprocessing.php');
    exit;
}

$batch = isset($_POST['batch']) ? $_POST['batch'] : '';
if ($batch === '') {
    header('Location: preprocessing.php');
    exit;
}

// Stemming dihapus dari alur web ini. Preprocessing selalu menjalankan
// 5 tahap sesuai skripsi (Tabel 3.4 & Bab IV): cleaning -> case folding ->
// normalisasi -> tokenizing -> stopword removal, tanpa stemming.
$useStemming = false;

// Mode "Proses Ulang": reset status batch ini ke 'belum' dulu supaya semua
// baris diproses ulang dari awal (dipakai oleh tombol "Proses Ulang" di
// halaman Hasil Pre-Processing).
$forceVal = isset($_POST['force']) ? $_POST['force'] : '';
if ($forceVal === '1') {
    $resetStmt = $db->prepare("UPDATE dataset SET status_preprocessing = 'belum' WHERE dataset_batch = ?");
    $resetStmt->bind_param('s', $batch);
    $resetStmt->execute();
}

// naikkan batas eksekusi karena preprocessing manual bisa memakan waktu untuk data besar
set_time_limit(300);

$preprocessing = new Preprocessing($db);

$stmt = $db->prepare("SELECT id, teks_asli FROM dataset WHERE dataset_batch = ? AND status_preprocessing = 'belum'");
$stmt->bind_param('s', $batch);
$stmt->execute();
// BUG FIX: pakai stmtFetchAll() (bukan get_result() langsung) supaya tetap
// jalan di hosting yang mysqli-nya tidak dikompilasi dengan mysqlnd.
$rows = stmtFetchAll($stmt);

$update = $db->prepare("UPDATE dataset SET teks_preprocessing = ?, tokens = ?, status_preprocessing = 'selesai' WHERE id = ?");

// PERBAIKAN PERFORMA: sama seperti upload, UPDATE per baris dengan autocommit
// aktif berarti commit (fsync) terpisah untuk tiap baris — sangat lambat untuk
// dataset ribuan baris. Bungkus dalam transaction, commit per chunk 500 baris.
$count = 0;
$sinceLastCommit = 0;
const PREPROCESSING_COMMIT_CHUNK = 500;

$db->autocommit(false);
$db->begin_transaction();
try {
    foreach ($rows as $row) {
        $hasil = $preprocessing->process($row['teks_asli'], $useStemming);
        $textResult = $hasil['text'];
        $tokensJson = json_encode($hasil['tokens']);
        $id = $row['id'];

        $update->bind_param('ssi', $textResult, $tokensJson, $id);
        $update->execute();
        $count++;
        $sinceLastCommit++;

        if ($sinceLastCommit >= PREPROCESSING_COMMIT_CHUNK) {
            $db->commit();
            $db->begin_transaction();
            $sinceLastCommit = 0;
        }
    }
    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    $db->autocommit(true);
    header('Location: preprocessing.php?error=' . urlencode('Preprocessing gagal (transaksi dibatalkan): ' . $e->getMessage()));
    exit;
}
$db->autocommit(true);

// Hapus duplikat otomatis (teks_asli identik) di batch ini setelah
// preprocessing selesai. Lihat includes/Dedup.php untuk detail logikanya --
// fungsi yang sama juga dipanggil otomatis setiap kali halaman Preprocessing
// / Hasil Pre-Processing dibuka, jadi batch lama yang sudah 100% "Selesai"
// pun tetap ikut dibersihkan tanpa perlu klik apapun di sini.
$duplicateRemoved = autoRemoveDuplicates($db, $batch);

$redirectVal = isset($_POST['redirect']) ? $_POST['redirect'] : '';
$redirectTo = $redirectVal === 'hasil'
    ? 'preprocessing_result.php?batch=' . urlencode($batch) . '&reprocessed=1&count=' . $count . '&duplicate_removed=' . $duplicateRemoved
    : 'preprocessing.php?success=1&count=' . $count . '&duplicate_removed=' . $duplicateRemoved;
header('Location: ' . $redirectTo);
exit;
