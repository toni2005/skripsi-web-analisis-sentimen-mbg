<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();
$pageTitle = 'Dashboard';
include __DIR__ . '/templates/header.php';

// Statistik ringkas
$totalData = $db->query("SELECT COUNT(*) c FROM dataset")->fetch_assoc()['c'];
$totalSelesai = $db->query("SELECT COUNT(*) c FROM dataset WHERE status_preprocessing='selesai'")->fetch_assoc()['c'];
$totalBerlabel = $db->query("SELECT COUNT(*) c FROM dataset WHERE label IS NOT NULL")->fetch_assoc()['c'];
$totalTraining = $db->query("SELECT COUNT(*) c FROM training_history")->fetch_assoc()['c'];

// Distribusi sentimen hanya dihitung dari data yang SUDAH berlabel
$distribusi = $db->query("SELECT label, COUNT(*) jumlah FROM dataset WHERE label IS NOT NULL GROUP BY label");
$sentimentColors = ['positif' => '#16a34a', 'negatif' => '#dc2626', 'netral' => '#94a3b8'];
$distLabels = []; $distValues = []; $distColors = [];
while ($row = $distribusi->fetch_assoc()) {
    $labelKey = strtolower($row['label']);
    $distLabels[] = ucfirst($row['label']);
    $distValues[] = (int)$row['jumlah'];
    $distColors[] = isset($sentimentColors[$labelKey]) ? $sentimentColors[$labelKey] : '#8a95a1';
}

// Riwayat training terakhir untuk perbandingan cepat
$lastRF = $db->query("SELECT * FROM training_history WHERE algoritma='random_forest' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
$lastKNN = $db->query("SELECT * FROM training_history WHERE algoritma='knn' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
?>

<div class="grid grid-5">
    <div class="stat-card">
        <div class="label">Total Data Dataset</div>
        <div class="value"><?= $totalData ?></div>
    </div>
    <div class="stat-card accent">
        <div class="label">Sudah Dipreprocessing</div>
        <div class="value"><?= $totalSelesai ?></div>
    </div>
    <div class="stat-card accent">
        <div class="label">Sudah Berlabel</div>
        <div class="value"><?= $totalBerlabel ?></div>
    </div>
    <div class="stat-card">
        <div class="label">Total Percobaan Training</div>
        <div class="value"><?= $totalTraining ?></div>
    </div>
    <div class="stat-card <?= ($lastRF && $lastKNN && $lastRF['akurasi'] >= $lastKNN['akurasi']) ? '' : 'danger' ?>">
        <div class="label">Model Terbaik (Akurasi)</div>
        <div class="value" style="font-size:18px;">
            <?php
            if ($lastRF && $lastKNN) {
                echo $lastRF['akurasi'] >= $lastKNN['akurasi']
                    ? 'Random Forest (' . round($lastRF['akurasi']*100,1) . '%)'
                    : 'KNN (' . round($lastKNN['akurasi']*100,1) . '%)';
            } else {
                echo '-';
            }
            ?>
        </div>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <h2>Distribusi Sentimen Dataset</h2>
        <?php if ($totalBerlabel > 0): ?>
            <div class="chart-wrap"><canvas id="pieChart"></canvas></div>
            <?php if ($totalBerlabel < $totalData): ?>
                <p class="text-muted mt-16"><?= $totalData - $totalBerlabel ?> data lain masih belum berlabel. Lihat menu <a href="pelabelan.php">Pelabelan Data</a>.</p>
            <?php endif; ?>
        <?php else: ?>
            <p class="text-muted">Belum ada data berlabel. Silakan upload dataset lalu jalankan Preprocessing &amp; Pelabelan Data.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>Perbandingan Akurasi Terakhir</h2>
        <?php if ($lastRF && $lastKNN): ?>
            <div class="chart-wrap"><canvas id="barChart"></canvas></div>
        <?php else: ?>
            <p class="text-muted">Belum ada hasil training. Silakan jalankan training model di menu Training Model.</p>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h2>Alur Kerja Sistem</h2>
    <div class="grid grid-5">
        <div class="stat-card">
            <div class="label">1. Upload Data Mentah</div>
            <p class="text-muted" style="margin-top:6px;">Upload CSV hasil scraping/gabungan (label tidak wajib ada).</p>
        </div>
        <div class="stat-card">
            <div class="label">2. Preprocessing</div>
            <p class="text-muted" style="margin-top:6px;">Cleaning, case folding, normalisasi, tokenizing, dan stopword removal.</p>
        </div>
        <div class="stat-card">
            <div class="label">3. Pelabelan Data</div>
            <p class="text-muted" style="margin-top:6px;">Label otomatis berbasis kamus sentimen (lexicon-based), bisa dikoreksi manual.</p>
        </div>
        <div class="stat-card">
            <div class="label">4. Training Model</div>
            <p class="text-muted" style="margin-top:6px;">Ekstraksi fitur TF-IDF lalu latih model Random Forest dan KNN dari UI.</p>
        </div>
        <div class="stat-card">
            <div class="label">5. Evaluasi & Uji Coba</div>
            <p class="text-muted" style="margin-top:6px;">Bandingkan akurasi, precision, recall, F1-score, dan uji prediksi teks baru.</p>
        </div>
    </div>
</div>

<script>
<?php if ($totalBerlabel > 0): ?>
new Chart(document.getElementById('pieChart'), {
    type: 'doughnut',
    data: {
        labels: <?= json_encode($distLabels) ?>,
        datasets: [{
            data: <?= json_encode($distValues) ?>,
            backgroundColor: <?= json_encode($distColors) ?>
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});
<?php endif; ?>

<?php if ($lastRF && $lastKNN): ?>
new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
        labels: ['Accuracy', 'Precision', 'Recall', 'F1-Score'],
        datasets: [
            {
                label: 'Random Forest',
                data: [<?= $lastRF['akurasi']*100 ?>, <?= $lastRF['presisi']*100 ?>, <?= $lastRF['recall_score']*100 ?>, <?= $lastRF['f1_score']*100 ?>],
                backgroundColor: '#2f6f4f'
            },
            {
                label: 'KNN',
                data: [<?= $lastKNN['akurasi']*100 ?>, <?= $lastKNN['presisi']*100 ?>, <?= $lastKNN['recall_score']*100 ?>, <?= $lastKNN['f1_score']*100 ?>],
                backgroundColor: '#e8a33d'
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                max: 100,
                ticks: { callback: function(value) { return value + '%'; } }
            }
        },
        plugins: {
            legend: { position: 'bottom' },
            tooltip: { callbacks: { label: function(ctx) { return ctx.dataset.label + ': ' + ctx.parsed.y.toFixed(2) + '%'; } } }
        }
    }
});
<?php endif; ?>
</script>

<?php include __DIR__ . '/templates/footer.php'; ?>
