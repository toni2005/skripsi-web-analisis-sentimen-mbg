<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
require_once __DIR__ . '/../includes/Preprocessing.php';

$db = getDB();
$batch = isset($_GET['batch']) ? $_GET['batch'] : '';

if ($batch === '') {
    header('Location: preprocessing_result.php');
    exit;
}

$preprocessing = new Preprocessing($db);

$stmt = $db->prepare("SELECT teks_asli, label, teks_preprocessing, tokens, status_preprocessing FROM dataset WHERE dataset_batch = ? ORDER BY id ASC");
$stmt->bind_param('s', $batch);
$stmt->execute();
// BUG FIX: pakai stmtFetchAll() (bukan get_result() langsung) supaya tetap
// jalan di hosting yang mysqli-nya tidak dikompilasi dengan mysqlnd.
$rows = stmtFetchAll($stmt);

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="hasil_preprocessing_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $batch) . '.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['teks_asli', 'label', 'case_folding', 'cleaning', 'normalisasi', 'tokenisasi', 'stopword', 'hasil_akhir']);

foreach ($rows as $row) {
    if ($row['status_preprocessing'] === 'selesai' && $row['teks_preprocessing'] !== null) {
        // Satu sumber kebenaran untuk semua kolom antara (lihat
        // Preprocessing::processWithTrace) - urutannya dijamin sama persis
        // dengan proses asli yang menghasilkan teks_preprocessing yang
        // tersimpan di database.
        $trace = $preprocessing->processWithTrace($row['teks_asli']);
        $hasilAkhir = $row['teks_preprocessing']; // tetap pakai hasil final tersimpan (konsisten dgn training)

        fputcsv($output, [
            $row['teks_asli'],
            $row['label'],
            $trace['case_folding'],
            $trace['cleaning'],
            $trace['normalisasi'],
            implode(' ', $trace['tokenize']),
            implode(' ', $trace['stopword_removal']),
            $hasilAkhir,
        ]);
    }
}
fclose($output);
exit;
