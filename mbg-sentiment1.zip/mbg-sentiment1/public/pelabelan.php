<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/Lexicon.php';
$db = getDB();
$pageTitle = 'Pelabelan Data';
include __DIR__ . '/templates/header.php';

$lexicon = new Lexicon();

$batches = $db->query("
    SELECT dataset_batch,
           COUNT(*) total,
           SUM(status_preprocessing='selesai') sudah_preprocessing,
           SUM(status_pelabelan='selesai') sudah_label,
           SUM(status_preprocessing='selesai' AND status_pelabelan='belum') siap_dilabeli
    FROM dataset GROUP BY dataset_batch
");
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert success">
        Pelabelan otomatis selesai! <?= (int)$_GET['count'] ?> baris data diberi label berbasis kamus sentimen
        (<?= (int)(isset($_GET['pos']) ? $_GET['pos'] : 0) ?> positif, <?= (int)(isset($_GET['neg']) ? $_GET['neg'] : 0) ?> negatif, <?= (int)(isset($_GET['net']) ? $_GET['net'] : 0) ?> netral).
        Periksa &amp; koreksi hasilnya bila perlu di menu <a href="dataset.php">Kelola Dataset</a>,
        lalu lanjutkan ke <a href="training.php">Training Model</a>.
    </div>
<?php endif; ?>
<?php if (isset($_GET['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
<?php endif; ?>

<div class="card">
    <h2>Tentang Pelabelan Otomatis</h2>
    <p class="text-muted mt-16">
        Karena data mentah hasil scraping umumnya tidak memiliki label sentimen, sistem memberi label
        awal secara <strong>otomatis berbasis kamus sentimen Bahasa Indonesia (Lexicon-Based Labeling —
        InSet Lexicon, <?= number_format($lexicon->jumlahKata(), 0, ',', '.') ?> kata)</strong>. Setiap token hasil preprocessing
        dicocokkan dengan kamus; skor total token menentukan label:
    </p>
    <div class="grid grid-3 mt-16">
        <div class="stat-card"><div class="label">Skor &gt; 0</div><p class="text-muted mt-16"><span class="badge positif">positif</span></p></div>
        <div class="stat-card"><div class="label">Skor &lt; 0</div><p class="text-muted mt-16"><span class="badge negatif">negatif</span></p></div>
        <div class="stat-card"><div class="label">Skor = 0</div><p class="text-muted mt-16"><span class="badge netral">netral</span></p></div>
    </div>
</div>

<div class="card">
    <h2>Status Pelabelan per Batch</h2>
    <table class="mt-16">
        <tr><th>Nama Batch</th><th>Total</th><th>Sudah Preprocessing</th><th>Sudah Berlabel</th><th>Progress</th><th>Aksi</th></tr>
        <?php if ($batches->num_rows === 0): ?>
            <tr><td colspan="6" class="text-muted">Belum ada dataset. Silakan upload terlebih dahulu.</td></tr>
        <?php endif; ?>
        <?php while ($b = $batches->fetch_assoc()):
            $pct = $b['total'] > 0 ? round(($b['sudah_label'] / $b['total']) * 100) : 0;
        ?>
        <tr>
            <td><strong><?= htmlspecialchars($b['dataset_batch']) ?></strong></td>
            <td><?= $b['total'] ?></td>
            <td><?= $b['sudah_preprocessing'] ?></td>
            <td><?= $b['sudah_label'] ?></td>
            <td style="min-width:160px;">
                <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:<?= $pct ?>%"></div></div>
                <span class="text-muted"><?= $pct ?>%</span>
            </td>
            <td>
                <?php if ((int)$b['siap_dilabeli'] > 0): ?>
                    <form action="process_pelabelan.php" method="POST" style="display:inline;">
                        <input type="hidden" name="batch" value="<?= htmlspecialchars($b['dataset_batch']) ?>">
                        <button type="submit" class="btn small">Jalankan Pelabelan (<?= $b['siap_dilabeli'] ?> baris)</button>
                    </form>
                <?php elseif ((int)$b['sudah_preprocessing'] === 0): ?>
                    <span class="text-muted">Jalankan Preprocessing dulu</span>
                <?php else: ?>
                    <span class="badge selesai">Selesai</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include __DIR__ . '/templates/footer.php'; ?>
