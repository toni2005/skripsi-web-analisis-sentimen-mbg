<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();
$pageTitle = 'Kelola Dataset';

// Hapus per batch
if (isset($_GET['delete_batch'])) {
    $batch = $_GET['delete_batch'];

    // Hitung dulu jumlah baris yang akan terhapus, untuk pesan konfirmasi
    $stmtCount = $db->prepare("SELECT COUNT(*) c FROM dataset WHERE dataset_batch = ?");
    $stmtCount->bind_param('s', $batch);
    $stmtCount->execute();
    $deletedCount = (int)$stmtCount->get_result()->fetch_assoc()['c'];

    $stmt = $db->prepare("DELETE FROM dataset WHERE dataset_batch = ?");
    $stmt->bind_param('s', $batch);
    $stmt->execute();

    // BUG FIX: sebelumnya hanya menghapus baris di tabel `dataset`, tapi
    // snapshot jumlah data mentah di `dataset_upload_log` (dipakai untuk
    // kolom "Total Data" di halaman Preprocessing) TIDAK ikut dihapus.
    // Akibatnya kalau nama batch yang sama dipakai lagi untuk upload baru,
    // process_upload.php menjumlahkan (ON DUPLICATE KEY UPDATE ... + ...)
    // total baru dengan sisa total lama yang sudah tidak relevan, sehingga
    // angka "Total Data" jadi 2x lipat (atau lebih) dari jumlah baris yang
    // sebenarnya ada. Perbaikan: hapus juga snapshot log untuk batch ini,
    // supaya kalau nama batch dipakai lagi, hitungannya mulai bersih dari 0.
    $logTableExists = $db->query("SHOW TABLES LIKE 'dataset_upload_log'");
    if ($logTableExists && $logTableExists->num_rows > 0) {
        $stmtLog = $db->prepare("DELETE FROM dataset_upload_log WHERE dataset_batch = ?");
        $stmtLog->bind_param('s', $batch);
        $stmtLog->execute();
    }

    // Ikut hapus riwayat training (dan otomatis riwayat perbandingan model,
    // karena halaman Training Model & Perbandingan Model membaca dari tabel
    // yang sama, training_history) untuk batch yang dihapus. Tanpa ini,
    // baris riwayat training untuk batch yang sudah tidak ada datanya akan
    // tetap muncul di menu Training Model dan Perbandingan Model.
    $trainingTableExists = $db->query("SHOW TABLES LIKE 'training_history'");
    if ($trainingTableExists && $trainingTableExists->num_rows > 0) {
        $stmtTraining = $db->prepare("DELETE FROM training_history WHERE dataset_batch = ?");
        $stmtTraining->bind_param('s', $batch);
        $stmtTraining->execute();
    }

    header('Location: dataset.php?batch_deleted=1&batch_name=' . urlencode($batch) . '&batch_count=' . $deletedCount);
    exit;
}

// Hapus per baris
// BUG FIX: sebelumnya redirect selalu balik ke dataset.php?deleted=1 tanpa
// menyertakan filter batch/nomor halaman yang sedang dibuka, sehingga
// tampilan tiba-tiba "melompat" ke Semua Batch & halaman 1 setelah hapus 1 baris.
if (isset($_GET['delete_id'])) {
    $id = (int)$_GET['delete_id'];
    $stmt = $db->prepare("DELETE FROM dataset WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $keepBatch = urlencode(isset($_GET['batch']) ? $_GET['batch'] : '');
    $keepPage = (int)(isset($_GET['page']) ? $_GET['page'] : 1);
    header("Location: dataset.php?deleted=1&batch=$keepBatch&page=$keepPage");
    exit;
}

include __DIR__ . '/templates/header.php';

// Filter batch & label
$batchFilter = isset($_GET['batch']) ? $_GET['batch'] : '';
$labelFilter = isset($_GET['label']) ? $_GET['label'] : '';
// REVISI DOSEN: filter "Dipakai Untuk" (train/test/unused) supaya data yang
// benar-benar dipakai sebagai data UJI saat training terakhir bisa dilihat/
// diverifikasi langsung di sini, bukan cuma dipercaya dari angka akurasi saja.
$pakaiFilter = isset($_GET['pakai']) ? $_GET['pakai'] : '';

$page = max(1, (int)(isset($_GET['page']) ? $_GET['page'] : 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$whereParts = [];
if ($batchFilter !== '') {
    $whereParts[] = "dataset_batch = '" . $db->real_escape_string($batchFilter) . "'";
}
if ($labelFilter === 'belum') {
    $whereParts[] = "label IS NULL";
} elseif (in_array($labelFilter, ['positif', 'negatif', 'netral'])) {
    $whereParts[] = "label = '" . $db->real_escape_string($labelFilter) . "'";
}
if (in_array($pakaiFilter, ['train', 'test', 'unused'], true)) {
    $whereParts[] = "dipakai_untuk = '" . $db->real_escape_string($pakaiFilter) . "'";
}
$where = !empty($whereParts) ? 'WHERE ' . implode(' AND ', $whereParts) : '';

$totalRows = $db->query("SELECT COUNT(*) c FROM dataset $where")->fetch_assoc()['c'];
$totalPages = max(1, ceil($totalRows / $perPage));

$dataResult = $db->query("SELECT * FROM dataset $where ORDER BY id DESC LIMIT $perPage OFFSET $offset");
?>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert success">Data berhasil dihapus.</div>
<?php endif; ?>
<?php if (isset($_GET['batch_deleted'])): ?>
    <div class="alert success">
        Batch <strong><?= htmlspecialchars(isset($_GET['batch_name']) ? $_GET['batch_name'] : '') ?></strong> berhasil dihapus
        (<?= (int)(isset($_GET['batch_count']) ? $_GET['batch_count'] : 0) ?> data terhapus).
        Silakan <a href="upload.php">upload dataset baru</a> jika ingin memulai dari awal.
    </div>
<?php endif; ?>
<?php if (isset($_GET['updated'])): ?>
    <div class="alert success">Label berhasil diperbarui secara manual.</div>
<?php endif; ?>

<div class="card">
    <div class="flex-between">
        <h2 style="margin:0;">Daftar Dataset (<?= $totalRows ?> data)</h2>
        <button type="button" id="btnHapusBatch" class="btn danger small" <?= $batchFilter === '' ? 'disabled' : '' ?>
                onclick="hapusBatchTerpilih()">🗑 Hapus Batch</button>
    </div>
    <div style="margin-top:12px;">
        <form method="GET" class="flex" id="filterForm">
            <select name="batch" id="batchSelect" onchange="this.form.submit()">
                <option value="">-- Semua Batch --</option>
                <?php
                $batchCounts = [];
                $batchList = $db->query("SELECT dataset_batch, COUNT(*) c FROM dataset GROUP BY dataset_batch ORDER BY dataset_batch");
                while ($b = $batchList->fetch_assoc()) {
                    $batchCounts[$b['dataset_batch']] = (int)$b['c'];
                }
                foreach ($batchCounts as $batchName => $batchCount):
                ?>
                    <option value="<?= htmlspecialchars($batchName) ?>"
                            data-count="<?= $batchCount ?>"
                            <?= $batchFilter === $batchName ? 'selected' : '' ?>>
                        <?= htmlspecialchars($batchName) ?> (<?= $batchCount ?> data)
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="label" onchange="this.form.submit()">
                <option value="">-- Semua Label --</option>
                <option value="belum" <?= $labelFilter === 'belum' ? 'selected' : '' ?>>Belum Berlabel</option>
                <option value="positif" <?= $labelFilter === 'positif' ? 'selected' : '' ?>>Positif</option>
                <option value="negatif" <?= $labelFilter === 'negatif' ? 'selected' : '' ?>>Negatif</option>
                <option value="netral" <?= $labelFilter === 'netral' ? 'selected' : '' ?>>Netral</option>
            </select>
            <select name="pakai" onchange="this.form.submit()">
                <option value="">-- Semua (Dipakai Untuk) --</option>
                <option value="train" <?= $pakaiFilter === 'train' ? 'selected' : '' ?>>Data Latih (Train)</option>
                <option value="test" <?= $pakaiFilter === 'test' ? 'selected' : '' ?>>Data Uji (Test)</option>
                <option value="unused" <?= $pakaiFilter === 'unused' ? 'selected' : '' ?>>Belum Dipakai (Unused)</option>
            </select>
        </form>
    </div>

    <script>
    function hapusBatchTerpilih() {
        var select = document.getElementById('batchSelect');
        var batchName = select.value;
        if (!batchName) {
            alert('Pilih batch yang ingin dihapus terlebih dahulu pada dropdown di sebelah kiri.');
            return;
        }
        var selectedOption = select.options[select.selectedIndex];
        var count = selectedOption.getAttribute('data-count') || '0';
        var confirmMsg = 'Hapus semua data pada batch "' + batchName + '" (' + count + ' data)?\n\n' +
                          'Tindakan ini tidak bisa dibatalkan. Setelah dihapus, Anda bisa upload dataset baru dari awal.';
        if (confirm(confirmMsg)) {
            window.location.href = 'dataset.php?delete_batch=' + encodeURIComponent(batchName);
        }
    }

    // Aktifkan/nonaktifkan tombol hapus mengikuti pilihan dropdown secara langsung
    document.getElementById('batchSelect').addEventListener('change', function () {
        document.getElementById('btnHapusBatch').disabled = (this.value === '');
    });
    </script>

    <div class="mt-16" style="overflow-x:auto;">
    <table>
        <tr>
            <th>ID</th><th>Teks Asli</th><th>Platform</th><th>Label</th><th>Koreksi Label</th><th>Batch</th><th>Preprocessing</th><th>Dipakai Untuk</th><th>Aksi</th>
        </tr>
        <?php if ($dataResult->num_rows === 0): ?>
            <tr><td colspan="9" class="text-muted">Belum ada data. Silakan upload dataset terlebih dahulu.</td></tr>
        <?php endif; ?>
        <?php while ($row = $dataResult->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars(mb_strimwidth($row['teks_asli'], 0, 60, '...')) ?></td>
                <td><?= $row['platform'] ? htmlspecialchars($row['platform']) : '<span class="text-muted">-</span>' ?></td>
                <td>
                    <?php if ($row['label']): ?>
                        <span class="badge <?= $row['label'] ?>"><?= $row['label'] ?></span>
                    <?php else: ?>
                        <span class="badge belum">belum berlabel</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="update_label.php" method="POST" class="flex" style="gap:4px;">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="hidden" name="batch" value="<?= htmlspecialchars($batchFilter) ?>">
                        <input type="hidden" name="page" value="<?= $page ?>">
                        <select name="label" style="padding:4px 6px;font-size:12px;">
                            <option value="">--pilih--</option>
                            <option value="positif" <?= $row['label'] === 'positif' ? 'selected' : '' ?>>Positif</option>
                            <option value="negatif" <?= $row['label'] === 'negatif' ? 'selected' : '' ?>>Negatif</option>
                            <option value="netral" <?= $row['label'] === 'netral' ? 'selected' : '' ?>>Netral</option>
                        </select>
                        <button type="submit" class="btn secondary small">Simpan</button>
                    </form>
                </td>
                <td><?= htmlspecialchars($row['dataset_batch']) ?></td>
                <td><span class="badge <?= $row['status_preprocessing'] ?>"><?= $row['status_preprocessing'] ?></span></td>
                <td>
                    <?php
                    $pakaiLabel = ['train' => 'Latih (Train)', 'test' => 'Uji (Test)', 'unused' => 'Belum dipakai'];
                    $pakaiVal = $row['dipakai_untuk'] ? $row['dipakai_untuk'] : 'unused';
                    ?>
                    <span class="badge <?= $pakaiVal ?>"><?= $pakaiLabel[$pakaiVal] ?></span>
                </td>
                <td><a href="?delete_id=<?= $row['id'] ?>&batch=<?= urlencode($batchFilter) ?>"
                       onclick="return confirm('Hapus data ini?')" style="color:#c0392b;font-size:12.5px;">Hapus</a></td>
            </tr>
        <?php endwhile; ?>
    </table>
    </div>

    <div class="pagination">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="?page=<?= $p ?>&batch=<?= urlencode($batchFilter) ?>&label=<?= urlencode($labelFilter) ?>&pakai=<?= urlencode($pakaiFilter) ?>" class="<?= $p === $page ? 'current' : '' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
</div>

<?php include __DIR__ . '/templates/footer.php'; ?>
