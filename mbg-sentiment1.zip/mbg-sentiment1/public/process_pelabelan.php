<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
require_once __DIR__ . '/../includes/Lexicon.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: pelabelan.php');
    exit;
}

$batch = isset($_POST['batch']) ? $_POST['batch'] : '';
if ($batch === '') {
    header('Location: pelabelan.php');
    exit;
}

set_time_limit(300);

$lexicon = new Lexicon();

// Hanya proses baris yang SUDAH dipreprocessing (butuh 'tokens') dan BELUM berlabel
$stmt = $db->prepare("SELECT id, tokens FROM dataset WHERE dataset_batch = ? AND status_preprocessing = 'selesai' AND status_pelabelan = 'belum'");
$stmt->bind_param('s', $batch);
$stmt->execute();
$rows = stmtFetchAll($stmt);

$update = $db->prepare("UPDATE dataset SET label = ?, skor_sentimen = ?, status_pelabelan = 'selesai', label_sumber = 'otomatis' WHERE id = ?");

// PERBAIKAN PERFORMA: sama seperti upload & preprocessing — bungkus dalam
// transaction, commit per chunk 500 baris (bukan per baris) supaya jumlah
// commit ke disk jauh lebih sedikit untuk dataset ribuan baris.
$count = 0;
$jumlahPos = 0; $jumlahNeg = 0; $jumlahNet = 0;
$sinceLastCommit = 0;
const PELABELAN_COMMIT_CHUNK = 500;

$db->autocommit(false);
$db->begin_transaction();
try {
    foreach ($rows as $row) {
        $tokens = json_decode($row['tokens'], true);
        if (!is_array($tokens)) $tokens = [];

        $hasil = $lexicon->scoreTokens($tokens);
        $label = $hasil['label'];
        $skor = $hasil['skor'];
        $id = $row['id'];

        if ($label === 'positif') $jumlahPos++;
        elseif ($label === 'negatif') $jumlahNeg++;
        else $jumlahNet++;

        $update->bind_param('sdi', $label, $skor, $id);
        $update->execute();
        $count++;
        $sinceLastCommit++;

        if ($sinceLastCommit >= PELABELAN_COMMIT_CHUNK) {
            $db->commit();
            $db->begin_transaction();
            $sinceLastCommit = 0;
        }
    }
    $db->commit();
} catch (Throwable $e) {
    $db->rollback();
    $db->autocommit(true);
    header('Location: pelabelan.php?error=' . urlencode('Pelabelan gagal (transaksi dibatalkan): ' . $e->getMessage()));
    exit;
}
$db->autocommit(true);

header('Location: pelabelan.php?success=1&count=' . $count . '&pos=' . $jumlahPos . '&neg=' . $jumlahNeg . '&net=' . $jumlahNet);
exit;
