<?php if (!isset($pageTitle)) $pageTitle = 'Dashboard'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> | Analisis Sentimen MBG</title>
    <link rel="stylesheet" href="../assets/css/style.css?v=<?= filemtime(__DIR__ . '/../../assets/css/style.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
</head>
<body>
<div class="layout">
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <span class="brand-icon">🍱</span>
            <div>
                <div class="brand-title">Analisis Sentimen</div>
                <div class="brand-sub">Program MBG · RF vs KNN</div>
            </div>
            <button class="sidebar-close" id="sidebarClose" aria-label="Tutup menu">&times;</button>
        </div>
        <nav>
            <a href="index.php" class="<?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">
                <span>📊</span> Dashboard
            </a>
            <div class="nav-divider">Data</div>
            <a href="upload.php" class="<?= basename($_SERVER['PHP_SELF']) === 'upload.php' ? 'active' : '' ?>">
                <span>📁</span> Upload Dataset
            </a>
            <a href="dataset.php" class="<?= basename($_SERVER['PHP_SELF']) === 'dataset.php' ? 'active' : '' ?>">
                <span>🗂️</span> Kelola Dataset
            </a>
            <a href="preprocessing.php" class="<?= basename($_SERVER['PHP_SELF']) === 'preprocessing.php' ? 'active' : '' ?>">
                <span>🧹</span> Preprocessing
            </a>
            <a href="preprocessing_result.php" class="<?= basename($_SERVER['PHP_SELF']) === 'preprocessing_result.php' ? 'active' : '' ?>">
                <span>📋</span> Hasil Pre-Processing
            </a>
            <a href="pelabelan.php" class="<?= basename($_SERVER['PHP_SELF']) === 'pelabelan.php' ? 'active' : '' ?>">
                <span>🏷️</span> Pelabelan Data
            </a>
            <div class="nav-divider">Klasifikasi</div>
            <a href="training.php" class="<?= basename($_SERVER['PHP_SELF']) === 'training.php' ? 'active' : '' ?>">
                <span>⚙️</span> Training Model
            </a>
            <a href="comparison.php" class="<?= basename($_SERVER['PHP_SELF']) === 'comparison.php' ? 'active' : '' ?>">
                <span>📈</span> Perbandingan Model
            </a>
            <a href="pengujian.php" class="<?= basename($_SERVER['PHP_SELF']) === 'pengujian.php' ? 'active' : '' ?>">
                <span>📄</span> Hasil Pengujian
            </a>
            <a href="../index.php" class="mobile-only-link">
                <span>←</span> Beranda
            </a>
        </nav>
        <div class="sidebar-footer">
            Skripsi Analisis Sentimen<br>Program MBG &copy; <?= date('Y') ?>
        </div>
    </aside>
    <main class="content">
        <header class="topbar">
            <h1><?= htmlspecialchars($pageTitle) ?></h1>
            <div class="topbar-links">
                <a class="beranda-link" href="../index.php">← Beranda</a>
                <button class="navbar-toggle" id="navToggle" aria-label="Buka menu" aria-expanded="false">
                    <span></span><span></span><span></span>
                </button>
            </div>
        </header>
        <div class="content-body">
