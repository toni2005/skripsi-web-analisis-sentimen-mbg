<?php
/**
 * Halaman "Hasil Pengujian" (REVISI DOSEN)
 * ------------------------------------------------
 * Sebelumnya sistem hanya menampilkan angka akurasi/precision/recall/F1
 * agregat (di menu Perbandingan Model) tanpa menunjukkan BUKTI baris per
 * baris bahwa angka tsb benar-benar dihitung dari DATA UJI (data testing)
 * hasil stratified train-test split, bukan dari data latih atau seluruh data.
 *
 * Halaman ini membaca detail hasil pengujian (id data, teks asli, label
 * aktual, label prediksi, benar/salah) yang disimpan di file model JSON oleh
 * process_training.php (lihat variabel $testDetail di sana), lalu
 * menampilkannya sebagai tabel yang bisa ditunjukkan ke dosen pembimbing/
 * penguji sebagai bukti pengujian.
 */
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
// Jaga-jaga tambahan: kalau suatu saat jumlah data uji sangat besar, file
// detail pengujian ikut membesar. Naikkan memory_limit runtime HANYA jika
// batas bawaan server lebih kecil dari 256M (tidak mengubah php.ini, dan
// tidak berefek kalau host sudah membatasi lebih ketat lewat disable_functions).
$currentLimit = ini_get('memory_limit');
if ($currentLimit !== '-1' && (int) $currentLimit < 256) {
    @ini_set('memory_limit', '256M');
}
$db = getDB();
$pageTitle = 'Hasil Pengujian';
include __DIR__ . '/templates/header.php';

$modelDir = __DIR__ . '/../models';

$batchFilter = isset($_GET['batch']) ? $_GET['batch'] : '';
$algoFilter = isset($_GET['algoritma']) ? $_GET['algoritma'] : 'random_forest';
if (!in_array($algoFilter, ['random_forest', 'knn'], true)) $algoFilter = 'random_forest';

$statusFilter = isset($_GET['status']) ? $_GET['status'] : ''; // '', 'benar', 'salah'

$batches = $db->query("SELECT DISTINCT dataset_batch FROM training_history ORDER BY dataset_batch");

$where = "algoritma = '" . $db->real_escape_string($algoFilter) . "'";
if ($batchFilter !== '') {
    $where .= " AND dataset_batch = '" . $db->real_escape_string($batchFilter) . "'";
}
// REVISI: sebelumnya halaman ini selalu mengambil riwayat training TERBARU
// (ORDER BY created_at DESC), sehingga kalau ada beberapa kali percobaan
// training dengan parameter berbeda (mis. beberapa nilai k pada KNN), yang
// tampil bisa jadi bukan model dengan performa terbaik. Sekarang halaman
// mengambil riwayat training dengan AKURASI TERTINGGI untuk kombinasi
// algoritma/batch yang dipilih (created_at dipakai hanya sebagai tie-breaker
// jika ada beberapa training dengan akurasi persis sama).
$lastTraining = $db->query("SELECT * FROM training_history WHERE $where ORDER BY akurasi DESC, created_at DESC LIMIT 1")->fetch_assoc();

// Info tambahan: total berapa kali training pernah dilakukan untuk kombinasi
// ini, supaya di UI jelas bahwa hasil yang ditampilkan sudah dipilih dari
// beberapa kandidat, bukan cuma satu-satunya percobaan.
$trainingCountRow = $db->query("SELECT COUNT(*) AS n FROM training_history WHERE $where")->fetch_assoc();
$trainingCount = $trainingCountRow ? (int) $trainingCountRow['n'] : 0;

$testDetail = [];
$evalRecap = null;
$modelReadError = '';

if ($lastTraining) {
    // REVISI: detail pengujian dibaca dari file TERPISAH yang jauh lebih
    // kecil (lihat process_training.php), supaya halaman ini tidak perlu
    // membaca/men-decode file model utama yang bisa berukuran belasan MB
    // (terutama untuk Random Forest) dan menghabiskan memory_limit PHP.
    $testDetailPath = $modelDir . '/testdetail_' . $lastTraining['model_path'];
    if (is_file($testDetailPath)) {
        $detailJson = json_decode(file_get_contents($testDetailPath), true);
        if (isset($detailJson['test_detail']) && is_array($detailJson['test_detail'])) {
            $testDetail = $detailJson['test_detail'];
            $evalRecap = isset($detailJson['evaluation_recap']) ? $detailJson['evaluation_recap'] : null;
        } else {
            $modelReadError = 'File detail pengujian ditemukan tapi formatnya tidak sesuai. Silakan latih ulang model.';
        }
    } else {
        // Model lama (dilatih sebelum revisi ini) belum menyimpan file detail terpisah.
        $modelReadError = 'Model ini dilatih sebelum fitur "Hasil Pengujian" ditambahkan, sehingga detail per baris data uji belum tersimpan. Silakan latih ulang model di menu Training Model untuk melihat detail pengujian.';
    }
}

if ($statusFilter === 'benar') {
    $testDetail = array_values(array_filter($testDetail, function ($d) { return $d['benar']; }));
} elseif ($statusFilter === 'salah') {
    $testDetail = array_values(array_filter($testDetail, function ($d) { return !$d['benar']; }));
}

$page = max(1, (int) (isset($_GET['page']) ? $_GET['page'] : 1));
$perPage = 25;
$totalRows = count($testDetail);
$totalPages = max(1, (int) ceil($totalRows / $perPage));
$page = min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$pageRows = array_slice($testDetail, $offset, $perPage);

function qs($params, $overrides) {
    $merged = array_merge($params, $overrides);
    return '?' . http_build_query($merged);
}
$baseParams = ['batch' => $batchFilter, 'algoritma' => $algoFilter, 'status' => $statusFilter];
?>

<div class="card">
    <h2 style="margin-top:0;">📄 Hasil Pengujian per Data Uji</h2>
    <form method="GET" class="flex" style="flex-wrap:wrap;gap:10px;margin-top:12px;">
        <select name="batch" onchange="this.form.submit()">
            <option value="">-- Semua Batch --</option>
            <?php $batches->data_seek(0); while ($b = $batches->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" <?= $batchFilter === $b['dataset_batch'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($b['dataset_batch']) ?>
                </option>
            <?php endwhile; ?>
        </select>
        <select name="algoritma" onchange="this.form.submit()">
            <option value="random_forest" <?= $algoFilter === 'random_forest' ? 'selected' : '' ?>>🌲 Random Forest</option>
            <option value="knn" <?= $algoFilter === 'knn' ? 'selected' : '' ?>>📍 KNN</option>
        </select>
        <select name="status" onchange="this.form.submit()">
            <option value="" <?= $statusFilter === '' ? 'selected' : '' ?>>-- Semua Status --</option>
            <option value="benar" <?= $statusFilter === 'benar' ? 'selected' : '' ?>>✔ Prediksi Benar</option>
            <option value="salah" <?= $statusFilter === 'salah' ? 'selected' : '' ?>>✘ Prediksi Salah</option>
        </select>
    </form>
</div>

<?php if (!$lastTraining): ?>
    <div class="alert info">
        Belum ada riwayat training untuk kombinasi filter ini. Silakan latih model terlebih dahulu di menu
        <a href="training.php">Training Model</a>.
    </div>
<?php elseif ($modelReadError !== ''): ?>
    <div class="alert warning"><?= htmlspecialchars($modelReadError) ?></div>
<?php else: ?>

    <div class="card">
        <h2>Ringkasan Pengujian — <?= $algoFilter === 'random_forest' ? '🌲 Random Forest' : '📍 KNN' ?>
            <span class="badge benar" style="margin-left:8px;font-size:11px;vertical-align:middle;">🏆 Akurasi Tertinggi</span>
            <span class="text-muted" style="font-weight:500;font-size:13px;">
                (batch: <?= htmlspecialchars($lastTraining['dataset_batch']) ?>,
                dilatih <?= date('d/m/Y H:i', strtotime($lastTraining['created_at'])) ?>)
            </span>
        </h2>
        <div class="pill-stats">
            <div class="pill-stat total"><div class="num"><?= isset($evalRecap['jumlah_data_uji']) ? $evalRecap['jumlah_data_uji'] : $lastTraining['jumlah_data_test'] ?></div><div class="lbl">Total Data Uji</div></div>
            <div class="pill-stat positif"><div class="num"><?= isset($evalRecap['jumlah_benar']) ? $evalRecap['jumlah_benar'] : '-' ?></div><div class="lbl">Prediksi Benar</div></div>
            <div class="pill-stat negatif"><div class="num"><?= isset($evalRecap['jumlah_salah']) ? $evalRecap['jumlah_salah'] : '-' ?></div><div class="lbl">Prediksi Salah</div></div>
            <div class="pill-stat netral"><div class="num"><?= round($lastTraining['akurasi'] * 100, 2) ?>%</div><div class="lbl">Akurasi</div></div>
        </div>
    </div>

    <div class="card">
        <div class="flex-between">
            <h2 style="margin:0;">Detail Data Uji (<?= $totalRows ?> baris<?= $statusFilter !== '' ? ' — filter: ' . htmlspecialchars($statusFilter) : '' ?>)</h2>
        </div>
        <div class="mt-16" style="overflow-x:auto;">
        <table>
            <tr>
                <th>No</th><th>ID Data</th><th>Teks (Hasil Preprocessing)</th><th>Label Aktual</th><th>Label Prediksi</th><th>Status</th>
            </tr>
            <?php if (empty($pageRows)): ?>
                <tr><td colspan="6" class="text-muted">Tidak ada data pada filter ini.</td></tr>
            <?php endif; ?>
            <?php foreach ($pageRows as $i => $d): ?>
                <?php
                    // REVISI: kolom utama sekarang menampilkan teks yang SUDAH
                    // melalui tahap preprocessing (bukan teks asli), karena
                    // itulah bentuk data yang benar-benar diklasifikasikan oleh
                    // model. Untuk model lama yang dilatih SEBELUM revisi ini
                    // (belum menyimpan 'teks_preprocessing' di file detailnya),
                    // fallback ke teks asli supaya halaman tidak error, disertai
                    // penanda agar tidak disalahpahami sebagai teks preprocessing.
                    $isFallback = !isset($d['teks_preprocessing']);
                    $displayText = $isFallback ? $d['teks_asli'] : $d['teks_preprocessing'];
                    $tooltipText = 'Teks asli: ' . $d['teks_asli'];
                ?>
                <tr>
                    <td><?= $offset + $i + 1 ?></td>
                    <td><?= (int) $d['id'] ?></td>
                    <td title="<?= htmlspecialchars($tooltipText) ?>">
                        <?= htmlspecialchars(mb_strimwidth($displayText, 0, 70, '...')) ?>
                        <?php if ($isFallback): ?>
                            <span class="text-muted" style="font-size:10px;">(teks asli — model lama, latih ulang untuk lihat hasil preprocessing)</span>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge <?= htmlspecialchars($d['label_aktual']) ?>"><?= htmlspecialchars($d['label_aktual']) ?></span></td>
                    <td><span class="badge <?= htmlspecialchars($d['label_prediksi']) ?>"><?= htmlspecialchars($d['label_prediksi']) ?></span></td>
                    <td><?php if ($d['benar']): ?><span class="badge benar">✔ Benar</span><?php else: ?><span class="badge salah">✘ Salah</span><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        </div>

        <div class="pagination">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <a href="<?= qs($baseParams, ['page' => $p]) ?>" class="<?= $p === $page ? 'current' : '' ?>"><?= $p ?></a>
            <?php endfor; ?>
        </div>
    </div>

<?php endif; ?>

<?php include __DIR__ . '/templates/footer.php'; ?>
