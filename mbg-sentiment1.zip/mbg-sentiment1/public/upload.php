<?php
$pageTitle = 'Upload Dataset';
include __DIR__ . '/templates/header.php';
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert success">
        Dataset berhasil diupload! <?= (int)$_GET['count'] ?> baris data ditambahkan dengan nama batch
        <strong><?= htmlspecialchars($_GET['batch']) ?></strong>
        (<?= (int)(isset($_GET['labeled']) ? $_GET['labeled'] : 0) ?> baris sudah berlabel dari file, <?= (int)(isset($_GET['unlabeled']) ? $_GET['unlabeled'] : 0) ?> baris <em>belum berlabel</em>).
        <?php if (!empty($_GET['teks_col'])): ?>
            Kolom teks komentar yang terdeteksi otomatis: <strong><?= htmlspecialchars($_GET['teks_col']) ?></strong>.
        <?php endif; ?>
        <?php if (!empty($_GET['preprocessed']) && (int)$_GET['preprocessed'] > 0): ?>
            <?= (int)$_GET['preprocessed'] ?> baris juga sudah dikenali sebagai hasil preprocessing (langsung siap dipakai training).
        <?php endif; ?>
        <?php if (!empty($_GET['skipped']) && (int)$_GET['skipped'] > 0): ?>
            (<?= (int)$_GET['skipped'] ?> baris dilewati karena teks kosong)
        <?php endif; ?>
        Lanjutkan ke menu <a href="preprocessing.php">Preprocessing</a>, lalu <a href="pelabelan.php">Pelabelan Data</a> untuk baris yang belum berlabel.
    </div>
<?php endif; ?>
<?php if (!empty($_GET['delimiter_warning'])): ?>
    <div class="alert" style="background:#fff3cd;border:1px solid #ffe69c;color:#664d03;">
        ⚠️ <?= htmlspecialchars($_GET['delimiter_warning']) ?>
    </div>
<?php endif; ?>
<?php if (isset($_GET['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
<?php endif; ?>

<?php
$uploadMaxRaw = ini_get('upload_max_filesize');
$postMaxRaw = ini_get('post_max_size');
?>
<div class="alert info">
    Batas ukuran file saat ini di server Anda: <strong>upload_max_filesize = <?= htmlspecialchars($uploadMaxRaw) ?></strong>,
    <strong>post_max_size = <?= htmlspecialchars($postMaxRaw) ?></strong>.
    Jika file CSV Anda lebih besar dari itu, upload akan gagal. Untuk menaikkannya di XAMPP:
    buka <code>C:\xampp\php\php.ini</code>, ubah kedua nilai tersebut (mis. jadi <code>64M</code>),
    simpan, lalu <strong>restart Apache</strong> dari XAMPP Control Panel.
</div>

<div class="card">
    <h2>Upload Dataset CSV</h2>
    <form action="process_upload.php" method="POST" enctype="multipart/form-data">
        <label>Nama Batch Dataset</label>
        <input type="text" name="dataset_batch" placeholder="contoh: dataset_mbg_juli2026" required>

        <label>Pilih File CSV</label>
        <input type="file" name="file_csv" accept=".csv" required>

        <label>Pemisah Kolom (Delimiter)</label>
        <select name="delimiter">
            <option value=",">Koma (,)</option>
            <option value=";">Titik koma (;)</option>
        </select>

        <button type="submit" class="btn">Upload Dataset</button>
    </form>
</div>

<div class="card">
    <h2>Alur Kerja Setelah Upload</h2>
    <div class="pipeline mt-16">
        <span class="step blue">1. Upload Data Mentah</span><span class="arrow">→</span>
        <span class="step">2. Preprocessing</span><span class="arrow">→</span>
        <span class="step">3. Pelabelan Otomatis</span><span class="arrow">→</span>
        <span class="step">4. (Opsional) Koreksi Label Manual</span><span class="arrow">→</span>
        <span class="step blue">5. Training RF / KNN</span>
    </div>
</div>

<?php include __DIR__ . '/templates/footer.php'; ?>
