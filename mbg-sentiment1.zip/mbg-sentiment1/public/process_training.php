<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
require_once __DIR__ . '/../includes/TfIdf.php';
require_once __DIR__ . '/../includes/KNN.php';
require_once __DIR__ . '/../includes/RandomForest.php';
require_once __DIR__ . '/../includes/Evaluator.php';
require_once __DIR__ . '/../includes/Smote.php';

/**
 * Stratified train-test split: proporsi tiap kelas label dijaga sama antara
 * data latih & data uji (sesuai skripsi: "Pembagian dilakukan menggunakan
 * parameter stratify=..."). Sebelumnya sistem ini hanya memakai shuffle acak
 * biasa (tidak stratified).
 *
 * @return array [$trainIdx, $testIdx]
 */
function stratifiedSplit($labels, $testRatio)
{
    $byClass = [];
    foreach ($labels as $i => $label) {
        $byClass[$label][] = $i;
    }

    $trainIdx = [];
    $testIdx = [];
    foreach ($byClass as $label => $idxs) {
        shuffle($idxs);
        $testCount = max(1, (int) round(count($idxs) * $testRatio));
        $testCount = min($testCount, count($idxs) - 1 >= 0 ? count($idxs) : $testCount); // jaga minimal 0 train
        $testPart = array_slice($idxs, 0, $testCount);
        $trainPart = array_slice($idxs, $testCount);
        $testIdx = array_merge($testIdx, $testPart);
        $trainIdx = array_merge($trainIdx, $trainPart);
    }
    shuffle($trainIdx);
    shuffle($testIdx);

    return [$trainIdx, $testIdx];
}

// Batas waktu eksekusi dinaikkan dari 600 -> 1800 detik (30 menit). Kombinasi
// max_depth tinggi + "full split search" (tanpa subsampling) + banyak tree
// bisa lebih lambat dari 600s di PHP murni pada mesin lokal (XAMPP dsb),
// beda jauh dari sklearn yang jalan di C. Kalau tetap timeout di hosting
// Anda, cek juga php.ini: max_execution_time & apakah hosting mengizinkan
// set_time_limit() di-override sama sekali (beberapa shared hosting mengunci
// ini terlepas dari nilai yang diminta script).
set_time_limit(1800);
// Training (terutama Random Forest pada dataset besar) cukup memakan memori
// karena tiap vektor TF-IDF berukuran ratusan dimensi. Naikkan batas memori
// khusus untuk proses ini saja (tidak mengubah php.ini secara permanen).
// @ dipakai karena beberapa hosting menonaktifkan ini_set untuk memory_limit.
// PERBAIKAN: dinaikkan dari 512M -> 1536M (BUKAN lebih tinggi lagi — lihat
// catatan di bawah). Root cause "Allowed memory size exhausted": dengan
// min_samples_leaf kecil (mis. 1) dan max_depth besar (mis. 200), pohon
// dibiarkan membelah sampai leaf nyaris 1 baris data, menghasilkan puluhan
// ribu node per tree x n_trees = bisa jutaan node array PHP tertampung di
// memori sekaligus. Cara yang LEBIH BAIK daripada sekadar menaikkan batas
// ini adalah menaikkan min_samples_leaf (mis. 5-10, sudah jadi default form)
// — selain menghemat memori drastis, ini juga regularisasi yang mencegah
// overfitting ke baris-baris tunggal/noise.
//
// CATATAN UNTUK LAPTOP 8GB RAM: 1536M ini adalah batas MAKSIMUM yang boleh
// diminta PHP, bukan jaminan segitu yang benar-benar dipakai. Tapi di
// laptop 8GB, OS + browser + Apache + MySQL (XAMPP) biasanya sudah memakai
// sekitar 4-5GB sendiri, jadi sisa RAM bebas untuk proses training ini
// realistisnya cuma sekitar 3GB. Kalau dipaksa ke 2048M/3072M dan
// kebetulan RAM lagi penuh oleh aplikasi lain, laptop bisa nge-freeze
// (swap ke disk) alih-alih PHP-nya sendiri yang error dengan rapi — jadi
// sengaja TIDAK dinaikkan lebih tinggi dari ini. Kalau masih exhausted di
// 1536M walau min_samples_leaf sudah >=5, jangan naikkan angka ini lagi;
// turunkan dulu n_trees atau max_depth (lihat catatan di halaman training).
@ini_set('memory_limit', '1536M');
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: training.php');
    exit;
}

$algoritma = isset($_POST['algoritma']) ? $_POST['algoritma'] : '';
$batch = isset($_POST['batch']) ? $_POST['batch'] : '';
$testRatioRaw = isset($_POST['test_ratio']) ? $_POST['test_ratio'] : 20;
$testRatio = max(0.1, min(0.5, ((float)$testRatioRaw) / 100));
// Dipakai untuk catatan riwayat training, mis. "80:20"
$splitRatioLabel = round((1 - $testRatio) * 100) . ':' . round($testRatio * 100);

// PERBAIKAN: sebelumnya TIDAK ADA satupun mt_srand() di seluruh sistem, jadi
// setiap tombol "Latih Model" diklik, PHP otomatis pakai seed acak baru
// (auto-seeded sejak PHP 7.1) untuk SEMUA sumber keacakan di bawah ini:
// stratifiedSplit() (shuffle urutan train/test), SMOTE (pilih tetangga &
// interpolasi), RandomForest (bootstrap sampling tiap tree), dan DecisionTree
// (random feature subspace per node + subsample pencarian split). Akibatnya
// dua kali training dengan SETTINGAN PARAMETER IDENTIK bisa menghasilkan
// akurasi berbeda (terlihat di riwayat training: 57.22% vs 58.5%).
//
// Kalau field "random_seed" di form diisi angka, mt_srand() dipanggil SEKALI
// di sini SEBELUM proses acak apapun dimulai — karena mt_rand() dipakai di
// banyak file berbeda (process_training.php, Smote.php, RandomForest.php,
// DecisionTree.php) tapi semuanya berbagi SATU generator angka acak global
// PHP, cukup di-seed sekali di titik paling awal ini supaya seluruh urutan
// angka acak berikutnya (di file manapun dipanggilnya) jadi deterministik/
// bisa diulang persis sama. Kalau field dikosongkan, perilaku lama (acak
// tiap run) tetap dipertahankan supaya tidak mengubah default yang sudah ada.
$randomSeedRaw = isset($_POST['random_seed']) ? trim($_POST['random_seed']) : '';
$randomSeed = ($randomSeedRaw === '') ? null : (int) $randomSeedRaw;
if ($randomSeed !== null) {
    // PENTING (ketemu lewat debug_seed_check.php di server PHP 5.6.40 milik
    // user): mt_srand() SAJA TIDAK CUKUP. Sebelum PHP 7.1, shuffle() dan
    // array_rand() TIDAK memakai generator Mersenne Twister yang dikontrol
    // mt_srand() - mereka memakai generator libc rand() terpisah yang HANYA
    // bisa di-seed lewat srand(). Baru sejak PHP 7.1 kedua generator ini
    // disatukan (mt_srand()/srand() jadi alias satu sama lain). Karena
    // stratifiedSplit() (train/test split) dan DecisionTree::randomFeatureSubset()
    // pakai shuffle(), serta Smote.php & DecisionTree::findBestSplit() pakai
    // array_rand(), keduanya WAJIB ikut di-seed lewat srand() juga - kalau
    // tidak, hasil training tetap berubah-ubah tiap run walau mt_rand() (dipakai
    // RandomForest untuk bootstrap sampling) sendiri sudah deterministik.
    // Memanggil keduanya aman untuk semua versi PHP: di 7.1+ ini cuma
    // menyeed ulang generator yang sama dua kali (tidak berbahaya).
    mt_srand($randomSeed);
    srand($randomSeed);
}

// SMOTE hanya diterapkan pada data LATIH (bukan data uji), sesuai skripsi.
// Default AKTIF supaya konsisten dengan metodologi (penyeimbangan kelas
// sebelum training RF & KNN). Bisa dimatikan lewat centang di form.
$useSmote = isset($_POST['use_smote']) && $_POST['use_smote'] === '1';

// Parameter TF-IDF, default disamakan dengan notebook Colab:
// TfidfVectorizer(max_features=3000, ngram_range=(1,2), min_df=5, max_df=0.9)
$maxFeaturesRaw = isset($_POST['max_features']) ? trim($_POST['max_features']) : '3000';
$maxFeatures = ($maxFeaturesRaw === '' || (int)$maxFeaturesRaw <= 0) ? null : (int)$maxFeaturesRaw;

$minDfRaw = isset($_POST['min_df']) ? trim($_POST['min_df']) : '5';
$minDf = ($minDfRaw === '') ? 5 : max(1, (int)$minDfRaw);

$maxDfRaw = isset($_POST['max_df']) ? trim($_POST['max_df']) : '0.9';
$maxDf = ($maxDfRaw === '') ? 0.9 : max(0.01, min(1.0, (float)$maxDfRaw));

// Sertakan bigram (dua kata berturutan) selain unigram, sesuai ngram_range=(1,2)
$useBigram = !isset($_POST['use_bigram']) || $_POST['use_bigram'] === '1'; // default AKTIF
$ngramRange = $useBigram ? [1, 2] : [1, 1];

if ($batch === '' || !in_array($algoritma, ['random_forest', 'knn'])) {
    header('Location: training.php?error=' . urlencode('Parameter tidak valid.'));
    exit;
}

// Ambil data yang sudah dipreprocessing
// PENTING untuk reproducibility: ditambahkan ORDER BY id. Tanpa ini, MySQL
// TIDAK menjamin urutan baris yang dikembalikan selalu sama antar eksekusi
// query (meski isi datanya identik) — dan karena stratifiedSplit() melakukan
// shuffle() pada urutan baris tsb, seed random yang sama bisa tetap
// menghasilkan split train/test yang BEDA kalau urutan input dari DB-nya
// beda. Dengan ORDER BY id, urutan input selalu sama, sehingga mt_srand()
// di atas benar-benar membuat seluruh pipeline (split -> SMOTE -> RF)
// deterministik/reproducible dari ujung ke ujung.
// REVISI DOSEN: kolom `teks_asli` DAN `teks_preprocessing` ikut diambil
// (sebelumnya hanya id/tokens/label, lalu sempat ditambah teks_asli saja).
// Data uji yang ditunjukkan di halaman public/pengujian.php seharusnya berupa
// teks yang SUDAH melalui tahap preprocessing (bukan teks mentah/asli),
// karena itulah bentuk data yang benar-benar masuk ke tahap ekstraksi fitur
// (TF-IDF) dan diklasifikasikan oleh model — teks_asli hanya disimpan sebagai
// referensi/tooltip supaya tetap bisa ditelusuri ke komentar aslinya.
$stmt = $db->prepare("SELECT id, teks_asli, teks_preprocessing, tokens, label FROM dataset WHERE dataset_batch = ? AND status_preprocessing = 'selesai' AND label IS NOT NULL ORDER BY id");
$stmt->bind_param('s', $batch);
$stmt->execute();
// BUG FIX: pakai stmtFetchAll() (bukan get_result() langsung) supaya tetap
// berjalan di hosting yang mysqli-nya tidak dikompilasi dengan mysqlnd.
$rows = stmtFetchAll($stmt);

$allTokens = [];
$allLabels = [];
$allIds = [];
$allTexts = [];
$allTextsPreprocessing = [];

foreach ($rows as $row) {
    $decodedTokens = json_decode($row['tokens'], true);
    $allTokens[] = $decodedTokens !== null ? $decodedTokens : [];
    $allLabels[] = $row['label'];
    $allIds[] = $row['id'];
    $allTexts[] = $row['teks_asli'];
    // Fallback ke teks_asli hanya untuk jaga-jaga kalau ada baris lama yang
    // status_preprocessing='selesai' tapi kolom teks_preprocessing-nya kosong
    // (seharusnya tidak terjadi, karena proses preprocessing selalu mengisi
    // kolom ini bersamaan dengan mengubah status menjadi 'selesai').
    $allTextsPreprocessing[] = $row['teks_preprocessing'] !== null && $row['teks_preprocessing'] !== ''
        ? $row['teks_preprocessing']
        : $row['teks_asli'];
}

$totalData = count($allTokens);
if ($totalData < 10) {
    header('Location: training.php?error=' . urlencode('Data terlalu sedikit untuk training (minimal 10 data yang sudah dipreprocessing dan berlabel).'));
    exit;
}

// Stratified split: proporsi kelas dijaga sama antara data latih & data uji
list($trainIdx, $testIdx) = stratifiedSplit($allLabels, $testRatio);

$trainTokens = array_map(function ($i) use ($allTokens) { return $allTokens[$i]; }, $trainIdx);
$trainLabels = array_map(function ($i) use ($allLabels) { return $allLabels[$i]; }, $trainIdx);
$testTokens = array_map(function ($i) use ($allTokens) { return $allTokens[$i]; }, $testIdx);
$testLabels = array_map(function ($i) use ($allLabels) { return $allLabels[$i]; }, $testIdx);

// REVISI DOSEN: sebelumnya stratifiedSplit() hanya dipakai secara "diam-diam"
// di dalam memori PHP (train/test dipisah, dipakai untuk fit+predict, lalu
// dibuang) — tidak ada bukti/tampilan di sistem yang menunjukkan BENAR bahwa
// evaluasi (akurasi/precision/recall/F1 di menu Perbandingan Model) dihitung
// dari DATA UJI (bukan data latih atau seluruh data). Kolom `dipakai_untuk`
// (enum 'train'/'test'/'unused') sudah ada di skema tabel `dataset` sejak
// awal tapi TIDAK PERNAH diisi oleh kode manapun — jadi baris data yang benar-
// benar dijadikan data uji tidak pernah tercatat/tertunjuk. Diperbaiki di sini:
// setiap kali training dijalankan untuk sebuah batch, tandai ulang seluruh
// baris batch tsb sesuai hasil split yang BARU (supaya kalau training diulang
// dengan seed/rasio berbeda, penandaan lama tidak menyesatkan).
$trainIds = array_map(function ($i) use ($allIds) { return (int) $allIds[$i]; }, $trainIdx);
$testIds = array_map(function ($i) use ($allIds) { return (int) $allIds[$i]; }, $testIdx);

/**
 * Update kolom `dipakai_untuk` untuk sekumpulan id dataset, dipecah per 500 id
 * supaya query IN (...) tidak terlalu panjang pada dataset besar.
 */
function updateDipakaiUntuk($db, $ids, $status)
{
    if (empty($ids)) return;
    $chunks = array_chunk($ids, 500);
    foreach ($chunks as $chunk) {
        $inList = implode(',', array_map('intval', $chunk));
        $db->query("UPDATE dataset SET dipakai_untuk = '" . $db->real_escape_string($status) . "' WHERE id IN ($inList)");
    }
}

// Reset dulu seluruh batch ini ke 'unused', baru tandai train/test sesuai
// split yang baru saja dihasilkan di atas — supaya status selalu konsisten
// dengan hasil training TERAKHIR untuk batch tsb.
$stmtReset = $db->prepare("UPDATE dataset SET dipakai_untuk = 'unused' WHERE dataset_batch = ?");
$stmtReset->bind_param('s', $batch);
$stmtReset->execute();
updateDipakaiUntuk($db, $trainIds, 'train');
updateDipakaiUntuk($db, $testIds, 'test');

// Ekstraksi fitur TF-IDF (fit hanya dari data training, transform ke train & test)
$tfidf = new TfIdf();
$tfidf->fit($trainTokens, $maxFeatures, $minDf, $maxDf, $ngramRange);

$trainVectors = $tfidf->transformBatch($trainTokens);
$testVectors = $tfidf->transformBatch($testTokens);

// Distribusi kelas SEBELUM SMOTE (untuk transparansi/ditampilkan di riwayat)
$distSebelum = Smote::classDistribution($trainLabels);

// Terapkan SMOTE pada data LATIH saja (data uji tetap asli, sama seperti di skripsi)
if ($useSmote) {
    list($trainVectors, $trainLabels) = Smote::apply($trainVectors, $trainLabels, 5);
}
$distSesudah = Smote::classDistribution($trainLabels);

$startTime = microtime(true);
$parameter = [];
$modelExport = [];

if ($algoritma === 'random_forest') {
    // Default n_trees=100 sesuai RandomForestClassifier(n_estimators=100, ...) di notebook.
    // Notebook TIDAK membatasi max_depth (default sklearn None = tumbuh sampai murni),
    // jadi kosongkan/0 di form berarti "tanpa batas" (disimulasikan dgn nilai besar
    // karena struktur pohon di sini butuh angka konkret).
    $nTreesRaw = isset($_POST['n_trees']) ? $_POST['n_trees'] : 100;
    $maxDepthRaw = isset($_POST['max_depth']) ? trim($_POST['max_depth']) : '';
    $nTrees = max(1, (int)$nTreesRaw);
    // PERBAIKAN (root cause akurasi RF jauh di bawah notebook Colab):
    // default LAMA (max_depth=10, min_samples_leaf=5) ternyata membuat pohon
    // terlalu DANGKAL untuk data TF-IDF sparse berdimensi ribuan, sehingga RF
    // underfitting parah dan hasilnya condong ke kelas mayoritas (gejala:
    // precision jauh LEBIH TINGGI dari accuracy — bukan tanda collapse
    // overfitting seperti dugaan awal, justru sebaliknya). scikit-learn
    // (notebook Colab) memakai max_depth=None (tanpa batas) dan RF tetap
    // stabil karena regularisasi utamanya datang dari BAGGING + random
    // feature subspace per node, bukan dari membatasi kedalaman. Default
    // kalau dikosongkan sekarang dinaikkan jadi 50 (kompromi supaya training
    // PHP murni tetap selesai dalam batas set_time_limit di atas; sklearn
    // bisa "tanpa batas" karena jalan di C, bukan PHP). Kalau dataset Anda
    // besar dan training terasa lambat/timeout, boleh turunkan; kalau ingin
    // meniru notebook lebih dekat, coba nilai tinggi (100-200).
    // UPDATE (berdasarkan riwayat training Anda sendiri, lihat catatan di
    // halaman Training Model): kombinasi max_depth=50 TANPA full-split hanya
    // menghasilkan ~55-60% akurasi. max_depth=200 DENGAN full-split terbukti
    // melompat ke ~70-71%. Default kalau dikosongkan sekarang dinaikkan dari
    // 50 -> 200 supaya form yang tidak diubah sama sekali sudah otomatis
    // memakai kombinasi yang terbukti terbaik (lihat juga default
    // $fullSplitSearch di bawah, yang sekarang ikut diubah jadi ON).
    $maxDepth = ($maxDepthRaw === '' || (int)$maxDepthRaw <= 0) ? 200 : max(1, (int)$maxDepthRaw);

    // Regularisasi tambahan: minimal jumlah sampel per leaf (tolak split yang
    // membuat salah satu sisi terlalu kecil/rawan overfit ke outlier/noise).
    // Default diturunkan lagi dari 2 -> 1 supaya PERSIS default sklearn:
    // RandomForestClassifier(min_samples_leaf=1) — parameter ini TIDAK ada
    // di grid GridSearchCV notebook (subbab 4.5, hanya n_estimators/max_depth/
    // min_samples_split yang dituning), jadi nilai final di notebook otomatis
    // memakai default sklearn ini, bukan hasil tuning.
    $minLeafRaw = isset($_POST['min_samples_leaf']) ? trim($_POST['min_samples_leaf']) : '1';
    $minSamplesLeaf = ($minLeafRaw === '') ? 1 : max(1, (int)$minLeafRaw);

    // MODE "PALING DEKAT NOTEBOOK": scikit-learn TIDAK melakukan subsampling
    // sama sekali saat mencari split terbaik — semua baris di satu node selalu
    // dipindai penuh. Implementasi PHP ini biasanya membatasi pencarian ke
    // $maxSplitSample baris (demi kecepatan) sehingga sedikit menyimpang dari
    // sklearn. Centang "cari split pakai seluruh data" di form untuk
    // menghilangkan batas ini (paling dekat ke notebook, tapi training jadi
    // ~2x lebih lambat pada dataset besar).
    $fullSplitSearch = isset($_POST['full_split_search']) && $_POST['full_split_search'] === '1';
    $maxSplitSample = $fullSplitSearch ? PHP_INT_MAX : 3000;

    $model = new RandomForest($nTrees, $maxDepth, 2, null, $minSamplesLeaf, $maxSplitSample);
    $model->fit($trainVectors, $trainLabels, $tfidf->vocabSize());
    $predictions = $model->predictBatch($testVectors);

    // DIAGNOSTIK collapse: hitung berapa banyak tree yang root-nya LANGSUNG
    // jadi leaf (tidak pernah nemu split valid sama sekali). Kalau angka ini
    // tinggi (mendekati $nTrees), itu akar masalah sebenarnya kenapa hasil
    // prediksi RF seragam untuk semua data uji.
    $debugStats = $model->debugStats();

    // DIAGNOSTIK LANJUTAN: lacak jalur prediksi 3 dokumen uji NYATA (dari
    // 3 kelas berbeda kalau memungkinkan) lewat tree pertama (index 0),
    // sampai ke leaf akhirnya. Ini untuk mengecek apakah dokumen-dokumen
    // yang beda kelas ternyata semua "nyasar" ke leaf yang SAMA (tanda
    // splitnya tidak informatif untuk data uji nyata meski valid secara
    // statistik gini saat training), atau memang berbeda leaf tapi leaf-nya
    // sendiri isinya campur/tidak murni (label_counts hampir rata).
    $traceSamples = [];
    $seenLabels = [];
    foreach ($testVectors as $ti => $vec) {
        $trueLabel = $testLabels[$ti];
        if (isset($seenLabels[$trueLabel])) continue;
        $seenLabels[$trueLabel] = true;
        $trace = $model->traceOne($vec, 0);
        $trace['true_label'] = $trueLabel;
        $trace['predicted_by_full_forest'] = $predictions[$ti];
        $traceSamples[] = $trace;
        if (count($seenLabels) >= 3) break;
    }

    $parameter = [
        'n_trees' => $nTrees,
        'max_depth' => $maxDepth,
        'min_samples_leaf' => $minSamplesLeaf,
        'full_split_search' => $fullSplitSearch,
        'stratified_split' => true,
        'split_ratio' => $splitRatioLabel,
        'random_seed' => $randomSeed === null ? 'acak (tidak di-seed)' : $randomSeed,
        'use_smote' => $useSmote,
        'max_features_tfidf' => $maxFeatures === null ? 'unlimited' : $maxFeatures,
        'min_df' => $minDf,
        'max_df' => $maxDf,
        'ngram_range' => $ngramRange,
        'distribusi_kelas_sebelum_smote' => $distSebelum,
        'distribusi_kelas_sesudah_smote' => $distSesudah,
        'debug_root_is_leaf_count' => $debugStats['root_is_leaf_count'] . ' / ' . $debugStats['total_trees'],
        'debug_root_labels' => array_count_values(array_map(function ($s) {
            return $s['root_is_leaf'] ? ('LEAF:' . $s['root_label']) : ('SPLIT:fitur#' . $s['root_feature']);
        }, $debugStats['per_tree'])),
        'debug_trace_tree0' => $traceSamples,
    ];
    $modelExport = $model->export();
} else {
    $kRaw = isset($_POST['k_value']) ? $_POST['k_value'] : 5;
    $k = max(1, (int)$kRaw);
    $metricRaw = isset($_POST['metric']) ? $_POST['metric'] : '';
    $metric = in_array($metricRaw, ['euclidean', 'cosine']) ? $metricRaw : 'euclidean';

    $model = new KNN($k, $metric);
    $model->fit($trainVectors, $trainLabels);
    $predictions = $model->predictBatch($testVectors);

    $parameter = [
        'k' => $k,
        'metric' => $metric,
        'stratified_split' => true,
        'split_ratio' => $splitRatioLabel,
        'random_seed' => $randomSeed === null ? 'acak (tidak di-seed)' : $randomSeed,
        'use_smote' => $useSmote,
        'max_features_tfidf' => $maxFeatures === null ? 'unlimited' : $maxFeatures,
        'min_df' => $minDf,
        'max_df' => $maxDf,
        'ngram_range' => $ngramRange,
        'distribusi_kelas_sebelum_smote' => $distSebelum,
        'distribusi_kelas_sesudah_smote' => $distSesudah,
    ];
    $modelExport = $model->export();
}

$waktuTraining = microtime(true) - $startTime;

$evaluation = Evaluator::evaluate($testLabels, $predictions);

// REVISI DOSEN: simpan detail hasil pengujian PER BARIS data uji (id asli,
// teks asli, label aktual vs label hasil prediksi model, benar/salah) supaya
// bisa DITUNJUKKAN di halaman "Hasil Pengujian" (public/pengujian.php) bahwa
// pengujian benar-benar dilakukan terhadap data testing hasil stratified
// split di atas, bukan cuma angka akurasi agregat tanpa bukti baris per baris.
// Disimpan di file model JSON yang sama (bukan tabel baru) supaya tidak perlu
// migrasi skema database tambahan.
$testDetail = [];
foreach ($testIdx as $pos => $originalIndex) {
    $testDetail[] = [
        'id' => $allIds[$originalIndex],
        'teks_asli' => $allTexts[$originalIndex],
        // REVISI: teks_preprocessing ikut disimpan supaya halaman Hasil
        // Pengujian bisa menampilkan teks yang SUDAH melalui tahap
        // preprocessing (case folding, cleaning, normalisasi, tokenisasi,
        // stopword removal, stemming) sebagai kolom utama, bukan teks asli.
        // teks_asli tetap disimpan sebagai atribut tooltip/referensi saja.
        'teks_preprocessing' => $allTextsPreprocessing[$originalIndex],
        'label_aktual' => $testLabels[$pos],
        'label_prediksi' => $predictions[$pos],
        'benar' => $testLabels[$pos] === $predictions[$pos],
    ];
}

// Simpan model + tfidf vocabulary ke file JSON
$modelDir = __DIR__ . '/../models';
if (!is_dir($modelDir)) mkdir($modelDir, 0755, true);

$modelFilename = $algoritma . '_' . $batch . '_' . time() . '.json';
$modelPath = $modelDir . '/' . $modelFilename;

file_put_contents($modelPath, json_encode([
    'algoritma' => $algoritma,
    'tfidf' => $tfidf->export(),
    'model' => $modelExport,
]));

// REVISI DOSEN: detail hasil pengujian disimpan di FILE TERPISAH (bukan
// digabung ke dalam file model di atas). File model (terutama Random Forest,
// berisi banyak pohon + vocabulary TF-IDF) bisa berukuran belasan MB, dan
// men-decode file sebesar itu dengan json_decode() bisa menghabiskan memori
// PHP jauh lebih besar dari ukuran filenya sendiri (mudah melebihi
// memory_limit 128M bawaan XAMPP dan menyebabkan "Fatal error: Allowed
// memory size ... exhausted"). Karena public/pengujian.php HANYA butuh
// test_detail (bukan isi model), detail pengujian disimpan terpisah di file
// yang jauh lebih kecil supaya halaman Hasil Pengujian tidak perlu membaca/
// men-decode file model sama sekali.
$testDetailFilename = 'testdetail_' . $modelFilename;
$testDetailPath = $modelDir . '/' . $testDetailFilename;
file_put_contents($testDetailPath, json_encode([
    'algoritma' => $algoritma,
    'dataset_batch' => $batch,
    'test_detail' => $testDetail,
    'evaluation_recap' => [
        'jumlah_data_uji' => count($testDetail),
        'jumlah_benar' => count(array_filter($testDetail, function ($d) { return $d['benar']; })),
        'jumlah_salah' => count(array_filter($testDetail, function ($d) { return !$d['benar']; })),
        'akurasi' => $evaluation['accuracy'],
    ],
]));

// Simpan riwayat training ke database
$paramJson = json_encode($parameter);
$cmJson = json_encode($evaluation['confusion_matrix']);
$trainCount = count($trainVectors); // jumlah data latih AKTUAL yang dipakai (setelah SMOTE jika aktif)
$testCountFinal = count($testIdx);

$stmtInsert2 = $db->prepare("
    INSERT INTO training_history
    (dataset_batch, algoritma, parameter, jumlah_data_train, jumlah_data_test, akurasi, presisi, recall_score, f1_score, confusion_matrix, waktu_training, model_path)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$stmtInsert2->bind_param(
    'sssiiddddsds',
    $batch, $algoritma, $paramJson, $trainCount, $testCountFinal,
    $evaluation['accuracy'], $evaluation['precision'], $evaluation['recall'], $evaluation['f1_score'],
    $cmJson, $waktuTraining, $modelFilename
);
$stmtInsert2->execute();

header('Location: training.php?success=1&algo=' . $algoritma . '&acc=' . $evaluation['accuracy']);
exit;
