<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/compat.php';
$db = getDB();
$pageTitle = 'Perbandingan Model';
include __DIR__ . '/templates/header.php';

$batchFilter = isset($_GET['batch']) ? $_GET['batch'] : '';
$batches = $db->query("SELECT DISTINCT dataset_batch FROM training_history ORDER BY dataset_batch");

$where = $batchFilter !== '' ? "WHERE dataset_batch = '" . $db->real_escape_string($batchFilter) . "'" : '';
$lastRF = $db->query("SELECT * FROM training_history $where " . ($where ? "AND" : "WHERE") . " algoritma='random_forest' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
$lastKNN = $db->query("SELECT * FROM training_history $where " . ($where ? "AND" : "WHERE") . " algoritma='knn' ORDER BY created_at DESC LIMIT 1")->fetch_assoc();

$allHistory = $db->query("SELECT * FROM training_history $where ORDER BY created_at DESC");

// Distribusi label dataset untuk batch yang relevan (mirip kartu "Distribusi Data" pada referensi)
$distBatch = $batchFilter;
if ($distBatch === '') {
    if (isset($lastRF['dataset_batch'])) { $distBatch = $lastRF['dataset_batch']; }
    elseif (isset($lastKNN['dataset_batch'])) { $distBatch = $lastKNN['dataset_batch']; }
}
$distLabels = []; $distValues = []; $distTotal = 0;
if ($distBatch !== '') {
    $distStmt = $db->prepare("SELECT label, COUNT(*) jumlah FROM dataset WHERE dataset_batch = ? GROUP BY label");
    $distStmt->bind_param('s', $distBatch);
    $distStmt->execute();
    $distRows = stmtFetchAll($distStmt);
    foreach ($distRows as $row) {
        $distLabels[$row['label']] = (int)$row['jumlah'];
        $distTotal += (int)$row['jumlah'];
    }
}

/**
 * BUG FIX / FITUR BARU: hitung classification report (precision/recall/f1/support
 * per kelas) langsung dari confusion_matrix yang sudah tersimpan di database,
 * tanpa perlu mengubah skema tabel training_history. Logikanya identik dengan
 * Evaluator::evaluate() supaya konsisten dengan angka macro-average yang sudah ada.
 */
function classificationReport($matrix)
{
    if (!$matrix) return [];
    $labels = array_keys($matrix);
    $report = [];
    foreach ($labels as $label) {
        $tp = isset($matrix[$label][$label]) ? $matrix[$label][$label] : 0;
        $fp = 0; $fn = 0; $support = 0;
        foreach ($labels as $other) {
            $support += isset($matrix[$label][$other]) ? $matrix[$label][$other] : 0;
            if ($other !== $label) {
                $fp += isset($matrix[$other][$label]) ? $matrix[$other][$label] : 0;
                $fn += isset($matrix[$label][$other]) ? $matrix[$label][$other] : 0;
            }
        }
        $precision = ($tp + $fp) > 0 ? $tp / ($tp + $fp) : 0;
        $recall = ($tp + $fn) > 0 ? $tp / ($tp + $fn) : 0;
        $f1 = ($precision + $recall) > 0 ? 2 * $precision * $recall / ($precision + $recall) : 0;
        $report[$label] = ['precision' => $precision, 'recall' => $recall, 'f1' => $f1, 'support' => $support];
    }
    return $report;
}

/**
 * Urutkan ulang confusion matrix (baris & kolom) sesuai urutan label yang
 * diinginkan: Positif, Negatif, Netral. Label yang tidak ada dalam $order
 * akan ditambahkan di akhir supaya tidak ada data yang hilang.
 */
function orderMatrix($matrix, $order = ['positif', 'negatif', 'netral']) {
    if (!$matrix) return $matrix;
    $labels = array_keys($matrix);
    $orderedLabels = array_values(array_filter($order, function ($l) use ($labels) {
        return in_array($l, $labels, true);
    }));
    foreach ($labels as $l) {
        if (!in_array($l, $orderedLabels, true)) $orderedLabels[] = $l;
    }
    $newMatrix = [];
    foreach ($orderedLabels as $actual) {
        $row = [];
        foreach ($orderedLabels as $pred) {
            $row[$pred] = isset($matrix[$actual][$pred]) ? $matrix[$actual][$pred] : 0;
        }
        $newMatrix[$actual] = $row;
    }
    return $newMatrix;
}

function renderConfusionMatrix($matrix) {
    if (!$matrix) { echo '<p class="text-muted">Data tidak tersedia.</p>'; return; }
    $labels = array_keys($matrix);
    echo '<div class="compact-table-wrap"><table><tr><th>Aktual \ Prediksi</th>';
    foreach ($labels as $l) echo '<th>' . htmlspecialchars($l) . '</th>';
    echo '</tr>';
    foreach ($labels as $actual) {
        echo '<tr><th style="background:var(--slate-light);color:var(--text);">' . htmlspecialchars($actual) . '</th>';
        foreach ($labels as $pred) {
            $val = isset($matrix[$actual][$pred]) ? $matrix[$actual][$pred] : 0;
            $highlight = $actual === $pred ? 'style="background:var(--green-light);font-weight:800;color:#147a3c;"' : '';
            echo "<td $highlight>$val</td>";
        }
        echo '</tr>';
    }
    echo '</table></div>';
}

function renderClassificationReport($matrix) {
    $report = classificationReport($matrix);
    if (empty($report)) { echo '<p class="text-muted">Data tidak tersedia.</p>'; return; }
    $colors = ['positif' => 'green', 'negatif' => 'red', 'netral' => 'amber'];
    echo '<div class="compact-table-wrap"><table><tr><th>Label</th><th>Precision</th><th>Recall</th><th>F1-Score</th><th>Support</th></tr>';
    foreach ($report as $label => $m) {
        $color = isset($colors[$label]) ? $colors[$label] : 'blue';
        echo '<tr>';
        echo '<td><span class="badge ' . htmlspecialchars($label) . '">' . htmlspecialchars($label) . '</span></td>';
        foreach (['precision', 'recall', 'f1'] as $key) {
            $pct = round($m[$key] * 100, 2);
            echo "<td>$pct%<div class=\"mini-bar-bg\"><div class=\"mini-bar-fill $color\" style=\"width:{$pct}%\"></div></div></td>";
        }
        echo '<td>' . $m['support'] . '</td>';
        echo '</tr>';
    }
    echo '</table></div>';
    echo '<p class="text-muted mt-16" style="font-size:11.5px;">* Support = jumlah data uji per kelas &nbsp;·&nbsp; F1-Score = harmonic mean precision &amp; recall</p>';
}
?>

<div class="card">
    <div class="flex-between">
        <h2 style="margin:0;">Filter Batch Dataset</h2>
        <form method="GET">
            <select name="batch" onchange="this.form.submit()" style="margin:0;">
                <option value="">-- Semua Batch --</option>
                <?php $batches->data_seek(0); while ($b = $batches->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($b['dataset_batch']) ?>" <?= $batchFilter === $b['dataset_batch'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($b['dataset_batch']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>
</div>

<?php if ($lastRF && $lastKNN): ?>

<div class="grid grid-2">
    <div class="card">
        <h2>🥧 Distribusi Data — <span class="text-muted" style="font-weight:500;"><?= htmlspecialchars($distBatch) ?></span></h2>
        <?php if ($distTotal > 0): ?>
        <div class="pill-stats">
            <div class="pill-stat total"><div class="num"><?= $distTotal ?></div><div class="lbl">Total</div></div>
            <div class="pill-stat positif"><div class="num"><?= isset($distLabels['positif']) ? $distLabels['positif'] : 0 ?></div><div class="lbl">Positif</div></div>
            <div class="pill-stat negatif"><div class="num"><?= isset($distLabels['negatif']) ? $distLabels['negatif'] : 0 ?></div><div class="lbl">Negatif</div></div>
            <div class="pill-stat netral"><div class="num"><?= isset($distLabels['netral']) ? $distLabels['netral'] : 0 ?></div><div class="lbl">Netral</div></div>
        </div>
        <div class="chart-wrap"><canvas id="distDonut"></canvas></div>
        <?php else: ?>
            <p class="text-muted">Data distribusi tidak tersedia.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>📊 Grafik Perbandingan Metrik Evaluasi</h2>
        <div class="chart-wrap"><canvas id="compareChart"></canvas></div>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <h2>🌲 Random Forest (Training Terakhir)</h2>
        <table class="mt-16">
            <tr><td>Akurasi</td><td><strong><?= round($lastRF['akurasi']*100,2) ?>%</strong></td></tr>
            <tr><td>Precision</td><td><?= round($lastRF['presisi']*100,2) ?>%</td></tr>
            <tr><td>Recall</td><td><?= round($lastRF['recall_score']*100,2) ?>%</td></tr>
            <tr><td>F1-Score</td><td><?= round($lastRF['f1_score']*100,2) ?>%</td></tr>
            <tr><td>Data Train / Test</td><td><?= $lastRF['jumlah_data_train'] ?> / <?= $lastRF['jumlah_data_test'] ?></td></tr>
            <tr><td>Waktu Training</td><td><?= round($lastRF['waktu_training'],3) ?> detik</td></tr>
        </table>
    </div>

    <div class="card">
        <h2>📍 KNN (Training Terakhir)</h2>
        <table class="mt-16">
            <tr><td>Akurasi</td><td><strong><?= round($lastKNN['akurasi']*100,2) ?>%</strong></td></tr>
            <tr><td>Precision</td><td><?= round($lastKNN['presisi']*100,2) ?>%</td></tr>
            <tr><td>Recall</td><td><?= round($lastKNN['recall_score']*100,2) ?>%</td></tr>
            <tr><td>F1-Score</td><td><?= round($lastKNN['f1_score']*100,2) ?>%</td></tr>
            <tr><td>Data Train / Test</td><td><?= $lastKNN['jumlah_data_train'] ?> / <?= $lastKNN['jumlah_data_test'] ?></td></tr>
            <tr><td>Waktu Training</td><td><?= round($lastKNN['waktu_training'],3) ?> detik</td></tr>
        </table>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <h2>Confusion Matrix — Random Forest</h2>
        <?php renderConfusionMatrix(orderMatrix(json_decode($lastRF['confusion_matrix'], true))); ?>
    </div>
    <div class="card">
        <h2>Confusion Matrix — KNN</h2>
        <?php renderConfusionMatrix(orderMatrix(json_decode($lastKNN['confusion_matrix'], true))); ?>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <h2>Classification Report — Random Forest</h2>
        <?php renderClassificationReport(orderMatrix(json_decode($lastRF['confusion_matrix'], true))); ?>
    </div>
    <div class="card">
        <h2>Classification Report — KNN</h2>
        <?php renderClassificationReport(orderMatrix(json_decode($lastKNN['confusion_matrix'], true))); ?>
    </div>
</div>

<div class="card">
    <h2>Kesimpulan Perbandingan</h2>
    <?php
    $diff = abs($lastRF['akurasi'] - $lastKNN['akurasi']) * 100;
    $winner = $lastRF['akurasi'] >= $lastKNN['akurasi'] ? 'Random Forest' : 'KNN';
    $winnerAcc = max($lastRF['akurasi'], $lastKNN['akurasi']);
    ?>
    <p>
        Berdasarkan hasil training terakhir pada dataset batch
        "<strong><?= htmlspecialchars($lastRF['dataset_batch']) ?></strong>",
        algoritma <strong><?= $winner ?></strong> menghasilkan akurasi lebih tinggi yaitu
        <strong><?= round($winnerAcc*100, 2) ?>%</strong>, unggul
        <strong><?= round($diff, 2) ?> poin persen</strong> dibandingkan algoritma pembanding.
    </p>
</div>
<?php else: ?>
<div class="alert info">
    Belum cukup data untuk membandingkan. Silakan latih kedua model (Random Forest dan KNN) terlebih dahulu di menu
    <a href="training.php">Training Model</a>.
</div>
<?php endif; ?>

<?php
function renderRiwayatSederhana($rows, $heading, $emoji) {
    // Cari akurasi tertinggi dalam grup ini untuk di-highlight hijau muda
    $bestIdx = null;
    foreach ($rows as $i => $r) {
        if ($bestIdx === null || $r['akurasi'] > $rows[$bestIdx]['akurasi']) $bestIdx = $i;
    }
    echo '<div class="history-subheading"><span><span class="history-subheading-icon">' . $emoji . '</span><span>' . htmlspecialchars($heading) . '</span></span></div>';
    echo '<div class="history-table-wrap"><table>';
    echo '<tr><th>Waktu</th><th>Batch</th><th>Algoritma</th><th>Akurasi</th><th>Precision</th><th>Recall</th><th>F1</th></tr>';
    if (empty($rows)) {
        echo '<tr><td colspan="7" class="text-muted">Belum ada riwayat training ' . htmlspecialchars($heading) . '.</td></tr>';
    }
    foreach ($rows as $i => $h) {
        $rowClass = ($i === $bestIdx) ? 'row-highlight' : '';
        echo '<tr class="' . $rowClass . '">';
        echo '<td>' . date('d/m/Y H:i', strtotime($h['created_at'])) . '</td>';
        echo '<td>' . htmlspecialchars($h['dataset_batch']) . '</td>';
        echo '<td>' . ($h['algoritma'] === 'random_forest' ? '🌲 RF' : '📍 KNN') . '</td>';
        echo '<td>' . round($h['akurasi']*100,2) . '%</td>';
        echo '<td>' . round($h['presisi']*100,2) . '%</td>';
        echo '<td>' . round($h['recall_score']*100,2) . '%</td>';
        echo '<td>' . round($h['f1_score']*100,2) . '%</td>';
        echo '</tr>';
    }
    echo '</table></div>';
}
$allHistoryRF = [];
$allHistoryKNN = [];
while ($h = $allHistory->fetch_assoc()) {
    if ($h['algoritma'] === 'random_forest') { $allHistoryRF[] = $h; } else { $allHistoryKNN[] = $h; }
}
?>

<div class="card">
    <h2>Seluruh Riwayat Training</h2>
    <?php
    renderRiwayatSederhana($allHistoryRF, 'Random Forest', '🌲');
    renderRiwayatSederhana($allHistoryKNN, 'K-Nearest Neighbor (KNN)', '📍');
    ?>
</div>

<?php if ($lastRF && $lastKNN): ?>
<script>
new Chart(document.getElementById('compareChart'), {
    type: 'bar',
    data: {
        labels: ['Accuracy', 'Precision', 'Recall', 'F1-Score'],
        datasets: [
            { label: 'Random Forest', data: [<?= $lastRF['akurasi']*100 ?>, <?= $lastRF['presisi']*100 ?>, <?= $lastRF['recall_score']*100 ?>, <?= $lastRF['f1_score']*100 ?>], backgroundColor: '#2f6feb' },
            { label: 'KNN', data: [<?= $lastKNN['akurasi']*100 ?>, <?= $lastKNN['presisi']*100 ?>, <?= $lastKNN['recall_score']*100 ?>, <?= $lastKNN['f1_score']*100 ?>], backgroundColor: '#d97706' }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true,
                max: 100,
                ticks: { callback: function(value) { return value + '%'; } }
            }
        },
        plugins: {
            legend: { position: 'bottom' },
            tooltip: { callbacks: { label: function(ctx) { return ctx.dataset.label + ': ' + ctx.parsed.y.toFixed(2) + '%'; } } }
        }
    }
});
<?php if ($distTotal > 0): ?>
new Chart(document.getElementById('distDonut'), {
    type: 'doughnut',
    data: {
        labels: ['Positif', 'Negatif', 'Netral'],
        datasets: [{
            data: [<?= isset($distLabels['positif']) ? $distLabels['positif'] : 0 ?>, <?= isset($distLabels['negatif']) ? $distLabels['negatif'] : 0 ?>, <?= isset($distLabels['netral']) ? $distLabels['netral'] : 0 ?>],
            backgroundColor: ['#16a34a', '#dc2626', '#94a3b8']
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } } }
});
<?php endif; ?>
</script>
<?php endif; ?>

<?php include __DIR__ . '/templates/footer.php'; ?>
