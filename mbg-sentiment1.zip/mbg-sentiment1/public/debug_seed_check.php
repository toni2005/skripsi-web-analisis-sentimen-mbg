<?php
/**
 * DIAGNOSTIK SEMENTARA - hapus file ini setelah selesai debugging.
 *
 * Tujuan: memastikan mt_srand() di server Anda benar-benar menghasilkan
 * urutan angka acak yang SAMA setiap kali dipanggil dengan seed yang sama.
 * Tidak menyentuh database sama sekali - murni tes PHP RNG.
 *
 * Cara pakai:
 *  1. Buka file ini di browser (misal: http://localhost/mbg-sentiment/public/debug_seed_check.php)
 *  2. Catat/screenshot angka yang muncul
 *  3. Refresh halaman ini (jalankan lagi)
 *  4. Bandingkan: kalau SEMUA angka di kedua run PERSIS SAMA -> RNG PHP di server
 *     Anda sudah konsisten, berarti penyebab hasil training beda ada di tempat
 *     lain (kemungkinan besar OPcache menyimpan file process_training.php versi
 *     LAMA, atau isi data batch berubah di antara dua run).
 *     Kalau ada angka yang BEDA -> ada masalah di level PHP/server itu sendiri
 *     (jarang terjadi, tapi bisa disebabkan ekstensi/thread lain yang juga
 *     memakai random generator sebelum titik ini, atau versi PHP yang aneh).
 */

header('Content-Type: text/plain; charset=utf-8');

echo "=== Diagnostik mt_srand() ===\n";
echo "PHP version : " . PHP_VERSION . "\n";
echo "Waktu       : " . date('Y-m-d H:i:s') . "\n\n";

mt_srand(42);
srand(42); // WAJIB juga - lihat catatan di process_training.php: shuffle()/array_rand()
           // di PHP < 7.1 pakai generator terpisah yang cuma di-seed lewat srand().

echo "10x mt_rand(0, 999999) setelah mt_srand(42):\n";
for ($i = 0; $i < 10; $i++) {
    echo "  [$i] " . mt_rand(0, 999999) . "\n";
}

echo "\nshuffle() pada array 0-9 setelah mt_srand(42)+srand(42) (di-reset ulang):\n";
mt_srand(42);
srand(42);
// buang 10 angka tadi supaya kita mulai dari titik state yang sama
for ($i = 0; $i < 10; $i++) { mt_rand(0, 999999); }
$arr = range(0, 9);
shuffle($arr);
echo "  " . implode(', ', $arr) . "\n";

echo "\narray_rand() 5 dari 20 elemen (lanjutan state yang sama):\n";
$pool = range(100, 119);
$picked = array_rand($pool, 5);
echo "  index terpilih: " . implode(', ', $picked) . "\n";

echo "\n=== SELESAI - refresh halaman ini, hasil di atas HARUS identik ===\n";
