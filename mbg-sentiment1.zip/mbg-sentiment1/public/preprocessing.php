<?php
require_once __DIR__ . '/../config/db.php';
$db = getDB();
$pageTitle = 'Preprocessing Data';

include __DIR__ . '/templates/header.php';

$batches = $db->query("
    SELECT dataset_batch,
           COUNT(*) total,
           SUM(status_preprocessing='selesai') selesai
    FROM dataset GROUP BY dataset_batch
");

// Snapshot jumlah data MENTAH (sebelum dedup) per batch, dari tabel
// dataset_upload_log (lihat database/migration_dataset_upload_log.sql).
// Dipakai untuk kolom "Total Data" supaya angkanya tidak ikut berubah
// saat autoRemoveDuplicates() di atas menghapus baris duplikat.
$uploadLogByBatch = [];
$logTableExists = $db->query("SHOW TABLES LIKE 'dataset_upload_log'");
if ($logTableExists && $logTableExists->num_rows > 0) {
    $logResult = $db->query("SELECT dataset_batch, total_upload_awal FROM dataset_upload_log");
    while ($logResult && ($lr = $logResult->fetch_assoc())) {
        $uploadLogByBatch[$lr['dataset_batch']] = (int)$lr['total_upload_awal'];
    }
}
?>

<?php if (isset($_GET['success'])): ?>
    <div class="alert success">
        Preprocessing selesai! <?= (int)$_GET['count'] ?> data berhasil diproses.
        <?php $dupRemoved = isset($_GET['duplicate_removed']) ? (int)$_GET['duplicate_removed'] : 0; ?>
        <?php if ($dupRemoved > 0): ?>
            Ditemukan <strong><?= $dupRemoved ?> data duplikat</strong> (teks asli sama persis)
            dan otomatis dihapus, sehingga jumlah data pada batch ini berkurang.
        <?php endif; ?>
        Lihat detail per baris di <a href="preprocessing_result.php">Hasil Pre-Processing</a>,
        atau lanjutkan ke menu <a href="training.php">Training Model</a>.
    </div>
<?php endif; ?>

<?php if (isset($_GET['error'])): ?>
    <div class="alert error"><?= htmlspecialchars($_GET['error']) ?></div>
<?php endif; ?>

<div class="card">
    <div class="flex-between">
        <h2 style="margin:0;">Status Preprocessing per Batch</h2>
        <a href="preprocessing_result.php" class="btn secondary small">📋 Lihat Hasil Pre-Processing</a>
    </div>
    <table class="mt-16">
        <tr><th>Nama Batch</th><th>Total Data</th><th>Sudah Diproses</th><th>Progress</th><th>Aksi</th></tr>
        <?php if ($batches->num_rows === 0): ?>
            <tr><td colspan="5" class="text-muted">Belum ada dataset. Silakan upload terlebih dahulu.</td></tr>
        <?php endif; ?>
        <?php while ($b = $batches->fetch_assoc()):
            $pct = $b['total'] > 0 ? round(($b['selesai'] / $b['total']) * 100) : 0;
            // Kalau belum ada snapshot mentah untuk batch ini (mis. batch lama
            // yang diupload sebelum fitur ini ada), tampilkan total saat ini
            // sebagai fallback -- lebih baik daripada kosong/salah.
            $totalMentah = isset($uploadLogByBatch[$b['dataset_batch']])
                ? $uploadLogByBatch[$b['dataset_batch']]
                : $b['total'];
        ?>
        <tr>
            <td><strong><?= htmlspecialchars($b['dataset_batch']) ?></strong></td>
            <td><?= $totalMentah ?></td>
            <td><strong style="color:#16a34a;"><?= $b['selesai'] ?></strong></td>
            <td style="min-width:160px;">
                <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:<?= $pct ?>%"></div></div>
                <span class="text-muted"><?= $pct ?>%</span>
            </td>
            <td>
                <?php if ($b['selesai'] < $b['total']): ?>
                    <form action="process_preprocessing.php" method="POST" style="display:inline-block;">
                        <input type="hidden" name="batch" value="<?= htmlspecialchars($b['dataset_batch']) ?>">
                        <button type="submit" class="btn small">Jalankan Preprocessing</button>
                    </form>
                <?php else: ?>
                    <span class="badge selesai">Selesai</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="card">
    <h2>Tahapan Preprocessing yang Dijalankan</h2>
    <div class="alert info">
        Sistem menjalankan <strong>5 tahap</strong>: case folding &rarr; cleaning &rarr; normalisasi &rarr;
        tokenizing &rarr; stopword removal.
    </div>
    <div class="alert info" style="margin-bottom:0;">
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 140px;">&bull; Case Folding</span><span>: Ubah seluruh teks menjadi huruf kecil.</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 140px;">&bull; Cleaning</span><span>: Hapus URL/www, mention, hashtag, angka, tanda baca, emoji, dan kurangi huruf berulang berlebihan ("bagusss"→"baguss").</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 140px;">&bull; Normalisasi</span><span>: Ubah kata tidak baku/singkatan menjadi kata baku menggunakan kamus normalisasi.</span></div>
        <div style="display:flex; gap:8px; margin-bottom:6px;"><span style="flex:0 0 140px;">&bull; Tokenizing</span><span>: Pecah kalimat menjadi kumpulan kata (token).</span></div>
        <div style="display:flex; gap:8px;"><span style="flex:0 0 140px;">&bull; Stopword Removal</span><span>: Hapus kata umum yang tidak bermakna sentimen (dan, yang, di, dsb).</span></div>
    </div>
</div>

<?php include __DIR__ . '/templates/footer.php'; ?>
